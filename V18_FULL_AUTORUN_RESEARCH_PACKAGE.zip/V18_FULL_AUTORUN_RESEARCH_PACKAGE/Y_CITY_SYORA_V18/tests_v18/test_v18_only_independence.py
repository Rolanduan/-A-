"""V18-only packaging isolation: no older-version modules or data fixtures required."""
from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'code_v18'))

def test_only_v18_source_tree_present():
    assert (R/'code_v18/prepare_tiger_acs_origins.py').is_file()
    assert (R/'code_v18/acquire_osm_walk.py').is_file()
    assert (R/'code_v18/gis_network_core.py').is_file()
    assert not any((R/name).exists() for name in ('code_v13','code_v14','code_v15',
        'V13_MASTER.md','V14_MASTER.md','V15_MASTER.md', 'legacy_V11_exact',
        'legacy_V12_exact','source_original_v14','source_original_v15',
        'tests_v13','tests_v14','results_v15_gis','paper_v15_official_gis'))

def test_no_code_version_imports():
    for file in (R/'code_v18').glob('*.py'):
        text=file.read_text(encoding='utf-8')
        for legacy in ('code_v13','code_v14','code_v15','tests_v13','tests_v14',
                       'data/raw_official/v15','results_v15_gis'):
            assert legacy not in text,(file,legacy)

def test_sole_controller_has_all_phases_and_current_geo_module():
    import run_v18
    assert len(run_v18.STAGES)>=24
    essential=['official_summary','census','geography','networks','osm_temporal','score','audit',
               'independent_replay','raw_network_replay','controlled_ablation','external_imls',
               'robustness_lp','route_stress','multicity_maps','paper','release','package']
    assert all(stage in run_v18.STAGES for stage in essential)
    assert run_v18.STAGES.index('score')<run_v18.STAGES.index('controlled_ablation')<run_v18.STAGES.index('paper')
    assert run_v18.STAGES.index('external_imls')<run_v18.STAGES.index('paper')
    assert (run_v18.SCRIPT/'prepare_tiger_acs_origins.py').is_file()
    assert run_v18.SCRIPT==R/'code_v18'

def test_registry_and_master_contain_no_historical_dependency():
    master=(R/'V18_MASTER.md').read_text()
    for legacy in ('code_v13','code_v14','code_v15','V15_MASTER.md','V14_MASTER.md','V13_MASTER.md'):
        assert legacy not in master
    assert (R/'config_v18/reference_model_v18.json').is_file()
