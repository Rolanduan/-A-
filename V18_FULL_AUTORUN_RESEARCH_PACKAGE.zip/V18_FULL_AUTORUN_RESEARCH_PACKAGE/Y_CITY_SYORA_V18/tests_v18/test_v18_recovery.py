"""Offline engineering fixtures only, not real empirical city observations.
Tests must never be packaged as claimed city data or field-validated park entrances.
"""
from __future__ import annotations
import datetime as dt,math,json
from pathlib import Path
import pytest
import numpy as np
import pandas as pd
import networkx as nx
from shapely.geometry import LineString
from access_policy import classify_access,bounds,opportunity_at_distance,aggregate_pair_bounds
from model_ablation import score_model,combine_domains,create_city_comparison
from robustness_lp import polytope_extreme,dominance_and_regret,validate_bounds,utility_matrix
from stress_real_routes import identity_dropout,group_pairs,city_counterfactual
from replay_raw_network import parse_overpass_original,independent_graph_from_overpass_files,haversine_m,check_node_to_node
from external_imls_validation import discover_imls_2024_csv_link,greedy_nearest_match
from render_city_atlas_v18 import build_corridor_polygons
from source_temporal_audit import check as check_dates
from official_summary import validate_source

@pytest.mark.parametrize('tag,want',[
  ('yes','OSM_TAGGED_PUBLIC'),('public','OSM_TAGGED_PUBLIC'),('permissive','OSM_TAGGED_PUBLIC'),
  (None,'UNKNOWN'),('','UNKNOWN'),('unknown','UNKNOWN'),('Private','RESTRICTED'),
  ('no','RESTRICTED'),('customers','RESTRICTED'),('permit','RESTRICTED'),
  ('maybe','UNKNOWN'),('restricted','UNKNOWN')])
def test_access_labeled_not_imagined(tag,want):
    item=classify_access(tag)
    assert item['access_status']==want
    assert item['observed_eligibility']=='NOT_VERIFIED'

@pytest.mark.parametrize('status,expected',[
    ('UNKNOWN',(0,1)),('OSM_TAGGED_PUBLIC',(1,1)),('RESTRICTED',(0,0))])
def test_access_reference_upper(status,expected):assert bounds(status)==expected

def test_access_bad_status_rejected():
    with pytest.raises(ValueError):bounds('PUBLIC_BY_DEFAULT')

@pytest.mark.parametrize('distance',[0,1,100,750,1500,1501,4000])
def test_walking_kernel_is_physically_monotone(distance):
    old=opportunity_at_distance(distance)
    assert 0<=old<=1
    assert opportunity_at_distance(distance+10)<=old+1e-12

def test_walking_cutoff_discontinuity_explicit():
    assert opportunity_at_distance(1500,1.25,20)>0
    assert opportunity_at_distance(1500.1,1.25,20)==0

def test_actual_pair_bound_must_not_treat_unknown_as_public():
    pairs=[{'kind':'library','route_dist_m':100,'approach_dist_m':0,'facility_snap_m':0,'access_status':'UNKNOWN'},
           {'kind':'library','route_dist_m':100,'approach_dist_m':0,'facility_snap_m':0,'access_status':'OSM_TAGGED_PUBLIC'},
           {'kind':'park','route_dist_m':50,'approach_dist_m':0,'facility_snap_m':0,'access_status':'RESTRICTED'}]
    got=aggregate_pair_bounds(pairs)
    assert got['library']['upper']>got['library']['tagged']>0
    assert got['park']['upper']==got['park']['tagged']==0

def test_city_model_structural_controls_numerical_fixture():
    origin=pd.DataFrame([{'tract_geoid':'001','longitude':-97.75,'latitude':30.27,'youth_15_17':100,
        'library_access_20m':0.8,'park_access_20m':0.3,'library_access_upper_20m':1.0,'park_access_upper_20m':0.5},
        {'tract_geoid':'002','longitude':-97.76,'latitude':30.28,'youth_15_17':150,
        'library_access_20m':0.1,'park_access_20m':0.25,'library_access_upper_20m':0.5,'park_access_upper_20m':0.3}])
    cand=pd.DataFrame([{'osm_id':'a','lon':-97.751,'lat':30.271,'kind':'library','access_status':'OSM_TAGGED_PUBLIC'},
                       {'osm_id':'b','lon':-97.762,'lat':30.282,'kind':'park','access_status':'OSM_TAGGED_PUBLIC'},
                       {'osm_id':'c','lon':-97.761,'lat':30.281,'kind':'park','access_status':'UNKNOWN'}])
    u=np.array([combine_domains(a,b) for a,b in zip(origin.library_access_20m,origin.park_access_20m)])
    expected=score_model(50,u,origin.youth_15_17.to_numpy(float),rho=.25)[0]
    row=create_city_comparison({'city':'Fixture not a city','city_geoid':'4805000','M0_acs_citywide':50,'M1_real_walk_20m':expected},origin,cand)
    assert abs(row['M_network_Q10_reference']-expected)<1e-9
    assert row['M_network_unknown_upper']>row['M_network_Q10_reference']
    assert row['M_inventory_same_POIs']!=row['M_network_Q10_reference']
    assert row['n_tagged_public_lib']==1
    assert row['n_tagged_public_park']==1
    assert row['n_unknown']==1

def test_model_refuses_fabricated_ref_score():
    with pytest.raises(ValueError):score_model(20,[2,0],[1,1])

def test_solve_exact_weight_lp():
    v,w=polytope_extreme([1,0],[ (0.2,0.8),(0.2,0.8) ])
    assert v==pytest.approx(.2)
    maximum,_=polytope_extreme([1,0],[(.2,.8),(.2,.8)],maximize=True)
    assert maximum==pytest.approx(.8)

def test_pareto_and_minimax_on_known_toy_matrix():
    utilities=[[.9,.9],[.8,.8],[1.0,.1]]
    rows=dominance_and_regret(utilities,['A','B','C'],lower=.1,upper=.9)
    a,b,c=rows
    assert a['pareto_non_dominated'] is True
    assert b['pareto_non_dominated'] is False
    assert 'B' in a['dominates']
    assert a['maximum_regret_over_weights']>=0
    assert c['maximum_regret_over_weights']>=0

def test_bad_weight_region_fails():
    with pytest.raises(ValueError):validate_bounds(.6,.7,3)

def test_hypothetical_missing_POI_stable_identity():
    assert identity_dropout('id123',.25)==identity_dropout('id123',.25)
    assert identity_dropout('id123',0) is False
    assert identity_dropout('id123',1) is True

def test_unknown_policy_affects_route_stress_not_source():
    rows=[{'tract_geoid':'1','youth_15_17':100}]
    pairs=[{'tract_geoid':'1','facility_osm_id':'f1','kind':'library','route_dist_m':'100',
            'approach_dist_m':'0','facility_snap_m':'0','access_status':'UNKNOWN'}]
    tracts=pd.DataFrame(rows)
    lo=city_counterfactual(60,tracts,pairs,1.25,0,False)
    hi=city_counterfactual(60,tracts,pairs,1.25,0,True)
    assert lo==pytest.approx(36.)
    assert hi>lo

def test_raw_overpass_json_parse_and_raw_nodes(tmp_path):
    # Fake OSM elements are test-only, not GIS evidence.
    nodes=[{'type':'node','id':i,'lat':30+i*.0001,'lon':-97.75} for i in range(1,122)]
    ways=[{'type':'way','id':1000+i,'nodes':[i+1,i+2,i+3,i+4],
           'tags':{'highway':'residential'}} for i in range(1,113)]
    f=tmp_path/'fixture.json';f.write_text(json.dumps({'elements':nodes+ways}))
    g=independent_graph_from_overpass_files([f]);assert g.number_of_nodes()>100
    assert nx.has_path(g,2,36)
    assert haversine_m(30,-97.75,30.0001,-97.75)>0

def test_raw_overpass_wrong_payload_fails():
    with pytest.raises(ValueError):parse_overpass_original(b'{"place":"not-overpass"}')

def test_node_route_sample_comparison(tmp_path):
    g=nx.DiGraph();g.add_edge(1,2,length=5)
    rows=[{'origin_node_id':'1','facility_node_id':'2','route_dist_m':'5'} for _ in range(12)]
    result=check_node_to_node(g,rows,max_pairs=10)
    assert result['status']=='PASS_RAW_OSM_BYTES_REBUILT_TO_ROUTES'

def test_gis_corridors_from_directed_real_fixture_not_euclidean():
    G=nx.MultiDiGraph()
    for i in range(4):G.add_node(i,x=float(i*150),y=0.)
    G.add_edge(0,1,length=150);G.add_edge(1,2,length=150);G.add_edge(2,3,length=150)
    corridors=build_corridor_polygons(G,0,minutes=(2,4,8),speed=1.25)
    assert corridors[2].area>0 and corridors[8].area>=corridors[2].area

def test_fy2024_not_2023_discovery_fixture():
    page='<h2>FY 2024</h2><a href="/sites/original_2024_csv.zip">CSV (ZIP 3 MB)</a><h2>FY 2023</h2><a href="/old.csv.zip">CSV (ZIP)</a>'
    url=discover_imls_2024_csv_link(page)
    assert url.startswith('https://www.imls.gov/sites/original_2024_csv.zip')

def test_unique_outlet_match_not_double_counted():
    a=np.array([[0,0],[1,0],[3000,0]],float)
    b=np.array([[.1,0],[3001,0]],float)
    assert greedy_nearest_match(a,b,radius=50)==2

def test_snapshot_window_cannot_auto_certify_historical_year():
    now=dt.datetime(2026,11,9,tzinfo=dt.timezone.utc)
    entries=[{'city':str(i),'status':'REAL_OSM_NETWORK_ACQUIRED_AND_GRAPH_ROUTED',
              'completed_utc':(now+dt.timedelta(minutes=i)).isoformat()} for i in range(12)]
    r=check_dates(entries)
    assert r['not_same_historical_vintage_as_acs'] is True
    entries[-1]['completed_utc']=(now+dt.timedelta(days=9)).isoformat()
    with pytest.raises(ValueError):check_dates(entries)

def test_official_source_requires_actual_standalone_latex(tmp_path):
    f=tmp_path/'template.tex';f.write_text('some text')
    with pytest.raises(ValueError):validate_source(f)
    f.write_text(r'\documentclass[12pt]{article}'+'\n'*300+r'\begin{document}HiMCM example\end{document}')
    assert 'HiMCM example' in validate_source(f)
