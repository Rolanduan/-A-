"""Synthetic layout fixtures only; never research evidence or city results."""
from pathlib import Path
import sys
import fitz

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'code_v18'))
from paper_layout_contract import validate_tex_structure, audit_pdf_layout


def valid_tex():
    return r'''\documentclass{article}
\begin{document}
\pagenumbering{arabic}
\section*{Summary Sheet}
Problem. Approach. Actual results.
\clearpage
\renewcommand{\contentsname}{Table of Contents}
\tableofcontents
\clearpage
\section{Introduction and Restatement of the Problem}
Text.
\section{Assumptions with Justifications}
Text.
\section{Presentation of Model and Solution}
Text.
\section{Analysis of Your Work}
Text.
\section{Concluding Paragraph}
One final paragraph only.
\section{Supplementary 1--2 Page Documents and Memos}
\subsection*{Nontechnical News Article}
One page article.
\clearpage
\section{Reference List}
References.
\end{document}'''


def make_pdf(path, pages):
    doc = fitz.open()
    for text in pages:
        page = doc.new_page(width=612, height=792)
        page.insert_text((54, 72), text, fontsize=12)
    doc.save(path)
    doc.close()


def layout_pages():
    return [
        'Summary Sheet\nProblem\nApproach\nActual results\nConclusion',
        'Table of Contents\nSummary Sheet\nIntroduction and Restatement of the Problem\nAssumptions with Justifications\nPresentation of Model and Solution\nAnalysis of Your Work\nConcluding Paragraph\nSupplementary 1--2 Page Documents and Memos\nNontechnical News Article\nReference List',
        'Introduction and Restatement of the Problem\nRestatement in our own words.\nAssumptions with Justifications\nAssumptions and reasons.',
        'Presentation of Model and Solution\nData, model, ranking and maps.',
        'Analysis of Your Work\nSensitivity, strengths and limitations.',
        'Concluding Paragraph\nOne concluding paragraph.',
        'Supplementary 1--2 Page Documents and Memos\nNontechnical News Article\nNews article content.',
        'Reference List\nReferences and sources.'
    ]


def test_tex_structure_follows_official_optional_outline():
    result = validate_tex_structure(valid_tex())
    assert result['status'] == 'PASS', result['issues']


def test_tex_structure_rejects_reference_list_not_last():
    text = valid_tex().replace('\\end{document}', '\\section{After References}\nBad.\n\\end{document}')
    result = validate_tex_structure(text)
    assert result['status'] == 'FAIL'
    assert 'REFERENCE_LIST_NOT_FINAL_MAJOR_SECTION' in result['issues']


def test_pdf_layout_passes_summary_toc_sections_article_and_references(tmp_path):
    p = tmp_path / 'layout.pdf'
    make_pdf(p, layout_pages())
    result = audit_pdf_layout(p, supplemental_titles=['Nontechnical News Article'])
    assert result['status'] == 'PASS', result['issues']
    assert result['summary_sheet_pages'] == 1
    assert result['table_of_contents_starts_page'] == 2
    assert result['supplemental_document_pages']['Nontechnical News Article'] == 1


def test_pdf_layout_rejects_summary_not_one_page(tmp_path):
    p = tmp_path / 'layout_bad_summary.pdf'
    pages = layout_pages()
    pages.insert(1, 'Summary Sheet continued with additional material.')
    make_pdf(p, pages)
    result = audit_pdf_layout(p, supplemental_titles=['Nontechnical News Article'])
    assert result['status'] == 'FAIL'
    assert 'TABLE_OF_CONTENTS_DOES_NOT_START_ON_PAGE_2' in result['issues']



def test_pdf_layout_rejects_missing_toc_entry(tmp_path):
    p = tmp_path / 'layout_bad_toc.pdf'
    pages = layout_pages()
    pages[1] = pages[1].replace('Assumptions with Justifications\n', '')
    make_pdf(p, pages)
    result = audit_pdf_layout(p, supplemental_titles=['Nontechnical News Article'])
    assert result['status'] == 'FAIL'
    assert 'TABLE_OF_CONTENTS_ENTRY_MISSING:Assumptions with Justifications' in result['issues']

def test_pdf_layout_rejects_three_page_news_article(tmp_path):
    p = tmp_path / 'layout_bad_news.pdf'
    pages = layout_pages()
    pages[6] = 'Supplementary 1--2 Page Documents and Memos\nNontechnical News Article\nPage one.'
    pages.insert(7, 'News article continued. Page two.')
    pages.insert(8, 'News article continued. Page three.')
    make_pdf(p, pages)
    result = audit_pdf_layout(p, supplemental_titles=['Nontechnical News Article'])
    assert result['status'] == 'FAIL'
    assert any(x.startswith('SUPPLEMENTAL_PAGE_COUNT_OUT_OF_RANGE:Nontechnical News Article:3') for x in result['issues'])
