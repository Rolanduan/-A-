# V18 source and licensing notice

- 2026 HiMCM Problem A source: © COMAP. User-provided reference PDF; use only with the applicable rights and contest terms.
- 2024 Census ACS and TIGER: official U.S. Census Bureau original downloads occur later; no raw Census files are prepackaged. Source: https://www.census.gov/ .
- OpenStreetMap street network and POIs: © OpenStreetMap contributors, Open Database License; respect ODbL attribution, share-alike and dataset use requirements. https://www.openstreetmap.org/copyright .
- Geofabrik is a distributor of OSM extracts; official Census statistics and OpenStreetMap observations are separate source families.
- The source and figure generators are included for the research workflow; generated maps and charts do not exist until real-data execution.
