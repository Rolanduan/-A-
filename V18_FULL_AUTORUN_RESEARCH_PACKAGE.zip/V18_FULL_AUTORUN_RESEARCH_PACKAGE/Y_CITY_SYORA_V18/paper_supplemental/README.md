# V18.2 supplementary documents and memos

The paper builder always creates and inserts the result-driven **Nontechnical News Article** as the first supplementary document. Do not add a duplicate copy to this folder.

If the research project has any other required 1–2 page document or memo that is not already included in the main solution, place its `.tex` file in this directory and register it in `manifest.json`:

```json
{
  "id": "document_id",
  "title": "Human-readable document title",
  "path": "paper_supplemental/document_id.tex",
  "pages_min": 1,
  "pages_max": 2
}
```

The builder refuses to compile if a `.tex` file is present but unregistered, a registered file is missing, or the compiled PDF shows any supplemental document outside the 1–2 page range. All supplemental documents are placed after the main **Concluding Paragraph** and before the final **Reference List**.
