#!/usr/bin/env python3
"""Twelve authentic city/tract GIS maps and real street-network 10/20/30 minute corridors.

No fabricated basemaps. Corridors buffer network edges ONLY to make route reachability
visible; they are NOT full-space pedestrian isochrones or verified entrances.
"""
from __future__ import annotations
import json,math
from pathlib import Path
import pandas as pd
import geopandas as gpd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from shapely.geometry import Point,LineString
from shapely.ops import unary_union
import networkx as nx
from acquire_osm_walk import ROOT,CITY,digest

NET=ROOT/'data/processed/v18_network';OUT=ROOT/'figures/v18_multicity_gis'

def build_corridor_polygons(graph,origin_node,minutes=(10,20,30),speed=1.25,buffer_m=12):
    if not graph.is_directed():raise ValueError('WALKING_GRAPH_REQUIRES_DIRECTED_TOPOLOGY')
    geoms={}
    for t in minutes:
        dist=nx.single_source_dijkstra_path_length(graph,origin_node,cutoff=t*60*speed,weight='length')
        reached=set(dist)
        lines=[]
        for u,v,k,d in graph.edges(keys=True,data=True):
            if u in reached and v in reached:
                geom=d.get('geometry')
                if geom is None:geom=LineString([(graph.nodes[u]['x'],graph.nodes[u]['y']),
                                               (graph.nodes[v]['x'],graph.nodes[v]['y'])])
                lines.append(geom)
        if not lines:raise ValueError('NO_WALK_NETWORK_EDGES_REACHABLE')
        # Buffer is a visual stroke/corridor, NOT a claim that every point in polygon is accessible.
        geoms[t]=unary_union(lines).buffer(buffer_m)
    return geoms


def run_city(geoid):
    import osmnx as ox
    receipt=json.loads((NET/f'receipt_{geoid}.json').read_text())
    graphfile=ROOT/receipt['real_osm_graph_file']
    if not graphfile.exists() or digest(graphfile)!=receipt['graph_sha256']:
        raise ValueError('WALK_GRAPH_SOURCE_SHA_MISMATCH_'+geoid)
    graph=ox.load_graphml(filepath=graphfile)
    H=ox.project_graph(graph,to_crs='EPSG:5070')
    pp=ROOT/f'data/raw_official/v18/tl_2024_{geoid[:2]}_place.zip'
    tt=ROOT/f'data/raw_official/v18/tl_2024_{geoid[:2]}_tract.zip'
    city=gpd.read_file('zip://'+str(pp));city=city[city.PLACEFP.astype(str).str.zfill(5)==geoid[2:]].to_crs('EPSG:5070')
    if len(city)!=1:raise ValueError('CITY_POLYGON_MISSING')
    tracts=gpd.read_file('zip://'+str(tt)).to_crs('EPSG:5070')
    tracts=tracts[tracts.intersects(city.geometry.iloc[0])].copy()
    metrics=pd.read_csv(NET/f'city_origins_access_{geoid}.csv',dtype={'tract_geoid':str})
    tracts=tracts.merge(metrics,left_on='GEOID',right_on='tract_geoid',how='inner',validate='one_to_one')
    if tracts.empty:raise ValueError('NO_MAPPED_TRACTS')
    import numpy as np
    tracts['opportunity_index']=.55*(1-np.exp(-tracts.library_access_20m.astype(float)/2))+.45*(1-np.exp(-tracts.park_access_20m.astype(float)/2))
    origin_file=ROOT/'data/processed/v18_gis/official_tract_origins_v18.csv'
    origins=pd.read_csv(origin_file,dtype={'city_geoid':str,'tract_geoid':str})
    origins=origins[origins.city_geoid.str.zfill(7)==geoid]
    origin=origins.iloc[origins.estimated_youth_15_17.astype(float).argmax()]
    representative=gpd.GeoSeries([Point(float(origin.longitude),float(origin.latitude))],crs='EPSG:4326').to_crs('EPSG:5070').iloc[0]
    node=ox.distance.nearest_nodes(H,representative.x,representative.y)
    corridors=build_corridor_polygons(H,node)
    poi=pd.read_csv(NET/f'poi_osm_{geoid}.csv')
    poi=gpd.GeoDataFrame(poi,geometry=gpd.points_from_xy(poi.lon,poi.lat),crs='EPSG:4326').to_crs('EPSG:5070')
    fig,(ax1,ax2)=plt.subplots(1,2,figsize=(15,7))
    tracts.plot(ax=ax1,column='opportunity_index',vmin=0,vmax=1,cmap='viridis',edgecolor='#999999',linewidth=.15,legend=True)
    city.boundary.plot(ax=ax1,color='black',linewidth=1.4)
    ax1.set_title('Population-weighted tract opportunity | 20 min')
    for t,color in [(30,'#dae9d2'),(20,'#a9c7d7'),(10,'#6d96bc')]:
        gpd.GeoSeries([corridors[t]],crs='EPSG:5070').plot(ax=ax2,color=color,alpha=.8,linewidth=0)
    city.boundary.plot(ax=ax2,color='#303030',linewidth=1.5)
    for kind,marker in [('library','s'),('park','o')]:
        subset=poi[poi.kind==kind]
        if len(subset):subset.plot(ax=ax2,marker=marker,color='#292929',markersize=13,alpha=.8,label=kind)
    ax2.scatter([representative.x],[representative.y],marker='*',s=100,color='#ba5334',zorder=8,label='Representative tract origin')
    ax2.set_title('Actual directed walk-network corridors | 10 / 20 / 30 min')
    ax2.legend(loc='lower left',fontsize=9)
    for ax in (ax1,ax2):
        ax.set_aspect('equal');ax.set_axis_off()
    fig.suptitle(f'{CITY[geoid]} | 2024 Census TIGER/ACS + actual OSM walking snapshot',fontsize=16,fontweight='bold')
    fig.text(.5,.025,'Modelled walking speed 1.25 m/s. Network corridors buffered 12 m only for display; NOT verified entry points. Tract youth 15–17 is an area-weighted proxy.',
              ha='center',fontsize=9)
    fig.tight_layout(rect=[0,.055,1,.93])
    OUT.mkdir(parents=True,exist_ok=True)
    prefix=OUT/f'V18_MAP_{geoid}_{CITY[geoid].upper().replace(" ","_")}'
    fig.savefig(str(prefix)+'.pdf');fig.savefig(str(prefix)+'.svg');plt.close(fig)
    return {'city_geoid':geoid,'city':CITY[geoid],
            'pdf':str(prefix.relative_to(ROOT))+'.pdf','pdf_sha256':digest(str(prefix)+'.pdf'),
            'svg':str(prefix.relative_to(ROOT))+'.svg','tracts':len(tracts),
            'graph_sha256':receipt['graph_sha256'],'official_tiger_sha256':digest(pp),
            'meaning':'Real OSM edges + Census polygons; buffer is display, not verified walking isochrone polygon.'}

def run():
    from audit_full_gis import check
    if check()['status']!='PASS':raise RuntimeError('RAW_CITY_AND_OSM_GATES_REQUIRED')
    records=[run_city(geo) for geo in CITY]
    target=OUT/'V18_12_CITY_MAP_EVIDENCE_MANIFEST.json'
    target.write_text(json.dumps({'status':'TWELVE_REAL_CITY_MAPS_RENDERED','cities':records},indent=2))
    print('SUCCESS:',len(records),'real source-backed city maps')
    return records
if __name__=='__main__':run()
