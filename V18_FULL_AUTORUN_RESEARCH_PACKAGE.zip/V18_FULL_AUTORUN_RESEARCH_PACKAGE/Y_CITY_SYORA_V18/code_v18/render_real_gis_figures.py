#!/usr/bin/env python3
"""Source-backed vector figures; fail if a real GIS dataset is absent."""
from pathlib import Path
import geopandas as gpd,pandas as pd
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import osmnx as ox
from score_official_gis import ROOT,OUT,CITY
from audit_full_gis import check

def render():
 if check()['status']!='PASS':raise RuntimeError('CANNOT_DRAW_UNVERIFIED_GIS_FIGURES')
 d=pd.read_csv(OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv');d=d.sort_values('M1_rank')
 folder=ROOT/'figures/v18_official_gis';folder.mkdir(parents=True,exist_ok=True)
 plt.rcParams.update({'pdf.fonttype':42,'font.size':10,'font.family':'DejaVu Sans'})
 fig,ax=plt.subplots(figsize=(9,6.5));y=list(range(len(d)));ax.barh(y,d.M1_real_walk_20m,color='#285975');ax.set_yticks(y,d.city);ax.invert_yaxis();ax.set_xlim(0,100);ax.set_xlabel('Reference score, 0–100');ax.set_title('Citywide ACS + observed street-network opportunity (12-city reference scenario)')
 for yy,v in zip(y,d.M1_real_walk_20m):ax.text(v+.7,yy,f'{v:.1f}',va='center',fontsize=9)
 fig.text(.02,.005,'Data: ACS 2024 5-year (E/M), TIGER 2024, OSMnx Overpass cached network; score is conditional, not a causal effect.',fontsize=8);fig.tight_layout(rect=(0,.04,1,1))
 for ex in ['pdf','svg','png']:fig.savefig(folder/f'F17_GIS_01_REAL_CITY_RANKING.{ex}',dpi=220)
 plt.close(fig)
 fig,ax=plt.subplots(figsize=(9,6.5));x=[0,1]
 for r in d.itertuples():ax.plot(x,[r.M0_rank,r.M1_rank],marker='o',linewidth=1.5,label=r.city)
 ax.invert_yaxis();ax.set_xticks(x,['M0: ACS citywide','M1: + real walk network']);ax.set_yticks(range(1,13));ax.set_ylabel('Rank (1 = best)');ax.grid(axis='y',alpha=.2);ax.legend(loc='center left',bbox_to_anchor=(1,0.5),fontsize=8);ax.set_title('Actual changes after structural model revision');fig.tight_layout()
 for ex in ['pdf','svg','png']:fig.savefig(folder/f'F17_GIS_02_RANK_BUMP.{ex}',dpi=220)
 plt.close(fig)
 geoid='4805000';city=CITY[geoid];st=geoid[:2]
 pp=gpd.read_file('zip://'+str(ROOT/f'data/raw_official/v18/tl_2024_{st}_place.zip'))
 target=pp[pp.PLACEFP.astype(str)==geoid[2:]].to_crs('EPSG:5070')
 graph=ox.io.load_graphml(ROOT/f'data/raw_osm/v18/graphml/{geoid}_{city}_walk.graphml')
 nodes,edges=ox.convert.graph_to_gdfs(graph);edges=edges.to_crs('EPSG:5070')
 origins=pd.read_csv(ROOT/f'data/processed/v18_gis/official_tract_origins_v18.csv',dtype={'city_geoid':str});origins=origins.loc[origins.city_geoid==geoid]
 acces=pd.read_csv(ROOT/f'data/processed/v18_network/city_origins_access_{geoid}.csv',dtype={'city_geoid':str})
 origins=origins.merge(acces[['tract_geoid','library_access_20m']],on='tract_geoid',validate='1:1')
 pts=gpd.GeoDataFrame(origins,geometry=gpd.points_from_xy(origins.longitude,origins.latitude),crs='EPSG:4326').to_crs('EPSG:5070')
 pois=pd.read_csv(ROOT/f'data/processed/v18_network/poi_osm_{geoid}.csv');fac=gpd.GeoDataFrame(pois,geometry=gpd.points_from_xy(pois.lon,pois.lat),crs='EPSG:4326').to_crs('EPSG:5070')
 fig,ax=plt.subplots(figsize=(9,8));edges.plot(ax=ax,color='#adb9c2',linewidth=.18,zorder=1);target.boundary.plot(ax=ax,color='#193c56',linewidth=1.2,zorder=2)
 pts.plot(ax=ax,column='library_access_20m',cmap='viridis',markersize=12,legend=True,legend_kwds={'label':'Network-decayed library opportunity'},zorder=3)
 fac.loc[fac.kind=='library'].plot(ax=ax,marker='s',color='#d59636',markersize=14,zorder=4)
 ax.set_title('Austin: Census tract origins and real OSM walking network');ax.axis('off')
 fig.text(.02,.015,'TIGER 2024 boundaries | ACS 2024 15–17 proxy | OSM network as-of acquisition | Facilities are potential, not eligibility-proven.',fontsize=8)
 fig.tight_layout(rect=(0,.04,1,1))
 for ex in ['pdf','svg','png']:fig.savefig(folder/f'F17_GIS_03_AUSTIN_REAL_WALK_MAP.{ex}',dpi=220)
 plt.close(fig)
 print('Rendered three REAL GIS figures from official raw-source gated calculations')
if __name__=='__main__':render()
