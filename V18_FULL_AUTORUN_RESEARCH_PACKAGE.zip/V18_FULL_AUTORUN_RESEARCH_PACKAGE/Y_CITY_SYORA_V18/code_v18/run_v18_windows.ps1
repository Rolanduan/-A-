# V18 genuine federal-data + OSM GIS research pipeline, Windows PowerShell.
# Run from the unzipped Y_CITY_SYORA_V18 folder, not from inside the ZIP.
param(
    [ValidateSet('auto','overpass','geofabrik')][string]$Network='auto',
    [string]$ImportDir='',
    [string]$AttestationDir='',
    [switch]$AllowAttestedOrigin,
    [switch]$DryRun
)
$ErrorActionPreference = 'Stop'
Set-Location (Resolve-Path (Join-Path $PSScriptRoot '..'))
$Python = 'python'
& $Python -m pip install -r code_v18/requirements_v18.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed; try Miniforge/conda-forge.' }
$argsV18 = @('code_v18/run_v18.py','--stage','all','--network',$Network)
if ($ImportDir) { $argsV18 += @('--import-dir',$ImportDir) }
if ($AttestationDir) { $argsV18 += @('--attestation-dir',$AttestationDir) }
if ($AllowAttestedOrigin) { $argsV18 += '--allow-attested-origin' }
if ($DryRun) { $argsV18 += '--dry-run' }
& $Python @argsV18
if ($LASTEXITCODE -ne 0) { throw "V18 empirical pipeline blocked; consult qa_v18/v18_execution_state.json" }
Write-Host 'V18 pipeline completed technically; human scientific review remains required.'
