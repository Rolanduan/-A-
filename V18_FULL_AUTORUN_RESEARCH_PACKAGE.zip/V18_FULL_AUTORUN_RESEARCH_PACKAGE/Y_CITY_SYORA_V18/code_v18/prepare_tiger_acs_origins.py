#!/usr/bin/env python3
"""V18 city/tract overlay. Reuses only downloaded TIGER polygons and ACS B01001 raw.
Population-weighting is explicitly area interpolation; it is NOT household geocoding.
"""
from pathlib import Path
import csv,json,math,sys
import geopandas as gpd
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1]
OFFICIAL_RAW=ROOT/'data/raw_official/v18';OUT=ROOT/'data/processed/v18_gis'
CITIES={'4805000':'Austin','2507000':'Boston','1714000':'Chicago','0820000':'Denver','5548000':'Madison','2743000':'Minneapolis','4261000':'Pittsburgh','4159000':'Portland','3755000':'Raleigh','0666000':'San Diego','5363000':'Seattle','1304000':'Atlanta'}
def read_tract_population():
    raw=OFFICIAL_RAW/'acs_2024_5y_B01001.dat';data={}
    if not raw.exists():raise FileNotFoundError('OFFICIAL ACS B01001 original not downloaded')
    with raw.open(encoding='utf-8-sig',errors='replace',newline='') as f:
        reader=csv.DictReader(f,delimiter='|');field={c.upper():c for c in reader.fieldnames or []}
        for k in ('GEO_ID','B01001_E006','B01001_E030'):
            if k not in field:raise ValueError(f'MISSING_OFFICIAL_ACS_FIELD:{k}')
        for r in reader:
            geo=r[field['GEO_ID']]
            if not geo.startswith('1400000US'):continue
            try:
                a=int(r[field['B01001_E006']]);b=int(r[field['B01001_E030']])
            except (TypeError,ValueError):continue
            if a<0 or b<0:continue
            data[geo[9:]]=a+b
    if not data:raise ValueError('NO_AGE_15_17_TRACT_DATA')
    return data

def run():
    p=read_tract_population();rows=[];out=OUT;out.mkdir(parents=True,exist_ok=True)
    for geo,name in CITIES.items():
        st=geo[:2];place=geo[2:]
        placezip=OFFICIAL_RAW/f'tl_2024_{st}_place.zip';tractzip=OFFICIAL_RAW/f'tl_2024_{st}_tract.zip'
        if not placezip.exists() or not tractzip.exists():raise FileNotFoundError(f'MISSING_REAL_TIGER_FOR_{name}')
        pp=gpd.read_file('zip://'+str(placezip));tt=gpd.read_file('zip://'+str(tractzip))
        city=pp.loc[pp['PLACEFP'].astype(str)==place]
        if len(city)!=1:raise ValueError(f'TIGER_PLACE_GEOID_MISMATCH:{geo}')
        city=city.to_crs('EPSG:5070'); boundary=city.geometry.iloc[0]
        tt=tt.to_crs('EPSG:5070')
        hits=tt.loc[tt.intersects(boundary)].copy()
        if hits.empty:raise ValueError('EMPTY_INTERSECTION_'+name)
        n=0.;o=0.
        for _,r in hits.iterrows():
            tract_id=str(r.GEOID);count=p.get(tract_id)
            if count is None:continue
            g=r.geometry;area=g.area
            if area<=0:continue
            fraction=min(1,max(0,g.intersection(boundary).area/area))
            if fraction<1e-5:continue
            weighted=count*fraction
            center=g.intersection(boundary).representative_point()
            origin=gpd.GeoSeries([center],crs='EPSG:5070').to_crs('EPSG:4326').iloc[0]
            rows.append(dict(city_geoid=geo,city=name,tract_geoid=tract_id,latitude=origin.y,longitude=origin.x,
                             area_interpolation_fraction=fraction,estimated_youth_15_17=weighted,
                             population_measure='ACS_2024_5YR_tract_B01001_006+030_area_weighted',is_observed_individual_location=False))
            n+=weighted;o+=1
        if o<=0:raise ValueError('NO_ELIGIBLE_TRACTS_'+name)
        print(f'{name}: {int(o)} tract origins, area-weighted age 15-17 proxy {n:.2f}')
    with (out/'official_tract_origins_v18.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print('CITIES=',len(set(x['city_geoid'] for x in rows)))
if __name__=='__main__':run()
