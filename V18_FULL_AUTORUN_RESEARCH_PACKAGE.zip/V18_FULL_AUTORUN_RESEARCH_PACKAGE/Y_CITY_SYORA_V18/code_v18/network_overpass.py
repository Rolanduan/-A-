#!/usr/bin/env python3
"""V18 configurable, rate-limited OSMnx Overpass route acquisition.
The source remains genuine Overpass HTTP response bytes, cached and SHA256-logged.
Alternate servers may be used only if openly accessible and terms permit it.
"""
import argparse,json,os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
from acquire_osm_walk import CITY,run_city


def run(geoid,max_dist_m=3500):
    import osmnx as ox
    options=[]
    p=os.environ.get('V18_OVERPASS_URL','').strip()
    if p:options.append(p)
    options.append(None)  # OSMnx default public service
    alternates=os.environ.get('V18_OVERPASS_ALTERNATES','')
    if alternates:options+= [a.strip() for a in alternates.split(';') if a.strip()][:2]
    used=set();errors=[]
    for url in options:
        if url in used:continue
        used.add(url)
        if url:
            if not url.startswith('https://'):raise ValueError('OVERPASS_SERVER_MUST_USE_HTTPS')
            ox.settings.overpass_url=url.rstrip('/')
        print('OSM Overpass source:',url or 'OSMnx default',flush=True)
        try:
            result=run_city(geoid,max_dist_m=max_dist_m)
            result['overpass_endpoint_configured']=url or 'OSMnx default'
            receipt=ROOT/f'data/processed/v18_network/receipt_{geoid}.json'
            receipt.write_text(json.dumps(result,indent=2))
            return result
        except Exception as e:
            errors.append({'endpoint':url or 'OSMnx default','error':repr(e)})
            print('Overpass source failed:',repr(e)[:250],flush=True)
    raise RuntimeError('ALL_CONFIGURED_OVERPASS_ENDPOINTS_FAILED_'+CITY[geoid]+':'+json.dumps(errors))

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--city',choices=list(CITY),required=True)
    a.add_argument('--max-dist-m',type=int,default=3500)
    o=a.parse_args();run(o.city,o.max_dist_m)
