#!/usr/bin/env python3
"""V18 streaming, resumable and SHA256-logged binary acquisition.

No success status without actual bytes. Network and manual inputs are not conflated.
This module never hardcodes checksum expectations that were not published.
"""
from __future__ import annotations
import datetime as dt
import hashlib
import json
import os
import shutil
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

CHUNK = 1024 * 1024
USER_AGENT = 'Y-CITY-SYORA-V18 Independent Research (public-data provenance; no bots bypass)'


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(CHUNK), b''):
            h.update(b)
    return h.hexdigest()


def atomically_write_json(path: Path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name+'.writing')
    temp.write_text(json.dumps(obj, indent=2, ensure_ascii=False, sort_keys=True), encoding='utf-8')
    os.replace(temp, path)


def validate_bytes(path: Path, ext: str, expected_min=201):
    path=Path(path)
    if not path.is_file() or path.stat().st_size < expected_min:
        raise ValueError('FILE_MISSING_OR_TOO_SMALL')
    with path.open('rb') as f:
        head=f.read(4096).lstrip().lower()
    if head.startswith((b'<!doctype',b'<html',b'<?xml')) and ext not in ('xml',):
        raise ValueError('RESPONSE_IS_HTML_OR_XML_ERROR_NOT_DATA')
    if ext=='zip':
        if not zipfile.is_zipfile(path):raise ValueError('ZIP_CENTRAL_DIRECTORY_INVALID')
        with zipfile.ZipFile(path) as z:
            if not z.namelist() or not any(n.endswith('.shp') for n in z.namelist()):
                raise ValueError('TIGER_ZIP_NO_SHAPEFILE')
    elif ext=='imls_zip':
        if not zipfile.is_zipfile(path):raise ValueError('IMLS_NOT_VALID_ZIP')
        with zipfile.ZipFile(path) as z:
            if not any('outlet' in n.lower() and n.lower().endswith('.csv') for n in z.namelist()):
                raise ValueError('IMLS_OFFICIAL_OUTLET_CSV_MISSING')
    elif ext=='dat':
        first=head.splitlines()[0]
        if b'geo_id' not in first or b'|' not in first:
            raise ValueError('NOT_CENSUS_TABLE_BASED_GEO_ID_PIPE_DELIMITED')
    elif ext=='pbf':
        if b'osmheader' not in head and b'OSMHeader' not in head:
            # PBF header occurs at the front; avoid rejecting a valid file with layout differences:
            # validate by osmium when available rather than trusting extensions.
            if shutil.which('osmium'):
                r=subprocess.run(['osmium','fileinfo','-e',str(path)],capture_output=True,text=True,timeout=90)
                if r.returncode:raise ValueError('OSMIUM_FILEINFO_FAILED:'+r.stderr[-300:])
            else:
                raise ValueError('PBF_HEADER_UNVERIFIED_REQUIRES_OSMIUM')
    return {'bytes':path.stat().st_size, 'sha256':sha256_file(path), 'validation':'BYTE_AND_FORMAT_PASSED'}


def _urllib_download(url:str, partial:Path, timeout=180):
    current=partial.stat().st_size if partial.exists() else 0
    headers={'User-Agent':USER_AGENT,'Accept-Encoding':'identity'}
    if current:headers['Range']=f'bytes={current}-'
    req=urllib.request.Request(url,headers=headers)
    with urllib.request.urlopen(req,timeout=timeout) as res:
        status=res.status
        final=res.geturl()
        if status not in (200,206):raise RuntimeError('HTTP_'+str(status))
        if current and status==206:
            span=res.headers.get('Content-Range','')
            if not span.startswith(f'bytes {current}-'):
                raise ValueError('UNEXPECTED_CONTENT_RANGE '+span)
        if current and status==200:
            current=0
        # status 200 after Range means server ignored Range: overwrite, never concatenate.
        written=0
        with partial.open('ab' if current else 'wb') as out:
            while True:
                block=res.read(CHUNK)
                if not block:break
                out.write(block);written+=len(block)
        declared=res.headers.get('Content-Length')
        if declared and declared.isdecimal() and written!=int(declared):
            raise ValueError(f'HTTP_BODY_LENGTH_MISMATCH {written}!={declared}')
        if status==206 and '/' in res.headers.get('Content-Range',''):
            total_text=res.headers['Content-Range'].rsplit('/',1)[-1]
            if total_text.isdecimal() and partial.stat().st_size!=int(total_text):
                raise ValueError('HTTP_RANGE_FINAL_SIZE_MISMATCH')
        return {'http_status':status,'response_url':final,
                'content_type':res.headers.get('Content-Type'),
                'content_length_header':res.headers.get('Content-Length'),
                'content_range':res.headers.get('Content-Range')}


def _external_download(url,partial,tool):
    if tool=='aria2' and shutil.which('aria2c'):
        args=['aria2c','--continue=true','--max-tries=3','--retry-wait=4',
              '--split=4','--max-connection-per-server=4','--min-split-size=20M',
              '--user-agent='+USER_AGENT,'--dir='+str(partial.parent),
              '--out='+partial.name,url]
    elif tool=='curl' and shutil.which('curl'):
        args=['curl','--fail','--location','--retry','3','--retry-all-errors',
              '--connect-timeout','30','--speed-time','60','--speed-limit','1024',
              '--continue-at','-','--output',str(partial),url]
    elif tool=='wget' and shutil.which('wget'):
        args=['wget','--continue','--tries=3','--timeout=180','-O',str(partial),url]
    else:raise RuntimeError(f'{tool} not installed')
    r=subprocess.run(args,capture_output=True,text=True,timeout=7200)
    if r.returncode:raise RuntimeError(f'{tool.upper()}_FAILED {r.returncode}: '+r.stderr[-500:])
    return {'http_status':200,'response_url':url,'external_transport':tool}


def fetch(url, target, *, source_id, publisher, extension, attempts=3, transports=('urllib','aria2','curl','wget'), rate_delay=1):
    target=Path(target);target.parent.mkdir(parents=True,exist_ok=True)
    stamp=dt.datetime.now(dt.timezone.utc).isoformat()
    base={'source_id':source_id,'publisher':publisher,'original_url':url,
          'retrieved_utc':stamp,'path':str(target),'status':'FAILED'}
    if target.exists():
        try:
            r=validate_bytes(target,extension)
            return {**base,**r,'status':'DOWNLOADED_ORIGINAL_WITH_SHA',
                    'transport':'existing_verified_file','origin_verification':'LOCAL_HASH_VERIFIED_ORIGIN_FROM_PRIOR_RECEIPT_REQUIRED'}
        except Exception: pass
    partial=target.with_name(target.name+'.part')
    failures=[]
    for method in transports:
        for attempt in range(attempts if method=='urllib' else 1):
            try:
                meta=(_urllib_download(url,partial) if method=='urllib' else
                      _external_download(url,partial,method))
                r=validate_bytes(partial,extension)
                os.replace(partial,target)
                # TLS to official server makes the raw source provenance directly inspectable.
                return {**base,**r,**meta,'status':'DOWNLOADED_ORIGINAL_WITH_SHA',
                        'transport':method,'origin_verification':'DIRECT_TLS_SOURCE'}
            except Exception as exc:
                failures.append(f'{method}-{attempt+1}:{type(exc).__name__}:{str(exc)[:200]}')
                time.sleep(min(3*(attempt+1),9))
        if rate_delay:time.sleep(rate_delay)
    return {**base,'status':'FAILED','failures':failures,'partial_bytes':partial.stat().st_size if partial.exists() else 0}


def verify_receipt(path, receipt, require_direct_source=True):
    if not path.is_file():raise FileNotFoundError(path)
    actual=sha256_file(path)
    if actual != receipt.get('sha256'):raise ValueError('SHA256_MISMATCH:'+str(path))
    if receipt.get('status')!='DOWNLOADED_ORIGINAL_WITH_SHA':raise ValueError('RECEIPT_NOT_PASSED')
    if require_direct_source and receipt.get('origin_verification') not in ('DIRECT_TLS_SOURCE','INHERITED_DIRECT_TLS_SOURCE'):
        raise ValueError('FILE_HASH_OK_BUT_ORIGIN_NOT_VERIFIED')
    return True
