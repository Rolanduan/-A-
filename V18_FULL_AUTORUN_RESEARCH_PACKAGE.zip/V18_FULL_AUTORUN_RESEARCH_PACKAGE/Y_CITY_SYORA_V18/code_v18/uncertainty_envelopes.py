#!/usr/bin/env python3
"""V18 conservative ACS published-MOE stress envelopes; not confidence intervals.
No imputed measurement values. Geometry/network and normative choices treated separately.
"""
from pathlib import Path
import csv,json,math
import pandas as pd
from score_official_gis import ROOT,RAW,OUT,NET,CITY,clamp
from audit_full_gis import check
from acquire_osm_walk import weighted_quantile,digest

def pair(row,table,i):
    e=float(row[f'{table}_E{i:03d}']);m=float(row[f'{table}_M{i:03d}'])
    if not math.isfinite(e) or e<0 or not math.isfinite(m) or m<0 or e>=9e8 or m>=9e8:
        raise ValueError(f'INVALID_ACS_ESTIMATE_OR_MOE {table} {i} {e}/{m}')
    return e,m

def ratio_envelope(n, n_m, d, d_m):
    if d<=0 or n<0 or not all(math.isfinite(x) for x in [n,n_m,d,d_m]):raise ValueError('INVALID_RATIO')
    if d-d_m<=0:raise ValueError('MOE_DENOMINATOR_NOT_POSITIVE')
    return max(0,(n-n_m)/(d+d_m)),min(1,(n+n_m)/(d-d_m))

def acs_utility_bounds(rows):
    r=rows['B25070'];p=rows['B17001'];b=rows['B28002']
    rent_parts=[pair(r,'B25070',i) for i in (7,8,9,10)]
    rent_n=sum(x for x,m in rent_parts);rent_nm=sum(m for x,m in rent_parts)
    t,tm=pair(r,'B25070',1);invalid,im=pair(r,'B25070',11)
    rentlo,renthi=ratio_envelope(rent_n,rent_nm,t-invalid,tm+im)
    pp,ppm=pair(p,'B17001',2);pd,pdm=pair(p,'B17001',1)
    povlo,povhi=ratio_envelope(pp,ppm,pd,pdm)
    bb,bbm=pair(b,'B28002',4);bd,bdm=pair(b,'B28002',1)
    weblo,webhi=ratio_envelope(bb,bbm,bd,bdm)
    m0lo=100*(.35*clamp((.8-renthi)/.6)+.35*clamp((.35-povhi)/.35)+.30*clamp((weblo-.6)/.4))
    m0hi=100*(.35*clamp((.8-rentlo)/.6)+.35*clamp((.35-povlo)/.35)+.30*clamp((webhi-.6)/.4))
    return m0lo,m0hi,dict(rent_min=rentlo,rent_max=renthi,poverty_min=povlo,poverty_max=povhi,broadband_min=weblo,broadband_max=webhi)

def run():
    if check()['status']!='PASS':raise RuntimeError('V18_REFERENCE_GIS_MUST_BE_AUDITED_BEFORE_MOE_STRESS')
    main=pd.read_csv(OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv',dtype={'city_geoid':str});main.city_geoid=main.city_geoid.str.zfill(7)
    tables={}
    for table in ('B25070','B17001','B28002'):
        path=ROOT/f'data/processed/v18_official_acs/ACS_{table}_12_cities.psv'
        with path.open(newline='',encoding='utf-8-sig') as f:records=list(csv.DictReader(f,delimiter='|'))
        tables[table]={r['GEO_ID'][9:]:r for r in records}
    rows=[]
    for r in main.itertuples():
        rr={t:tables[t][r.city_geoid] for t in tables}
        low,high,details=acs_utility_bounds(rr)
        spatial_fraction=(r.M1_real_walk_20m-.6*r.M0_acs_citywide)/.4
        if not 0<=spatial_fraction<=100:raise ValueError('NETWORK_COMPONENT_OUT_OF_RANGE')
        rows.append(dict(city_geoid=r.city_geoid,city=r.city,reference_m1=r.M1_real_walk_20m,
            acs_m0_low_moe_stress=low,acs_m0_high_moe_stress=high,
            m1_low_acs_moe_stress=.6*low+.4*spatial_fraction,
            m1_high_acs_moe_stress=.6*high+.4*spatial_fraction,**details))
    output=OUT/'V18_ACS_MOE_STRESS_ENVELOPES.csv';pd.DataFrame(rows).to_csv(output,index=False)
    receipt={'status':'ACTUAL_ACS_MOE_NUMERIC_STRESS_PASSED',
       'sha256':digest(output),'n_cities':len(rows),
       'interpretation':'These are conservative endpoint stress envelopes using published marginal ACS 90% MOEs, NOT simultaneous confidence intervals; OSM/network and normative uncertainty are separate.'}
    (OUT/'V18_ACS_MOE_STRESS_RECEIPT.json').write_text(json.dumps(receipt,indent=2))
    print(receipt);return rows
if __name__=='__main__':run()
