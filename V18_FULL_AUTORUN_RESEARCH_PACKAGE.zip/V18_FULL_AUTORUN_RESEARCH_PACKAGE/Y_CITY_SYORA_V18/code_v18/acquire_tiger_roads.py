#!/usr/bin/env python3
"""Supplementary 2024 Census TIGER county-level All Roads originals + SHA256.
Not a substitute for access-restricted, walking-specific OSM network routing.
Use this module for independent road-geometry cross-source checks only.
"""
import json,sys,datetime as dt
from pathlib import Path
import geopandas as gpd
from acquire_census import ROOT,RAW,CITIES,STATES
from fetch_verified import fetch,sha256_file,atomically_write_json
DATA=ROOT/'data/raw_official/v18_road_crosscheck'
RECEIPT=ROOT/'qa_v18/tiger_roads_optional_manifest.json'

def run():
    DATA.mkdir(parents=True,exist_ok=True);records=[]
    official='https://www2.census.gov/geo/tiger/TIGER2024'
    counties_by_state={}
    for state in STATES:
        target=DATA/f'tl_2024_{state}_county.zip'
        spec=f'{official}/COUNTY/{target.name}'
        r=fetch(spec,target,source_id='TIGER2024_COUNTY_'+state,publisher='US Census Bureau',extension='zip')
        records.append(r)
        if r['status']!='DOWNLOADED_ORIGINAL_WITH_SHA':
            atomically_write_json(RECEIPT,{'status':'INCOMPLETE','sources':records})
            raise RuntimeError('COUNTY_BOUNDARY_UNAVAILABLE_'+state)
        counties=gpd.read_file('zip://'+str(target)).to_crs('EPSG:5070')
        place=gpd.read_file('zip://'+str(RAW/f'tl_2024_{state}_place.zip')).to_crs('EPSG:5070')
        polygon=place.loc[place.PLACEFP.astype(str).isin([g[2:] for g in CITIES if g.startswith(state)])]
        if polygon.empty:raise ValueError('EMPTY_PLACE_'+state)
        selected=counties[counties.intersects(polygon.geometry.union_all().buffer(4000))]
        ids=selected.GEOID.astype(str).tolist()
        if not ids:raise ValueError('NO_COUNTIES_INTERSECT_'+state)
        counties_by_state[state]=ids
    for state,codes in counties_by_state.items():
        for code in codes:
            target=DATA/f'tl_2024_{code}_roads.zip'
            r=fetch(f'{official}/ROADS/{target.name}',target,
                    source_id='TIGER2024_ROADS_'+code,publisher='US Census Bureau',extension='zip')
            records.append(r)
            atomically_write_json(RECEIPT,{'status':'IN_PROGRESS','sources':records})
            if r['status']!='DOWNLOADED_ORIGINAL_WITH_SHA':raise RuntimeError('OFFICIAL_COUNTY_ALL_ROADS_MISSING_'+code)
    passed=all(r['status']=='DOWNLOADED_ORIGINAL_WITH_SHA' for r in records)
    out={'status':'OPTIONAL_OFFICIAL_CENSUS_ROAD_CROSSCHECK_PASSED' if passed else 'BLOCKED',
         'n_county_road_shapefiles':sum(x['source_id'].startswith('TIGER2024_ROADS_') for x in records),
         'sources':records,'road_use_limitation':'TIGER all roads include car/private roads and cannot serve as legal walk-path graph'}
    atomically_write_json(RECEIPT,out)
    if not passed:raise RuntimeError('STREET_SOURCE_AUDIT_FAILED')
    print(out['status']);return out
if __name__=='__main__':run()
