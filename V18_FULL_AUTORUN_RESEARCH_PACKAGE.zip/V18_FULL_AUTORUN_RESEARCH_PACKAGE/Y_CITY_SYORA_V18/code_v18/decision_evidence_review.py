#!/usr/bin/env python3
"""V18: decision-evidence-to-sentence generator with epistemic boundaries.

Original work: descriptive evidence frontier + normative preference transitions.
The prose is not copied from any external team. It does not certify peer review.
"""
from __future__ import annotations
import csv,json,math
from pathlib import Path
import pandas as pd
from acquire_osm_walk import ROOT,digest
from audit_full_gis import check
OUT=ROOT/'results_v18_gis';PAPER=ROOT/'paper_v18_official_gis';QA=ROOT/'qa_v18';RESEARCH=ROOT/'research'

def fmt_city(s):
    return str(s).replace('&',r'\&').replace('_',r'\_').replace('%',r'\%')

def generate():
    if check()['status']!='PASS':raise RuntimeError('V18_GIS_DATA_SOURCE_AUDIT_MUST_PASS')
    paths={
        'rank':OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv',
        'horizon':OUT/'V18_EVIDENCE_HORIZON.csv',
        'queue':OUT/'V18_TARGETED_EVIDENCE_QUEUE.csv',
        'families':OUT/'V18_DECLARED_PREFERENCE_FAMILIES.csv',
        'transitions':OUT/'V18_EXACT_LEADER_TRANSITIONS.csv',
        'regret':OUT/'V18_CROSS_FAMILY_MINIMAX_REGRET.csv',
        'ablation':OUT/'V18_CONTROLLED_ABLATION.csv',
        'moe':OUT/'V18_ACS_MOE_STRESS_ENVELOPES.csv',
    }
    for n,p in paths.items():
        if not p.is_file():raise FileNotFoundError('MISSING_REAL_SOURCE_FOR_V18_PROSE:'+n)
    d={k:pd.read_csv(v,dtype={'city_geoid':str}) for k,v in paths.items()}
    reference=d['rank'].sort_values('M1_rank').iloc[0];winner=str(reference.city)
    hull=d['horizon'];n_surv=int(hull.not_excluded_by_outer_bound.astype(str).str.lower().eq('true').sum())
    if len(hull)!=12 or len(d['families'])!=48:raise RuntimeError('V18_DECISION_MATRIX_INCOMPLETE')
    leader_envelope=hull.loc[hull.city==winner].iloc[0]
    target=d['queue'].iloc[0];exclusion=d['horizon'][d['horizon'].eliminated_by_verified_outer_bound.astype(str).str.lower()=='true']
    leaders=d['families'][d['families']['rank']==1].sort_values('preference_id')
    family_leaders=', '.join(f"{r.preference_id}: {fmt_city(r.city)}" for r in leaders.itertuples())
    switches=d['transitions'].groupby('preference_id',sort=True).winner.nunique().to_dict()
    changed=sum(x>1 for x in switches.values())
    widest=hull.sort_values(['outer_width','city'],ascending=[False,True]).iloc[0]
    source_sha={name:digest(path) for name,path in paths.items()}
    claims=[
     ('DE01','Research population','observed proxy','rank','12 candidate cities scored using ACS 15--17 proxy; not individual welfare.'),
     ('DE02','Observed-data model reference','model output','rank',f'{winner} is highest in the original reference model with {float(reference.M1_real_walk_20m):.3f}/100.'),
     ('DE03','Outer envelope rather than probability','conditional interval','horizon',f'{n_surv} of 12 cities are not excluded by conservative evidence outer bounds; exclusion is sufficient only inside the stated bound construction.'),
     ('DE04','Unidentified access','model uncertainty','horizon',f'{widest.city} has the widest declared outer score envelope, {widest.outer_width:.2f} points.'),
     ('DE05','Prioritized verification','conditional prospective scenario','queue',f'First proposed audit: {target.verification_kind} in {target.city}, with an upper-bound contribution width of {target.potential_upper_bound_reduction:.2f} points.'),
     ('DE06','Normative priority dependence','non-survey value scenario','families',f'Under analyst-declared priority scenarios, first-ranked cities are {family_leaders}.'),
     ('DE07','Preference transition','exact conditional result','transitions',f'{changed} nonreference preference paths change their leading city at one or more exact linear-utility crossings.'),
     ('DE08','Identification boundary','unidentifiable claim','ablation','Neither road accessibility nor cross-sectional preference experiments establish a causal effect on adolescent outcomes.'),
    ]
    RESEARCH.mkdir(parents=True,exist_ok=True);PAPER.mkdir(parents=True,exist_ok=True);QA.mkdir(parents=True,exist_ok=True)
    reg=RESEARCH/'v18_epistemic_claim_registry.csv'
    with reg.open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['claim_id','research_object','epistemic_class','source_relative_path','source_sha256','claim','claim_ceiling'])
        for cid,obj,kind,src,claim in claims:
            w.writerow([cid,obj,kind,str(paths[src].relative_to(ROOT)),source_sha[src],claim,
                      'MODEL_CONDITIONAL_NOT_CAUSAL' if kind!='unidentifiable claim' else 'DO_NOT_ASSERT_CAUSAL_WELFARE'])
    text=r'''\subsection{Evidence-horizon decision audit}
The frozen twelve-city ranking is a conditional reference, not a population preference survey. We keep the published ACS marginal-MOE endpoint stress and the unverified-OSM-access assumption separate, then form an \emph{outer} score envelope by adding their compatible utility contributions. The rectangular envelope may include physically incompatible combinations; it is deliberately conservative and is \textbf{not} a joint confidence region. Under this declared outer envelope, __NSURV__ of twelve cities remain \emph{not excluded}; excluded cities require their upper bound to lie below another city's lower bound. The widest outer envelope is for __WIDEST__, with width __WIDTH__ points. It is incorrect to treat 'not excluded' as a measured probability of winning. Evidence IDs DE03--DE04 link these claims to the frozen model outputs.

\subsection{Which observation could change our inference?}
Rather than fill uncertain cells with an invented mean, we rank explicit verification tasks by their ability to reduce a score's optimistic bound. The top proposed audit targets __TARGET__ (__KIND__), contributing up to __REDUCTION__ points to the upper-bound uncertainty. This is an \emph{ex ante conditional influence measure}: it does not predict the result of a measurement, its collection cost, or its probability of success. Original source bytes and fresh provenance are still required. The reference conclusion is never improved by deleting an inconvenient uncertain city (DE05).

\subsection{Preference pathways and rank-switch thresholds}
The existing six-component GIS utility vector and the reference weights are left unchanged. We construct three clearly labeled analyst-defined, counterfactual household-priority families; these are neither student AHP responses nor estimates of population preferences. Their leaders are: __LEADERS__. On the affine weight paths from the frozen reference to each family, __CHANGED__ of three paths have an exact winner switch. Each path is evaluated at all pairwise score-line intersections, not at a visually chosen grid interval. These sensitivity calculations show the \emph{domain of applicability} of the reference recommendation rather than identify a universal best city (DE06--DE07).

\noindent\textbf{Scientific boundary.} Greater documented walking access does not by itself establish actual library use, park admission, safety, school enrolment, or causal adolescent wellbeing. The outer bound measures input uncertainty under declared restrictions; the alternate weights measure normative uncertainty. These are not interchangeable estimands (DE08).
'''
    substitutions={'__NSURV__':str(n_surv),'__WIDEST__':fmt_city(widest.city),'__WIDTH__':f'{widest.outer_width:.2f}',
           '__TARGET__':fmt_city(target.city),'__KIND__':fmt_city(target.verification_kind),'__REDUCTION__':f'{target.potential_upper_bound_reduction:.2f}',
           '__LEADERS__':fmt_city(family_leaders),'__CHANGED__':str(changed)}
    for key,v in substitutions.items():text=text.replace(key,v)
    if '__' in text:raise RuntimeError('V18_UNRESOLVED_PAPER_FACT_PLACEHOLDER')
    extension=PAPER/'V18_DECISION_EVIDENCE_ADDITIONS.tex';extension.write_text(text,encoding='utf-8')
    receipt={'status':'V18_EPISTEMIC_AND_DECISION_PROSE_BOUND_TO_ACTUAL_SOURCES','reference_winner':winner,'not_excluded':n_surv,
      'source_sha256':source_sha,'registry_sha256':digest(reg),'extension_tex_sha256':digest(extension),
      'limitations':['Not a probability of being objectively best','No student preference survey','Source evidence cannot establish causal teen outcomes']}
    (QA/'v18_decision_prose_receipt.json').write_text(json.dumps(receipt,indent=2))
    print(json.dumps(receipt,indent=2));return receipt
if __name__=='__main__':generate()
