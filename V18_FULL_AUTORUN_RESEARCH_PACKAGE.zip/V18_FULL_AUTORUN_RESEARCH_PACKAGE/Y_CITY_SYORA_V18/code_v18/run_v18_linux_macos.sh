#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-python3}"
"$PYTHON" -m pip install -r code_v18/requirements_v18.txt
"$PYTHON" code_v18/run_v18.py --stage all --network auto "$@"
