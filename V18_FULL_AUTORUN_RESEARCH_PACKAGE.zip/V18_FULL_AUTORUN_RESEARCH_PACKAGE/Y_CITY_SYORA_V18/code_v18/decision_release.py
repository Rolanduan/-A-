#!/usr/bin/env python3
"""Fail-closed extension gate, invoked before the actual V18 paper build."""
from __future__ import annotations
import json,sys
from pathlib import Path
import pandas as pd
from acquire_osm_walk import ROOT,digest,CITY
from audit_full_gis import check
OUT=ROOT/'results_v18_gis';QA=ROOT/'qa_v18';PAPER=ROOT/'paper_v18_official_gis';FIG=ROOT/'figures/v18_decision_evidence'

def validate():
    issues=[]
    if check()['status']!='PASS':issues.append('OFFICIAL_ORIGINAL_GIS_NOT_ACTUALLY_VERIFIED')
    expected={
     'horizon':OUT/'V18_EVIDENCE_HORIZON.csv',
     'queue':OUT/'V18_TARGETED_EVIDENCE_QUEUE.csv',
     'families':OUT/'V18_DECLARED_PREFERENCE_FAMILIES.csv',
     'transitions':OUT/'V18_EXACT_LEADER_TRANSITIONS.csv',
     'regret':OUT/'V18_CROSS_FAMILY_MINIMAX_REGRET.csv',
     'claims':ROOT/'research/v18_epistemic_claim_registry.csv',
     'tex':PAPER/'V18_DECISION_EVIDENCE_ADDITIONS.tex',
     'frontier_receipt':OUT/'V18_EVIDENCE_HORIZON_RECEIPT.json',
     'preference_receipt':OUT/'V18_PREFERENCE_PATH_RECEIPT.json',
     'claim_receipt':QA/'v18_decision_prose_receipt.json',
     'figures_receipt':FIG/'V18_DECISION_FIGURES_MANIFEST.json',
     'reference_ranking':OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv',
     'official_moe':OUT/'V18_ACS_MOE_STRESS_ENVELOPES.csv',
     'controlled_ablation':OUT/'V18_CONTROLLED_ABLATION.csv',
     'reference_config':ROOT/'config_v18/reference_model_v18.json',
    }
    for key,p in expected.items():
        if not p.is_file():issues.append('MISSING_V18_REPRODUCIBLE_EVIDENCE_'+key)
    if not issues:
        e=pd.read_csv(expected['horizon'],dtype={'city_geoid':str});q=pd.read_csv(expected['queue'],dtype={'city_geoid':str})
        p=pd.read_csv(expected['families']);t=pd.read_csv(expected['transitions']);r=pd.read_csv(expected['regret'])
        if len(e)!=12 or len(q)!=24 or len(p)!=48 or len(r)!=12:issues.append('INCOMPLETE_V18_CITY_EVIDENCE_MATRIX')
        if set(e.city_geoid.str.zfill(7))!=set(CITY):issues.append('CITY_SET_CHANGED')
        if p.groupby('preference_id')['rank'].nunique().ne(12).any():issues.append('INVALID_PREFERENCE_RANK_PERMUTATION')
        if not set(['reference','household_continuity','nearby_public_opportunity','lower_access_safeguard'])==set(p.preference_id):issues.append('UNEXPECTED_PREFERENCE_IDS')
        if len(t)<3:issues.append('MISSING_PREFERENCE_PATHS')
        f=json.loads(expected['frontier_receipt'].read_text());g=json.loads(expected['preference_receipt'].read_text());c=json.loads(expected['claim_receipt'].read_text());a=json.loads(expected['figures_receipt'].read_text())
        for alias,filename in [('rank','reference_ranking'),('moe','official_moe'),('ablation','controlled_ablation')]:
            if f.get('source_sha256',{}).get(alias)!=digest(expected[filename]):issues.append('STALE_INPUT_TO_HORIZON_'+alias)
        if f.get('config_sha256')!=digest(expected['reference_config']):issues.append('STALE_HORIZON_MODEL_CONFIG')
        if g.get('source_ranking_sha256')!=digest(expected['reference_ranking']) or g.get('config_sha256')!=digest(expected['reference_config']):
            issues.append('STALE_PREFERENCE_INPUTS')
        for alias,filename in [('rank','reference_ranking'),('moe','official_moe'),('ablation','controlled_ablation'),('horizon','horizon'),('queue','queue'),('families','families'),('transitions','transitions'),('regret','regret')]:
            if c.get('source_sha256',{}).get(alias)!=digest(expected[filename]):issues.append('STALE_PAPER_EVIDENCE_SOURCE_'+alias)
        if a.get('source_files_sha256',{}).get('horizon')!=digest(expected['horizon']) or a.get('source_files_sha256',{}).get('scenarios')!=digest(expected['families']):
            issues.append('STALE_FIGURE_INPUTS')
        for k,actual in [('frontier_sha256',expected['horizon']),('queue_sha256',expected['queue'])]:
            if f.get(k)!=digest(actual):issues.append('FRONTIER_SHA_MISMATCH_'+k)
        for label,actual in [('scenarios',expected['families']),('transitions',expected['transitions']),('regret',expected['regret'])]:
            if g.get('file_sha256',{}).get(label)!=digest(actual):issues.append('PREFERENCE_SHA_MISMATCH_'+label)
        if c.get('registry_sha256')!=digest(expected['claims']) or c.get('extension_tex_sha256')!=digest(expected['tex']):issues.append('PROSE_CLAIM_SHA_MISMATCH')
        figures=a.get('figures',[])
        if len(figures)!=6:issues.append('V18_TWO_FIGURES_IN_THREE_FORMATS_EXPECTED')
        for item in figures:
            path=ROOT/item['path']
            if not path.is_file() or digest(path)!=item['sha256']:issues.append('V18_FIGURE_HASH_MISMATCH')
        if (e.eliminated_by_verified_outer_bound.astype(str).str.lower()=='true').all():issues.append('NO_CANDIDATE_LEFT_CONTRADICTORY_BOUNDS')
    result={'status':'PASS_V18_DECISION_EVIDENCE_GATE' if not issues else 'BLOCKED_FOR_V18_GIS_PAPER',
            'issues':issues,'checked_paths':{k:str(p) for k,p in expected.items()},
            'interpretation':'Technical integration and frozen hash audit only; not external youth validity or human scientific acceptance.'}
    QA.mkdir(parents=True,exist_ok=True)
    (QA/'v18_decision_release_gate.json').write_text(json.dumps(result,indent=2))
    return result
if __name__=='__main__':
    outcome=validate();print(json.dumps(outcome,indent=2));raise SystemExit(0 if outcome['status'].startswith('PASS_') else 3)
