#!/usr/bin/env python3
"""V18 source-backed, results-first prose and executable claim/equation audit trail.

Quantitative paragraphs are generated ONLY from witnessed final CSV/receipts.
This is not a replacement for human scientific editing or field validation.
"""
from __future__ import annotations
import csv,json,math
from pathlib import Path
import pandas as pd
from acquire_osm_walk import ROOT,digest,CITY

OUT=ROOT/'results_v18_gis';QA=ROOT/'qa_v18';RESEARCH=ROOT/'research'


def safe(s):
    text=str(s)
    for x,y in [('&',r'\&'),('%',r'\%'),('_',r'\_'),('$',r'\$'),('#',r'\#')]:text=text.replace(x,y)
    return text


def verified_inputs():
    files={'ranking':OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv',
           'ablation':OUT/'V18_CONTROLLED_ABLATION.csv',
           'lp':OUT/'V18_PARETO_LP_MINIMAX_REGRET.csv',
           'stress':OUT/'V18_REAL_OD_ACCESS_SPEED_MISSINGNESS_STRESS.csv',
           'imls':OUT/'V18_IMLS_OSM_INDEPENDENT_COVERAGE.csv',
           'raw_replay':QA/'independent_raw_osm_replay.json',
           'demography':ROOT/'data/processed/v18_gis/official_tract_origins_v18.csv'}
    missing=[k for k,p in files.items() if not p.is_file()]
    if missing:raise FileNotFoundError('MISSING_ACTUAL_RESEARCH_CLAIM_INPUTS:'+','.join(missing))
    data={}
    for name,path in files.items():
        if name=='raw_replay':
            v=json.loads(path.read_text())
            if v.get('status')!='PASS_12_CITIES_RAW_SOURCE_NETWORK_REPLAY':raise ValueError('RAW_SOURCE_REBUILD_NOT_PASSED')
            data[name]=v
        else:data[name]=pd.read_csv(path,dtype={'city_geoid':str})
    for n in ('ranking','ablation','lp','imls'):
        if len(data[n])!=12:raise ValueError('NOT_TWELVE_CITY_'+n)
    for n in ('ranking','ablation','imls'):
        if set(data[n].city_geoid.str.zfill(7))!=set(CITY):raise ValueError('CITY_SET_DIFFERS_'+n)
    if len(data['stress'])!=216:raise ValueError('STRESS_GRID_MUST_BE_18x12')
    data['files']=files
    return data


def generate():
    data=verified_inputs()
    rank=data['ranking'].sort_values('M1_rank');abl=data['ablation'];lp=data['lp'];stress=data['stress'];imls=data['imls']
    first=rank.iloc[0];city=first.city
    counterpart=abl.loc[(abl.spatial_mechanism_change).abs().idxmax()]
    bound_city=abl.loc[abl.unknown_access_span.idxmax()]
    worst=imls.loc[imls.imls_coverage_fraction.idxmin()]
    lpcity=lp.loc[lp.city==city].iloc[0]
    top_all=(stress.loc[stress['rank']==1].groupby('city').size().to_dict())
    span=float(abl.unknown_access_span.max())
    raw=data['raw_replay']['cities']
    tested=sum(x.get('tested',0) for x in raw.values())
    if tested<120:raise ValueError('INSUFFICIENT_INDEPENDENT_RAW_OSM_ROUTE_PROBES')
    total_youth=float(data['demography']['estimated_youth_15_17'].astype(float).sum())
    observed_match=int(imls.one_to_one_matches.sum());official_total=int(imls.imls_outlets.sum());osm_total=int(imls.osm_candidate_libraries.sum())
    claims=[
        ('V18C01','12-city conditional reference ranking','ranking',f'{city} ranked first with {first.M1_real_walk_20m:.2f}/100.'),
        ('V18C02','Same-facility road geometry mechanism','ablation',f'{counterpart.city} differs by {counterpart.spatial_mechanism_change:+.2f} points between Euclidean and route means with the same facilities.'),
        ('V18C03','Unknown access bound','ablation',f'{bound_city.city} shows the widest unknown-access upper-bound score interval of {span:.2f} points.'),
        ('V18C04','Original-road independent routing sample','raw_replay',f'{tested} independently re-routed OSM-node OD records across 12 cities passed source rebuilding checks.'),
        ('V18C05','Independent IMLS coverage','imls',f'{observed_match} matched outlet candidates of {official_total} IMLS and {osm_total} OSM candidate outlets in the scoped city polygons.'),
        ('V18C06','Robust LP preference region','lp',f'{city} max regret = {lpcity.maximum_regret_over_weights:.3f} over declared weight constraints.'),
        ('V18C07','Road/access/missingness stress','stress',f'{city} ranks first in {top_all.get(city,0)} of 18 explicitly specified stress cases.'),
        ('V18C08','Study population proxy','demography',f'The area-interpolated tract-based proxy is {total_youth:,.0f} persons aged 15-17 summed across selected cities; not observed individual addresses.')]
    header=['claim_id','research_question','actual_source_file','source_sha256','claim_text','status','paper_section']
    RESEARCH.mkdir(exist_ok=True,parents=True)
    with (RESEARCH/'v18_claim_evidence_registry.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(header)
        for cid,q,src,claim in claims:
            w.writerow([cid,q,str(data['files'][src].relative_to(ROOT)),digest(data['files'][src]),claim,
                        'REAL_COMPUTED_SOURCE_BOUND','Model and Solution / Analysis of Work'])
    # Bound to exact supported rows; finite stress is not a confidence interval.
    prose=r'''\subsection{Controlled same-facility revision experiment}
The initial household-only $M_0$ is \emph{not} a facility inventory. We therefore introduce an explicit
inventory-only baseline on the same OSM-tagged public candidate set, compare it with a straight-line
proxy, then calculate directed street-network reachability and finally add a population-weighted
lower-decile equity component. This separates introducing a new domain from changing its spatial
measurement. The largest observed straight-line-to-network score contrast was __ABLCITY__
(__ABLDIFF__ points). This is a mechanical comparison under stated distances, not proof of higher
predictive validity (claim V18C02).\\
\noindent\textbf{Unverified access.} The reference admits only OSM-tagged public candidates, not
unknown-access candidates. In __BOUNDCITY__, adding the unknown-access candidates under an
optimistic upper-bound assumption changes the reference by as much as __BOUND__ points;
this is an assumption interval, not an empirical admission probability (V18C03).

\subsection{Independent raw-source and government-outlet checks}
A separate route audit reconstructed source ways/nodes from original Overpass responses or
re-parsed Geofabrik PBF records and checked __ROUTES__ sampled origin--destination paths
against the production routing results. The audit is at the original-route level and does not
validate entrances (V18C04). Independently, the FY2024 IMLS public library outlet directory
matched __IMLSMATCH__ outlet candidates across the twelve city scopes. OSM had __OSMOUT__
scoped candidate-library records; the official comparator had __IMLSOUT__ outlet records
(V18C05). In the weakest IMLS spatial-coverage city, __IMLSWORST__, this independent
coverage diagnostic cautions against interpreting OSM absence as no public service.

\subsection{Pareto, exact preference-weight LP, and adversarial cases}
For an explicit six-component utility vector (three Census environment dimensions, library
and park accessibility, and the lower-decile opportunity), a linear program minimizes each
city-pair weighted margin across $w_d\in[0.03,0.40]$ and $\sum_d w_d=1$.
The conditional reference leader __CHAMP__ has maximum regret __MAXREGRET__ over that
preference region; its robust-first rank over the entire declared polytope is __ROBUST__.
Pareto non-dominance is __PARETO__. None of these calculations makes a normative weight
choice an experimentally measured youth preference (V18C06).

\subsection{Road and evidence-uncertainty counterexamples}
The measured route lengths were re-scored under three walking speeds, three hypothetical
observed-POI deletion fractions, and two transparent treatments of unverified access,
for eighteen full twelve-city stress cases. __CHAMP__ leads __STRESSCOUNT__ of eighteen.
Deletion fractions are predeclared adversarial scenarios, \emph{not} measured failure rates.
Any reported champion flip is a real result of the stated algorithm under changed assumptions,
not a frequentist confidence probability (V18C07).
'''
    repl={'__ABLCITY__':safe(counterpart.city),'__ABLDIFF__':f'{counterpart.spatial_mechanism_change:+.2f}',
        '__BOUNDCITY__':safe(bound_city.city),'__BOUND__':f'{span:.2f}',
        '__ROUTES__':str(tested),'__IMLSMATCH__':str(observed_match),'__IMLSOUT__':str(official_total),
        '__OSMOUT__':str(osm_total),'__IMLSWORST__':safe(worst.city),'__CHAMP__':safe(city),
        '__MAXREGRET__':f'{lpcity.maximum_regret_over_weights:.3f}',
        '__ROBUST__':str(bool(lpcity.robust_rank_one_entire_polytope)).lower(),
        '__PARETO__':str(bool(lpcity.pareto_non_dominated)).lower(),
        '__STRESSCOUNT__':str(top_all.get(city,0))}
    for k,v in repl.items():prose=prose.replace(k,v)
    paper=ROOT/'paper_v18_official_gis';paper.mkdir(exist_ok=True)
    (paper/'V18_EMPIRICAL_EVIDENCE_ADDITIONS.tex').write_text(prose)
    equations=[
      ('E01','M0 household score','score_official_gis.py::u_acscity','tests_v18/test_v18_critical_gates.py','0..100','Census city'),
      ('E02','OSM travel kernel','access_policy.py::opportunity_at_distance','tests_v18/test_v18_critical_gates.py','dimensionless','observed OD metres'),
      ('E03','population weighted access','model_ablation.py::score_model','tests_v18/test_v18_recovery.py','0..1','ACS tract proxy'),
      ('E04','weighted lower decile','acquire_osm_walk.py::weighted_quantile','tests_v18/test_v18_recovery.py','0..1','tract proxy'),
      ('E05','preference polytope','robustness_lp.py::polytope_extreme','tests_v18/test_v18_recovery.py','utility-score','declared bounds'),
      ('E06','access uncertainty bounds','access_policy.py::bounds','tests_v18/test_v18_recovery.py','0/1 or interval','OSM access tag')]
    with (RESEARCH/'v18_equation_contracts.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['equation_id','definition','implementation','test','range_unit','evidence_origin'])
        w.writerows(equations)
    manifest={'status':'V18_SCIENTIFIC_CLAIMS_BOUND_TO_COMPUTED_SOURCES','n_claims':len(claims),
      'registry_sha256':digest(RESEARCH/'v18_claim_evidence_registry.csv'),
      'raw_ranking_sha256':digest(data['files']['ranking']),
      'generated_prose_sha256':digest(paper/'V18_EMPIRICAL_EVIDENCE_ADDITIONS.tex'),
      'scope_limits':['No external youth-outcome causal validation','OSM tags are not legally certified entry','Raw-route replay samples are a finite validation subset']}
    (RESEARCH/'V18_PAPER_CLAIM_EVIDENCE_RECEIPT.json').write_text(json.dumps(manifest,indent=2))
    return paper/'V18_EMPIRICAL_EVIDENCE_ADDITIONS.tex'

if __name__=='__main__':generate()
