#!/usr/bin/env python3
"""28 mandatory original 2024 Census inputs, honest SHA256 + provenance manifest.
12 state PLACE ZIP + 12 state TRACT ZIP + 4 ACS whole-table DAT.
Only official www2.census.gov endpoints are treated as direct official original source.
"""
from __future__ import annotations
import argparse,csv,datetime as dt,json,os,shutil,sys,urllib.parse
from pathlib import Path
from fetch_verified import atomically_write_json,fetch,validate_bytes,sha256_file
ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'data/raw_official/v18'
MANIFEST=ROOT/'qa_v18/census_original_manifest.json'
CITIES={'4805000':'Austin','2507000':'Boston','1714000':'Chicago','0820000':'Denver',
        '5548000':'Madison','2743000':'Minneapolis','4261000':'Pittsburgh',
        '4159000':'Portland','3755000':'Raleigh','0666000':'San Diego',
        '5363000':'Seattle','1304000':'Atlanta'}
STATES=sorted({g[:2] for g in CITIES})
TABLES=('B01001','B25070','B28002','B17001')
CENSUS_ACS_ROOT='https://www2.census.gov/programs-surveys/acs/summary_file/2024/table-based-SF/data/5YRData'
CENSUS_GEO_ROOT='https://www2.census.gov/geo/tiger/TIGER2024'

def specs():
    q=[]
    for table in TABLES:
        f=f'acs_2024_5y_{table}.dat'
        q.append(dict(source_id='ACS_'+table, url=f'{CENSUS_ACS_ROOT}/acsdt5y2024-{table.lower()}.dat',
                      filename=f,ext='dat',source_kind='OFFICIAL_CENSUS_ACS_2024_5Y_WHOLE_TABLE'))
    for state in STATES:
        for layer in ('PLACE','TRACT'):
            f=f'tl_2024_{state}_{layer.lower()}.zip'
            q.append(dict(source_id=f'TIGER2024_{layer}_{state}',url=f'{CENSUS_GEO_ROOT}/{layer}/{f}',
                          filename=f,ext='zip',source_kind='OFFICIAL_CENSUS_TIGER2024'))
    assert len(q)==28
    return q

def scan_acs(raw,table):
    import csv
    cities=set();tracts=0;errors=[]
    with Path(raw).open(encoding='utf-8-sig',errors='strict',newline='') as f:
        reader=csv.DictReader(f,delimiter='|')
        cols={a.upper().strip():a for a in reader.fieldnames or []}
        required={'GEO_ID'}
        required |= {'B01001_E006','B01001_E030'} if table=='B01001' else set()
        required |= {'B25070_E001','B25070_E011'} if table=='B25070' else set()
        required |= {'B28002_E001','B28002_E004'} if table=='B28002' else set()
        required |= {'B17001_E001','B17001_E002'} if table=='B17001' else set()
        if not required.issubset(cols):raise ValueError('MISSING_COLUMNS:'+str(required-set(cols)))
        for row in reader:
            geoid=row[cols['GEO_ID']].strip()
            if geoid.startswith('1600000US') and geoid[9:] in CITIES:cities.add(geoid[9:])
            if table=='B01001' and geoid.startswith('1400000US'):
                if geoid[9:11] in STATES:tracts+=1
    if cities!=set(CITIES):raise ValueError('CENSUS_NOT_12_CITIES:'+str(sorted(set(CITIES)-cities)))
    if table=='B01001' and tracts<1000:raise ValueError('TRACT_COVERAGE_IMPLAUSIBLY_SMALL:'+str(tracts))
    return {'city_count':len(cities),'tract_count_in_sample_states':tracts,'schema':'PASS'}

def export_city_subset(raw,table):
    """Exactly twelve normalized city observations extracted from original full-table bytes."""
    target=ROOT/f'data/processed/v18_official_acs/ACS_{table}_12_cities.psv'
    target.parent.mkdir(parents=True,exist_ok=True)
    tmp=target.with_suffix('.tmp')
    count=0
    with Path(raw).open(encoding='utf-8-sig',errors='strict',newline='') as f, tmp.open('w',encoding='utf-8',newline='') as out:
        r=csv.DictReader(f,delimiter='|')
        writer=csv.DictWriter(out,fieldnames=r.fieldnames,delimiter='|')
        writer.writeheader()
        for row in r:
            geoid=row.get('GEO_ID','')
            if geoid.startswith('1600000US') and geoid[9:] in CITIES:
                writer.writerow(row);count+=1
    if count!=12:
        tmp.unlink(missing_ok=True)
        raise ValueError('NOT_EXACTLY_12_CITY_ROWS_FOR_'+table)
    os.replace(tmp,target)
    return {'city_rows':count,'derived_path':str(target),'derived_sha256':sha256_file(target)}

def download_all(*, import_dir=None, attestation_dir=None, allow_human_attested=False,
                 require_official_provenance=True, stop_after_first_failure=False):
    RAW.mkdir(parents=True,exist_ok=True);MANIFEST.parent.mkdir(parents=True,exist_ok=True)
    records=[];prior={}
    if MANIFEST.exists():
        try:prior={r['source_id']:r for r in json.loads(MANIFEST.read_text())['sources']}
        except Exception:prior={}
    imported=Path(import_dir) if import_dir else None
    attest_dir=Path(attestation_dir) if attestation_dir else None
    for spec in specs():
        target=RAW/spec['filename'];pre=prior.get(spec['source_id'])
        if pre and target.exists() and sha256_file(target)==pre.get('sha256') and pre.get('origin_verification') in ('DIRECT_TLS_SOURCE','INHERITED_DIRECT_TLS_SOURCE'):
            rec=dict(pre);rec['verified_at_utc']=dt.datetime.now(dt.timezone.utc).isoformat()
        else:
            if imported and (imported/spec['filename']).is_file() and not target.exists():
                # Local byte import is not independently proven to have come from the official server.
                # Ingest and hash, but quarantine unverified origin until a trusted origin receipt exists.
                shutil.copy2(imported/spec['filename'],target)
            if target.exists():
                try:
                    meta=validate_bytes(target,spec['ext'])
                    rec={**spec,**meta,'status':'DOWNLOADED_ORIGINAL_WITH_SHA',
                         'path':str(target),'origin_verification':'UNVERIFIED_MANUAL_OR_PREEXISTING_FILE',
                         'error':'Source origin needs directly obtained official TLS receipt or independent publisher checksum'}
                except Exception:
                    target.unlink(missing_ok=True)
                    rec=fetch(spec['url'],target,source_id=spec['source_id'],publisher='US Census Bureau',extension=spec['ext'])
            else: rec=fetch(spec['url'],target,source_id=spec['source_id'],publisher='US Census Bureau',extension=spec['ext'])
        rec.setdefault('original_url',spec['url']);rec.setdefault('source_kind',spec['source_kind'])
        if rec.get('status')=='DOWNLOADED_ORIGINAL_WITH_SHA':
            try:
                if spec['ext']=='dat':
                    rec['semantic_qa']=scan_acs(target,spec['source_id'][4:])
                    rec['derived_city_subset']=export_city_subset(target,spec['source_id'][4:])
                else:
                    import zipfile
                    with zipfile.ZipFile(target) as z:
                        names=z.namelist()
                        if not any(n.lower().endswith('.shp') for n in names):raise ValueError('NO_SHP')
                        rec['semantic_qa']={'zip_members':len(names),'schema':'PASS_SHAPEFILE_PRESENT'}
            except Exception as e:
                rec['status']='SCHEMA_REJECTED';rec['schema_error']=repr(e)
        if attest_dir and rec.get('status')=='DOWNLOADED_ORIGINAL_WITH_SHA' and rec.get('origin_verification') not in ('DIRECT_TLS_SOURCE','INHERITED_DIRECT_TLS_SOURCE'):
            witness=attest_dir/(spec['source_id']+'.json')
            if witness.is_file():
                try:
                    proof=json.loads(witness.read_text())
                    if (proof.get('sha256')==rec.get('sha256') and
                        proof.get('exact_download_url')==spec['url'] and
                        proof.get('confirmed_direct_https_download') is True and
                        len(str(proof.get('human_reviewed_by','')).strip())>=2):
                        rec['origin_verification']='HUMAN_ATTESTED_OFFICIAL_TLS'
                        rec['human_attestation_sha256']=sha256_file(witness)
                except Exception as e:rec['attestation_error']=repr(e)
        accepted={'DIRECT_TLS_SOURCE','INHERITED_DIRECT_TLS_SOURCE'}
        if allow_human_attested:accepted.add('HUMAN_ATTESTED_OFFICIAL_TLS')
        if require_official_provenance and rec.get('origin_verification') not in accepted:
            rec['release_eligible']=False
        else:rec['release_eligible']=rec.get('status')=='DOWNLOADED_ORIGINAL_WITH_SHA' and rec.get('semantic_qa',{}).get('schema','').startswith('PASS')
        records.append(rec)
        atomically_write_json(MANIFEST,{'version':'V18','required':28,'as_of_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'sources':records,'all_pass':False})
        print(spec['source_id'],rec.get('status'),rec.get('release_eligible'),flush=True)
        if stop_after_first_failure and not rec['release_eligible']:break
    allpass=len(records)==28 and all(r['release_eligible'] for r in records)
    atomically_write_json(MANIFEST,{'version':'V18','required':28,'sources':records,'all_pass':allpass})
    if not allpass:raise RuntimeError('CENSUS_28_ORIGINALS_NOT_VERIFIED: see '+str(MANIFEST))
    return records

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--import-dir',help='User-downloaded original files; source provenance must be verified separately')
    ap.add_argument('--allow-attested-origin',action='store_true',help='Explicit human signoff for individually SHA-matched official-URL attestations, human review still required')
    ap.add_argument('--attestation-dir',help='JSON file per original source_id with exact URL, sha, and human signature')
    ap.add_argument('--fail-fast',action='store_true')
    a=ap.parse_args()
    download_all(import_dir=a.import_dir,attestation_dir=a.attestation_dir,allow_human_attested=a.allow_attested_origin,stop_after_first_failure=a.fail_fast)
