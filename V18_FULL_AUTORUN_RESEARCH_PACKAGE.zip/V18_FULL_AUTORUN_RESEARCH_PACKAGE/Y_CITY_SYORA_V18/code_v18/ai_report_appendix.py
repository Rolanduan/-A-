#!/usr/bin/env python3
"""Actual AI-use ledger -> separate, appended disclosure; never invent prompts.
The solution length cap applies before the AI appendix, not to the combined PDF.
"""
from __future__ import annotations
import csv,hashlib,json,subprocess
from pathlib import Path
import fitz
from acquire_osm_walk import ROOT,digest

PAPER=ROOT/'paper_v18_official_gis'
LEDGER=ROOT/'sources/ai_tool_use_ledger.csv'
PROMPTS=ROOT/'sources/ai_prompt_execution_log.csv'

def latex_escape(s):
    x=str(s)
    for a,b in [('&',r'\&'),('_',r'\_'),('%',r'\%'),('#',r'\#'),('$',r'\$')]:x=x.replace(a,b)
    return x

def read_csv(p):
    if not p.exists():raise FileNotFoundError('Actual-use source ledger missing: '+str(p))
    with p.open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))

def generate(solution_pdf):
    uses=read_csv(LEDGER);prompts=read_csv(PROMPTS)
    if not uses:raise ValueError('AI_USE_LEDGER_EMPTY_BUT_AI_USED_IN_AUTHORING')
    if not prompts:raise ValueError('AI_PROMPT_EXECUTION_LOG_EMPTY_COMPLETE_DISCLOSURE_BLOCKED')
    for p in prompts:
        for k in ('prompt_id','tool_name','date_utc','purpose','actual_prompt_or_loss_note','human_verified'):
            if not p.get(k):raise ValueError('INCOMPLETE_ACTUAL_AI_PROMPT_LOG_FIELD_'+k)
        if p['human_verified'].strip().lower()!='true':
            raise ValueError('AI_PROMPT_LOG_NEEDS_HUMAN_VERIFICATION')
    rows='\n'.join(r'\item '+latex_escape(x['provider']+' / '+x['tool_name']+' / '+x['model_version']+': '+x['used_for']+' ('+x['access_date']+')') for x in uses)
    excerpts='\n'.join(r'\item '+latex_escape(p['prompt_id']+': '+p['purpose']+'. Actual recorded instruction or scope: '+p['actual_prompt_or_loss_note']) for p in prompts)
    tex=r'''\documentclass[12pt,letterpaper]{article}
\usepackage[margin=.85in]{geometry}
\usepackage[T1]{fontenc}
\usepackage{lmodern,microtype}
\begin{document}
\begin{center}{\Large\bfseries Report on Use of AI Tools}\\
Independent research disclosure -- after solution, outside the 25-page solution limit\end{center}
\section*{Tools and actual purposes}
\begin{itemize}
__USES__
\end{itemize}
\section*{Prompt and use ledger}
\begin{itemize}
__PROMPTS__
\end{itemize}
\section*{Limitations}
The recorded log represents the actual uses attested by the operator. Missing or lost
historical prompts must be identified honestly in the ledger, never reconstructed as verbatim.
AI-assisted code and prose are subject to independent numerical and source verification.
This does not represent any human peer review, contest compliance approval or submitted entry.
\end{document}
'''.replace('__USES__',rows).replace('__PROMPTS__',excerpts)
    PAPER.mkdir(parents=True,exist_ok=True)
    path=PAPER/'V18_REPORT_ON_USE_OF_AI.tex';path.write_text(tex)
    run=subprocess.run(['latexmk','-pdf','-interaction=nonstopmode','-halt-on-error',path.name],
                      cwd=PAPER,capture_output=True,text=True)
    (PAPER/'ai_report_compile.log').write_text(run.stdout+'\n'+run.stderr)
    if run.returncode:raise RuntimeError('AI_DISCLOSURE_LATEX_FAILED:'+run.stdout[-900:])
    ai_pdf=path.with_suffix('.pdf')
    solution=Path(solution_pdf)
    combined=PAPER/'V18_EMPIRICAL_YOUTH_CITY_NETWORK_RESEARCH.pdf'
    with fitz.open(solution) as a,fitz.open(ai_pdf) as b:
        if len(a)>25:raise ValueError('SOLUTION_EXCEEDS_25_PAGES_EXCLUDING_AI')
        original_pages=len(a)
        a.insert_pdf(b)
        a.save(combined,garbage=4,deflate=True)
        after=len(a)
    meta={'status':'AI_REPORT_APPENDED_AFTER_SOLUTION','solution_pages':original_pages,
          'ai_appendix_pages':after-original_pages,'combined_pages':after,
          'combined_sha256':digest(combined),'solution_sha256':digest(solution),
          'ai_report_sha256':digest(ai_pdf),'actual_ledger_sha256':digest(LEDGER),
          'actual_prompt_log_sha256':digest(PROMPTS)}
    (PAPER/'V18_AI_DISCLOSURE_BUILD.json').write_text(json.dumps(meta,indent=2))
    return combined,meta
