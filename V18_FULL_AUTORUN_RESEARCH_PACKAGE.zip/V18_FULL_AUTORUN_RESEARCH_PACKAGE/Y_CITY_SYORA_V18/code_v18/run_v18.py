#!/usr/bin/env python3
"""Single command; reproducible twelve-city REAL data run with closed release gates.
No current execution claims are made by the existence of this script.
"""
from __future__ import annotations
import argparse,datetime as dt,hashlib,json,os,subprocess,sys,traceback
from pathlib import Path
from fetch_verified import atomically_write_json,sha256_file
from acquire_census import CITIES,download_all
ROOT=Path(__file__).resolve().parents[1]
QA=ROOT/'qa_v18'
QA.mkdir(parents=True,exist_ok=True)
SCRIPT=ROOT/'code_v18'
STAGES=['tests','environment','official_summary','census','geography','networks','osm_temporal','score','audit','independent_replay','raw_network_replay','controlled_ablation','sensitivity','uncertainty','evidence_frontier','systems','external_imls','robustness_lp','preference_paths','route_stress','edge_failure','figures','atlas','multicity_maps','decision_figures','evidence_review','decision_gate','paper','release','package']


def run_cmd(label,args, *, env=None):
    print('\n###',label,' '.join(map(str,args)),flush=True)
    logfile=QA/('phase_'+label+'.log')
    completed=subprocess.run(args,cwd=ROOT,env=env,capture_output=True,text=True)
    logfile.write_text(completed.stdout+'\n--- STDERR ---\n'+completed.stderr,encoding='utf-8')
    print(completed.stdout[-1600:],flush=True)
    if completed.returncode:
        print(completed.stderr[-2500:],flush=True)
        raise RuntimeError(label+' FAILED exit '+str(completed.returncode)+'; see '+str(logfile))

def valid_network(geoid):
    receipt=ROOT/f'data/processed/v18_network/receipt_{geoid}.json'
    if not receipt.is_file():return False
    r=json.loads(receipt.read_text())
    if r.get('status')!='REAL_OSM_NETWORK_ACQUIRED_AND_GRAPH_ROUTED':return False
    raw=ROOT/r.get('real_osm_graph_file','')
    if not raw.is_file() or sha256_file(raw)!=r.get('graph_sha256'):return False
    if r.get('source_kind')=='RAW_GEOFABRIK_PBF':
        p=Path(r['source_pbf_path']);return p.is_file() and sha256_file(p)==r.get('source_pbf_sha256')
    cache=r.get('original_overpass_cached_response_files',[])
    return bool(cache) and all((ROOT/p['path']).is_file() and sha256_file(ROOT/p['path'])==p['sha256'] for p in cache)


def phase(stage,options,env):
    if stage=='tests':
        run_cmd('tests',[sys.executable,'-m','pytest','-q','tests_v18'],env=env)
    elif stage=='environment':run_cmd(stage,[sys.executable,str(SCRIPT/'environment_provenance.py')],env=env)
    elif stage=='official_summary':
        run_cmd(stage,[sys.executable,'-c','from official_summary import acquire; print(acquire())'],env=env)
    elif stage=='census':
        download_all(import_dir=options.import_dir,attestation_dir=options.attestation_dir,allow_human_attested=options.allow_attested_origin)
    elif stage=='census_streets':run_cmd(stage,[sys.executable,str(SCRIPT/'acquire_tiger_roads.py')],env=env)
    elif stage=='geography':
        run_cmd(stage,[sys.executable,str(SCRIPT/'prepare_tiger_acs_origins.py')],env=env)
    elif stage=='networks':
        for geoid,city in CITIES.items():
            if not options.force_network and valid_network(geoid):
                print('VERIFIED_EXISTING_GRAPH',city);continue
            errors=[]
            choices=['overpass','geofabrik'] if options.network=='auto' else [options.network]
            for source in choices:
                try:
                    if source=='overpass':
                        run_cmd('network_'+geoid+'_overpass',
                                [sys.executable,str(SCRIPT/'network_overpass.py'),'--city',geoid,'--max-dist-m','3500'],env=env)
                    else:run_cmd('network_'+geoid+'_geofabrik',
                                 [sys.executable,str(SCRIPT/'network_geofabrik.py'),'--city',geoid],env=env)
                    if not valid_network(geoid):raise RuntimeError('Downloaded network failed SHA provenance verification')
                    break
                except Exception as e:
                    errors.append(str(e))
                    print('NETWORK_ALTERNATIVE_FAILED:',city,source,str(e),flush=True)
            else:raise RuntimeError('ALL_REAL_OSM_SOURCES_FAILED_'+city+' '+str(errors))
    elif stage=='osm_temporal':run_cmd(stage,[sys.executable,str(SCRIPT/'source_temporal_audit.py')],env=env)
    elif stage=='score':run_cmd(stage,[sys.executable,str(SCRIPT/'score_official_gis.py')],env=env)
    elif stage=='audit':run_cmd(stage,[sys.executable,str(SCRIPT/'audit_full_gis.py')],env=env)
    elif stage=='independent_replay':run_cmd(stage,[sys.executable,str(SCRIPT/'independent_replay.py')],env=env)
    elif stage=='raw_network_replay':run_cmd(stage,[sys.executable,str(SCRIPT/'replay_raw_network.py')],env=env)
    elif stage=='controlled_ablation':run_cmd(stage,[sys.executable,str(SCRIPT/'model_ablation.py')],env=env)
    elif stage=='sensitivity':run_cmd(stage,[sys.executable,str(SCRIPT/'sensitivity_official_gis.py')],env=env)
    elif stage=='uncertainty':run_cmd(stage,[sys.executable,str(SCRIPT/'uncertainty_envelopes.py')],env=env)
    elif stage=='evidence_frontier':run_cmd(stage,[sys.executable,str(SCRIPT/'evidence_frontier.py')],env=env)
    elif stage=='systems':run_cmd(stage,[sys.executable,str(SCRIPT/'systems_hypothesis_tests.py')],env=env)
    elif stage=='external_imls':run_cmd(stage,[sys.executable,str(SCRIPT/'external_imls_validation.py')],env=env)
    elif stage=='robustness_lp':run_cmd(stage,[sys.executable,str(SCRIPT/'robustness_lp.py')],env=env)
    elif stage=='preference_paths':run_cmd(stage,[sys.executable,str(SCRIPT/'preference_paths.py')],env=env)
    elif stage=='route_stress':run_cmd(stage,[sys.executable,str(SCRIPT/'stress_real_routes.py')],env=env)
    elif stage=='edge_failure':run_cmd(stage,[sys.executable,str(SCRIPT/'edge_failure_stress.py')],env=env)
    elif stage=='figures':run_cmd(stage,[sys.executable,str(SCRIPT/'render_real_gis_figures.py')],env=env)
    elif stage=='atlas':run_cmd(stage,[sys.executable,str(SCRIPT/'render_atlas.py')],env=env)
    elif stage=='multicity_maps':run_cmd(stage,[sys.executable,str(SCRIPT/'render_city_atlas_v18.py')],env=env)
    elif stage=='decision_figures':run_cmd(stage,[sys.executable,str(SCRIPT/'decision_atlas.py')],env=env)
    elif stage=='evidence_review':run_cmd(stage,[sys.executable,str(SCRIPT/'decision_evidence_review.py')],env=env)
    elif stage=='decision_gate':run_cmd(stage,[sys.executable,str(SCRIPT/'decision_release.py')],env=env)
    elif stage=='paper':run_cmd(stage,[sys.executable,str(SCRIPT/'build_empirical_gis_paper.py')],env=env)
    elif stage=='release':run_cmd(stage,[sys.executable,str(SCRIPT/'release_audit.py')],env=env)
    elif stage=='package':run_cmd(stage,[sys.executable,str(SCRIPT/'package_evidence.py')],env=env)
    else:raise ValueError(stage)


def main():
    ap=argparse.ArgumentParser(description='V18 full twelve-city official-Census + OSM live execution')
    ap.add_argument('--stage',choices=['all','census_streets']+STAGES,default='all')
    ap.add_argument('--network',choices=['auto','overpass','geofabrik'],default='auto')
    ap.add_argument('--import-dir',default=None,help='Directory of manually obtained original files; cannot certify origin from a filename')
    ap.add_argument('--force-network',action='store_true')
    ap.add_argument('--attestation-dir',default=None)
    ap.add_argument('--allow-attested-origin',action='store_true')
    ap.add_argument('--dry-run',action='store_true')
    opts=ap.parse_args()
    stages=STAGES if opts.stage=='all' else [opts.stage]
    env=os.environ.copy()
    if opts.import_dir:env.setdefault('V18_OSM_IMPORT_DIR',opts.import_dir)
    if opts.attestation_dir:env.setdefault('V18_OSM_ATTEST_DIR',opts.attestation_dir)
    env['PYTHONPATH']=os.pathsep.join([str(SCRIPT),env.get('PYTHONPATH','')])
    state={'version':'V18','run_started_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
           'requested_stages':stages,'run_state':'RUNNING','phase_states':{},'principal_outputs':{},
           'caveats':['V18 script presence alone is not execution','No real-data ranking without 28 raw Census and 12 real OSM networks']}
    state_file=QA/'v18_execution_state.json'
    atomically_write_json(state_file,state)
    if opts.dry_run:
        state.update(run_state='DRY_RUN_ONLY',phase_states={k:'NOT_EXECUTED' for k in stages})
        atomically_write_json(state_file,state)
        print('DRY RUN:',' -> '.join(stages),'network=',opts.network)
        return 0
    for step in stages:
        try:
            phase(step,opts,env)
            state['phase_states'][step]='PASS_REAL_ACTION_DONE'
        except Exception as exc:
            state['phase_states'][step]={'status':'FAILED','error':repr(exc)}
            state['run_state']='BLOCKED_FOR_FINAL_GIS_PAPER'
            state['run_completed_utc']=dt.datetime.now(dt.timezone.utc).isoformat()
            atomically_write_json(state_file,state)
            print(traceback.format_exc(),file=sys.stderr)
            return 3
        atomically_write_json(state_file,state)
    state['run_state']='PIPELINE_EXECUTED_NEEDS_HUMAN_SCIENTIFIC_REVIEW'
    state['run_completed_utc']=dt.datetime.now(dt.timezone.utc).isoformat()
    atomically_write_json(state_file,state)
    print('V18 ALL STAGES EXITED ZERO; verify release audit and conduct human expert review.')
    return 0
if __name__=='__main__':raise SystemExit(main())
