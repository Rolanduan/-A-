#!/usr/bin/env python3
"""Defensive final preflight for REAL data + GIS paper; not peer review or COMAP approval."""
from pathlib import Path
import json,sys
import pandas as pd
import fitz
from fetch_verified import atomically_write_json,sha256_file
from audit_full_gis import check
from paper_layout_contract import audit_pdf_layout, validate_tex_structure
from score_official_gis import ROOT,OUT,CITY


def run():
    problems=[]
    q=check()
    from decision_release import validate as validate_v18_decision
    v18_decision=validate_v18_decision()
    if v18_decision.get('status')!='PASS_V18_DECISION_EVIDENCE_GATE':
        problems.extend('V18_EXTENSION:'+str(x) for x in v18_decision.get('issues',[]))
    if q['status']!='PASS':problems.extend(q['issues'])
    rank=OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv'
    sc=OUT/'REAL_GIS_27_SCENARIOS.csv'
    moe=OUT/'V18_ACS_MOE_STRESS_ENVELOPES.csv'
    atlas=ROOT/'figures/v18_real_gis_atlas/figure_manifest.json'
    systems=ROOT/'results_v18/SYSTEMS_THEORY_EMPIRICAL_TESTS.csv'
    replay_path=ROOT/'qa_v18/independent_replay.json'
    release=[rank,sc,moe,systems,atlas,replay_path]
    for path in release:
        if not path.is_file():problems.append('MISSING:'+str(path))
    if replay_path.is_file():
        replay=json.loads(replay_path.read_text())
        if replay.get('status')!='INDEPENDENT_PYTHON_NUMERIC_REPLAY_PASS' or (rank.is_file() and replay.get('ranking_csv_sha256')!=sha256_file(rank)):
            problems.append('INDEPENDENT_REPLAY_NOT_CURRENT_OR_FAILED')
    if rank.is_file():
        d=pd.read_csv(rank,dtype={'city_geoid':str});d.city_geoid=d.city_geoid.str.zfill(7)
        if len(d)!=12 or set(d.city_geoid)!=set(CITY):problems.append('CITY_COUNT_NOT_12')
        if not d.M1_rank.is_unique or set(d.M1_rank)!=set(range(1,13)):problems.append('RANK_PERMUTATION_WRONG')
    if sc.is_file() and len(pd.read_csv(sc))!=324:problems.append('SCENARIOS_NOT_27x12')
    if moe.is_file() and len(pd.read_csv(moe))!=12:problems.append('MOE_ENVELOPES_NOT_12')
    if systems.is_file() and len(pd.read_csv(systems))<8:problems.append('SYSTEMS_TESTS_INCOMPLETE')
    if atlas.is_file():
        figs=json.loads(atlas.read_text())
        if figs.get('num_figures',0)<10:problems.append('ATLAS_FEWER_THAN_TEN')
        for entry in figs.get('figures',[]):
            p=ROOT/entry['pdf_path']
            if not p.is_file() or sha256_file(p)!=entry['sha256']:problems.append('ATLAS_PDF_SHA_MISMATCH_'+entry.get('name',''))
    # V18 restored P0/P1 evidence: each gate is a real computed file/receipt.
    extras={
        'same_facility_ablation':OUT/'V18_CONTROLLED_ABLATION.csv',
        'raw_osm_source_rebuild':ROOT/'qa_v18/independent_raw_osm_replay.json',
        'independent_imls':OUT/'V18_IMLS_OSM_INDEPENDENT_COVERAGE.csv',
        'exact_lp_regret':OUT/'V18_PARETO_LP_MINIMAX_REGRET.csv',
        'real_od_stress':OUT/'V18_REAL_OD_ACCESS_SPEED_MISSINGNESS_STRESS.csv',
        'edge_failure_sample':OUT/'V18_ACTUAL_GRAPH_HYPOTHETICAL_EDGE_BLOCK_SAMPLE.csv',
        'multicity_map_manifest':ROOT/'figures/v18_multicity_gis/V18_12_CITY_MAP_EVIDENCE_MANIFEST.json',
        'temporal_comparability':ROOT/'qa_v18/osm_temporal_comparability.json',
        'claims':ROOT/'research/v18_claim_evidence_registry.csv',
        'equations':ROOT/'research/v18_equation_contracts.csv',
        'official_summary_receipt':ROOT/'qa_v18/official_summary_template.json',
        'official_summary_compiled':ROOT/'paper_v18_official_gis/V18_OFFICIAL_SUMMARY_BUILD.json',
        'ai_appendix_receipt':ROOT/'paper_v18_official_gis/V18_AI_DISCLOSURE_BUILD.json'}
    for key,path in extras.items():
        if not path.is_file():problems.append('V18_SOURCE_EVIDENCE_MISSING:'+key)
    if extras['same_facility_ablation'].is_file():
        df=pd.read_csv(extras['same_facility_ablation'])
        if len(df)!=12 or not {'M_inventory_same_POIs','M_euclidean_same_POIs','M_network_mean_same_POIs','M_network_Q10_reference','M_network_unknown_upper'}<=set(df.columns):
            problems.append('V18_CONTROLLED_ABLATION_INVALID')
        elif (df.M_network_unknown_upper+1e-8<df.M_network_Q10_reference).any():
            problems.append('V18_ELIGIBILITY_UPPER_LT_REFERENCE')
    if extras['raw_osm_source_rebuild'].is_file():
        raw=json.loads(extras['raw_osm_source_rebuild'].read_text())
        if raw.get('status')!='PASS_12_CITIES_RAW_SOURCE_NETWORK_REPLAY' or len(raw.get('cities',{}))!=12:
            problems.append('V18_RAW_OSM_INDEPENDENT_REBUILD_NOT_12_CITY_PASS')
    if extras['independent_imls'].is_file() and len(pd.read_csv(extras['independent_imls']))!=12:
        problems.append('V18_IMLS_NOT_TWELVE_CITIES')
    if extras['exact_lp_regret'].is_file() and len(pd.read_csv(extras['exact_lp_regret']))!=12:
        problems.append('V18_PARETO_LP_NOT_12_CITIES')
    if extras['real_od_stress'].is_file() and len(pd.read_csv(extras['real_od_stress']))!=216:
        problems.append('V18_ROAD_STRESS_NOT_18x12')
    if extras['edge_failure_sample'].is_file() and len(pd.read_csv(extras['edge_failure_sample']))!=12:
        problems.append('V18_ROAD_EDGE_FAILURE_DIAGNOSTICS_NOT_ALL_12_CITIES')
    if extras['multicity_map_manifest'].is_file():
        atlas12=json.loads(extras['multicity_map_manifest'].read_text())
        if len(atlas12.get('cities',[]))!=12:problems.append('V18_NO_12_REAL_GIS_MAPS')
        else:
            for item in atlas12['cities']:
                f=ROOT/item['pdf']
                if not f.is_file() or sha256_file(f)!=item['pdf_sha256']:
                    problems.append('V18_GIS_MULTICITY_MAP_SHA_MISMATCH:'+item['city_geoid'])
    official=ROOT/'sources/official/HiMCM-MidMCM_Summary_ORIGINAL.tex'
    if extras['official_summary_receipt'].is_file():
        r=json.loads(extras['official_summary_receipt'].read_text())
        if not official.is_file() or sha256_file(official)!=r.get('sha256') or r.get('origin_verification') not in ('DIRECT_TLS_SOURCE','HUMAN_ATTESTED_OFFICIAL_TLS'):
            problems.append('V18_COMAP_LATEX_ORIGINAL_NOT_ATTESTED')
    if extras['official_summary_compiled'].is_file():
        b=json.loads(extras['official_summary_compiled'].read_text())
        if not official.is_file() or b.get('official_original_sha256')!=sha256_file(official):
            problems.append('V18_COMAP_ADAPTATION_SOURCE_HASH_NOT_BOUND')
    paper=ROOT/'paper_v18_official_gis/V18_EMPIRICAL_YOUTH_CITY_NETWORK_RESEARCH.pdf'
    layout_path=ROOT/'paper_v18_official_gis/paper_layout_audit.json'
    tex_path=ROOT/'paper_v18_official_gis/V18_EMPIRICAL_YOUTH_CITY_NETWORK_RESEARCH.tex'
    tex_layout_report=None
    if not tex_path.is_file():
        problems.append('PAPER_TEX_SOURCE_MISSING')
    else:
        tex_layout_report=validate_tex_structure(tex_path.read_text(encoding='utf-8'))
        if tex_layout_report.get('status')!='PASS':
            problems.extend('OFFICIAL_OPTIONAL_LAYOUT_TEX:'+x for x in tex_layout_report.get('issues',[]))
    layout_report=None
    supplemental_titles=['Nontechnical News Article']
    supplemental_manifest=ROOT/'paper_supplemental/manifest.json'
    if not supplemental_manifest.is_file():
        problems.append('SUPPLEMENTAL_DOCUMENT_MANIFEST_MISSING')
    else:
        supplemental_titles.extend(str(x.get('title','')).strip() for x in json.loads(supplemental_manifest.read_text()).get('documents',[]))
    solution_only=ROOT/'paper_v18_official_gis/V18_SOLUTION_25PAGE_ONLY.pdf'
    if not paper.is_file() or not solution_only.is_file():
        problems.append('COMPILED_V18_PAPER_MISSING')
    else:
        layout_report=audit_pdf_layout(solution_only, supplemental_titles=supplemental_titles, max_pages=25)
        if layout_report.get('status')!='PASS':
            problems.extend('OFFICIAL_OPTIONAL_LAYOUT:'+x for x in layout_report.get('issues',[]))
        if not layout_path.is_file():
            problems.append('PAPER_LAYOUT_AUDIT_RECEIPT_MISSING')
        else:
            stored=json.loads(layout_path.read_text())
            if stored.get('status')!='PASS' or stored.get('pdf_sha256')!=layout_report.get('pdf_sha256'):
                problems.append('PAPER_LAYOUT_AUDIT_RECEIPT_STALE_OR_FAILED')
        with fitz.open(solution_only) as doc:
            if len(doc)>25:problems.append('PDF_SOLUTION_OVER_25_PAGES')
            if len(doc)<8:problems.append('PDF_TOO_SHORT_POSSIBLY_TRUNCATED')
            text='\n'.join(p.get_text() for p in doc)
            for section in ('Summary Sheet','Table of Contents','Introduction and Restatement of the Problem',
                            'Assumptions with Justifications','Presentation of Model and Solution',
                            'Analysis of Your Work','Concluding Paragraph',
                            'Supplementary 1--2 Page Documents and Memos','Nontechnical News Article','Reference List'):
                if section.lower() not in text.lower():problems.append('PDF_SECTION_MISSING_'+section)
            # Scientific legibility: flag substantial prose/caption spans below 12 pt.
            for pageno,page in enumerate(doc):
                for block in page.get_text('dict').get('blocks',[]):
                    if block.get('type')!=0:continue
                    for line in block.get('lines',[]):
                        for span in line.get('spans',[]):
                            text=(span.get('text') or '').strip()
                            if len(text)>=22 and span.get('size',12)<11.5:
                                problems.append('PDF_READABLE_TEXT_BELOW_12PT_PAGE_'+str(pageno+1))
                                break
            # This is a technical layout audit of an independent paper, not COMAP approval.
        if extras['ai_appendix_receipt'].is_file():
            ai=json.loads(extras['ai_appendix_receipt'].read_text())
            if ai.get('combined_sha256')!=sha256_file(paper) or ai.get('solution_sha256')!=sha256_file(solution_only):
                problems.append('AI_APPENDIX_COMBINED_SOURCE_HASH_MISMATCH')
            with fitz.open(paper) as combined:
                if len(combined)<=ai.get('solution_pages',10**9):problems.append('AI_DISCLOSURE_NOT_APPENDED')
    status='TECHNICAL_PRECHECK_PASS_HUMAN_SCIENCE_REVIEW_PENDING' if not problems else 'BLOCKED_FOR_FINAL_GIS_PAPER'
    receipt={'version':'V18','status':status,'problems':problems,'claim_scope':'12-city conditional 2024 Census + acquired OSM walking model; not causal welfare',
             'not_automatically_certified':['External construct validity','Facility access/entrance legality','Human scholarly review','Competition submission eligibility'],
             'ranking_sha256':sha256_file(rank) if rank.is_file() else None,
             'manuscript_sha256':sha256_file(paper) if paper.is_file() else None,
             'official_optional_layout_audit':layout_report,
             'official_optional_layout_tex_audit':tex_layout_report}
    atomically_write_json(ROOT/'qa_v18/final_release_audit.json',receipt)
    print(json.dumps(receipt,indent=2));return status
if __name__=='__main__':sys.exit(0 if run().startswith('TECHNICAL_PRECHECK_PASS') else 3)
