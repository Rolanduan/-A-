#!/usr/bin/env python3
"""Acquire original COMAP summary LaTeX, adapt its preamble, compile exactly one page.

This is an independent study: when no real control number exists, it MUST be
labelled Not Registered, and no compliance or entry is claimed. The official
original is hashed and retained; adaptations are auditably separate files.
"""
from __future__ import annotations
import json,re,shutil,subprocess,os
from pathlib import Path
import pandas as pd
import fitz
from acquire_osm_walk import ROOT,digest
from fetch_verified import fetch,atomically_write_json

URL='https://www.contest.comap.com/highschool/contests/himcm/flyers/HiMCM-MidMCM_Summary.tex'
RAW=ROOT/'sources/official/HiMCM-MidMCM_Summary_ORIGINAL.tex'
RECEIPT=ROOT/'qa_v18/official_summary_template.json'


def validate_source(original):
    s=Path(original).read_text(encoding='utf-8-sig',errors='strict')
    if len(s)<300 or r'\documentclass' not in s or r'\begin{document}' not in s or r'\end{document}' not in s:
        raise ValueError('OFFICIAL_LATEX_TEMPLATE_NOT_STANDALONE_OR_MALFORMED')
    return s


def acquire():
    RECEIPT.parent.mkdir(parents=True,exist_ok=True)
    if RAW.exists() and RECEIPT.exists():
        receipt=json.loads(RECEIPT.read_text())
        if digest(RAW)==receipt.get('sha256') and receipt.get('origin_verification') in ('DIRECT_TLS_SOURCE','HUMAN_ATTESTED_OFFICIAL_TLS'):
            validate_source(RAW);return receipt
    manual=os.getenv('V18_COMAP_SUMMARY_IMPORT','').strip()
    signed=os.getenv('V18_COMAP_SUMMARY_ATTESTATION','').strip()
    if manual:
        m=Path(manual)
        if not m.is_file() or not signed or not Path(signed).is_file():
            raise ValueError('COMAP_SUMMARY_IMPORT_REQUIRES_SOURCE_AND_SOURCE_ATTESTATION')
        v=json.loads(Path(signed).read_text())
        if (v.get('sha256')!=digest(m) or v.get('exact_official_source_url')!=URL or
            v.get('human_confirmed_official_https') is not True or not str(v.get('human_reviewed_by','')).strip()):
            raise ValueError('COMAP_LATEX_ORIGIN_ATTESTATION_INVALID')
        validate_source(m);shutil.copy2(m,RAW)
        r={'status':'DOWNLOADED_ORIGINAL_WITH_SHA','source_id':'COMAP_OFFICIAL_SUMMARY_LATEX',
           'publisher':'COMAP','original_url':URL,'sha256':digest(RAW),'path':str(RAW),
           'bytes':RAW.stat().st_size,'origin_verification':'HUMAN_ATTESTED_OFFICIAL_TLS',
           'human_attestation_sha256':digest(Path(signed))}
        atomically_write_json(RECEIPT,r);return r
    r=fetch(URL,RAW,source_id='COMAP_OFFICIAL_SUMMARY_LATEX',publisher='COMAP',extension='tex',
            attempts=2,transports=('urllib','curl','wget'))
    if r.get('status')!='DOWNLOADED_ORIGINAL_WITH_SHA' or r.get('origin_verification')!='DIRECT_TLS_SOURCE':
        atomically_write_json(RECEIPT,r)
        raise RuntimeError('OFFICIAL_SUMMARY_ORIGINAL_NOT_VERIFIED_V18:'+str(r.get('failures')))
    validate_source(RAW)
    r['source_type']='OFFICIAL_ORIGINAL_UNMODIFIED'
    atomically_write_json(RECEIPT,r)
    return r


def latexsafe(s):
    x=str(s)
    for a,b in [('\\',r'\textbackslash{}'),('&',r'\&'),('%',r'\%'),('$',r'\$'),('#',r'\#'),('_',r'\_'),('{',r'\{'),('}',r'\}')]:
        x=x.replace(a,b)
    return x


def generate_official_summary(paper_dir):
    receipt=acquire()
    original=validate_source(RAW)
    source=ROOT/'results_v18_gis/FINAL_12_CITY_REAL_GIS_RANKING.csv'
    rank=pd.read_csv(source).sort_values('M1_rank')
    if len(rank)!=12:raise ValueError('TWELVE_CITY_EVIDENCE_REQUIRED_FOR_SUMMARY')
    ab=ROOT/'results_v18_gis/V18_CONTROLLED_ABLATION.csv'
    if not ab.is_file():raise FileNotFoundError('SAME_FACILITY_ABLATIONS_REQUIRED')
    a=pd.read_csv(ab)
    change=a.iloc[(a['spatial_mechanism_change']).abs().argmax()]
    tops=rank.head(3)
    count=int((a['unknown_access_span']>1e-7).sum())
    number=os.environ.get('HIMCM_TEAM_CONTROL_NUMBER','').strip()
    if number and not re.fullmatch(r'[0-9]{3,8}',number):raise ValueError('CONTROL_NUMBER_NOT_VALID_NUMERIC_FORMAT')
    marker=('Team control '+number) if number else 'Independent research -- no registered control number'
    body=r'''
\begin{center}
{\Large\bfseries HiMCM 2026 -- Summary Sheet}\\[4pt]
{\bfseries Problem A: Youth Opportunity in Twelve U.S. Cities}\\[3pt]
__MARKER__
\end{center}
\noindent\textbf{Problem.} Rank twelve preselected U.S. cities under a clear age-relevant, evidence-grounded livability definition; test a substantive model revision.\\[5pt]
\noindent\textbf{Approach.} We retain original SHA256-verified 2024 ACS Table-Based files, official TIGER shapes, and source-cached OpenStreetMap walking roads. Household conditions are compared against a same-POI inventory, straight-line proxy, directed-road accessibility and population-weighted equity control. Unknown access is not silently accepted.\\[5pt]
\noindent\textbf{Actual results.} Under the frozen reference, __WINNER__ ranked first (__SCORE__/100), followed by __SECOND__ and __THIRD__. Across the same facility candidates, __CHANGE_CITY__ shows a road-versus-straight-line score change of __CHANGE__ points. In __UNKNOWN__ cities, unresolved facility access changes the potential upper bound, making the ranking conditional.\\[5pt]
\noindent\textbf{Conclusion.} This is a decision-model ranking for an explicit youth proxy, time window, mapping vintage and normative weights, not a causal or universal best-city conclusion. OSM rights and park entrances remain only partially observed.
'''
    replacements={'__MARKER__':latexsafe(marker),'__WINNER__':latexsafe(rank.iloc[0]['city']),
       '__SCORE__':f"{rank.iloc[0]['M1_real_walk_20m']:.2f}",
       '__SECOND__':latexsafe(tops.iloc[1]['city']),'__THIRD__':latexsafe(tops.iloc[2]['city']),
       '__CHANGE_CITY__':latexsafe(change['city']),'__CHANGE__':f"{change['spatial_mechanism_change']:+.2f}",
       '__UNKNOWN__':str(count)}
    for k,v in replacements.items():body=body.replace(k,v)
    start=original.index(r'\begin{document}')+len(r'\begin{document}')
    end=original.rindex(r'\end{document}')
    # The official LaTeX PREAMBLE is kept byte-for-byte in the adaptation;
    # official example body is replaced by the actual summary after calculation.
    adapted=original[:start]+'\n'+body+'\n'+original[end:]
    p=Path(paper_dir);p.mkdir(parents=True,exist_ok=True)
    tex=p/'V18_OFFICIAL_TEMPLATE_ADAPTED_SUMMARY.tex';tex.write_text(adapted)
    completed=subprocess.run(['latexmk','-pdf','-interaction=nonstopmode','-halt-on-error',tex.name],
                             cwd=p,capture_output=True,text=True)
    (p/'summary_compile.log').write_text(completed.stdout+'\n'+completed.stderr)
    if completed.returncode:raise RuntimeError('OFFICIAL_SUMMARY_LATEX_FAILED:'+completed.stdout[-1500:])
    pdf=tex.with_suffix('.pdf')
    with fitz.open(pdf) as d:
        if len(d)!=1:raise ValueError('OFFICIAL_SUMMARY_ADAPTATION_MUST_RENDER_EXACTLY_ONE_PAGE')
        page=d[0].get_text('text')
        for label in ('Problem','Approach','Actual results'):
            if label.lower() not in page.lower():raise ValueError('OFFICIAL_SUMMARY_EVIDENCE_LABEL_MISSING_'+label)
    info={'status':'OFFICIAL_LATEX_ORIGINAL_HASHED_AND_ADAPTED_ONEPAGE_COMPILED',
         'source_url':URL,'official_original_sha256':digest(RAW),
         'adapted_tex_sha256':digest(tex),'adapted_pdf_sha256':digest(pdf),
         'ranking_sha256':digest(source),'team_control_number':number or None,
         'identity':'UNREGISTERED_INDEPENDENT_STUDY' if not number else 'TEAM_NUMBER_USER_SUPPLIED_NOT_VALIDATED_WITH_COMAP'}
    (p/'V18_OFFICIAL_SUMMARY_BUILD.json').write_text(json.dumps(info,indent=2))
    return pdf,info


def splice_pdf_first_page(paper_pdf,paper_dir):
    official,receipt=generate_official_summary(paper_dir)
    pdf=Path(paper_pdf);solution_only=pdf.with_name('V18_SOLUTION_25PAGE_ONLY.pdf')
    with fitz.open(pdf) as original,fitz.open(official) as summary:
        if len(original)<2 or 'Summary Sheet' not in original[0].get_text():
            raise ValueError('EXPECTED_DRAFT_SUMMARY_TO_BE_REPLACED')
        original.delete_page(0)
        original.insert_pdf(summary,start_at=0)
        original.save(solution_only,garbage=4,deflate=True)
    shutil.copy2(solution_only,pdf)
    receipt['solution_only_pdf_sha256']=digest(solution_only)
    return solution_only,receipt
