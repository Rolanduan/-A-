#!/usr/bin/env python3
"""Independent PURE PYTHON replay of the final 12-city ACS+walking model.

This intentionally does NOT import the scoring/quantile helpers or pandas-based ranker.
It is not a substitute for validating physical entrances or ACS data provenance.
"""
from __future__ import annotations
import csv,json,math
from pathlib import Path
from fetch_verified import sha256_file,atomically_write_json
ROOT=Path(__file__).resolve().parents[1]
IDS={'4805000','2507000','1714000','0820000','5548000','2743000',
     '4261000','4159000','3755000','0666000','5363000','1304000'}

def rows_by_city(table):
    p=ROOT/f'data/processed/v18_official_acs/ACS_{table}_12_cities.psv'
    with p.open(encoding='utf-8-sig',newline='') as stream:
        rows=list(csv.DictReader(stream,delimiter='|'))
    return {r['GEO_ID'][9:]:r for r in rows}

def value(row,table,index):
    x=float(row[f'{table}_E{index:03d}'])
    if not math.isfinite(x) or x<0 or x>1e9:raise ValueError('BAD_OBSERVED_INPUT')
    return x

def clamp(x):return min(1,max(0,x))

def replay():
    m=json.loads((ROOT/'qa_v18/census_original_manifest.json').read_text())
    if not m.get('all_pass') or len(m.get('sources',[]))!=28:raise ValueError('CENSUS_MANIFEST_FAILED')
    for x in m['sources']:
        if not x['release_eligible'] or sha256_file(Path(x['path']))!=x['sha256']:
            raise ValueError('OFFICIAL_SOURCE_CORRUPTED_'+x['source_id'])
    ranks=ROOT/'results_v18_gis/FINAL_12_CITY_REAL_GIS_RANKING.csv'
    with ranks.open(newline='',encoding='utf-8') as f:claimed=list(csv.DictReader(f))
    if len(claimed)!=12 or {r['city_geoid'].zfill(7) for r in claimed}!=IDS:
        raise ValueError('NOT_EXACTLY_TWELVE_CITY_RANKS')
    tables={tab:rows_by_city(tab) for tab in ('B25070','B17001','B28002')}
    scored={}
    for city_id in IDS:
        r=tables['B25070'][city_id];p=tables['B17001'][city_id];b=tables['B28002'][city_id]
        rent_num=sum(value(r,'B25070',i) for i in (7,8,9,10))
        rent_den=value(r,'B25070',1)-value(r,'B25070',11)
        poverty=value(p,'B17001',2)/value(p,'B17001',1)
        broad=value(b,'B28002',4)/value(b,'B28002',1)
        if rent_den<=0:raise ValueError('INVALID_RENT_DENOM')
        m0=100*(.35*clamp((.8-rent_num/rent_den)/.6)+.35*clamp((.35-poverty)/.35)+.30*clamp((broad-.60)/.4))
        with (ROOT/f'data/processed/v18_network/city_origins_access_{city_id}.csv').open(newline='',encoding='utf-8') as f:
            blocks=list(csv.DictReader(f))
        obs=[]
        for x in blocks:
            weight=float(x['youth_15_17'])
            lib=1-math.exp(-float(x['library_access_20m'])/2)
            park=1-math.exp(-float(x['park_access_20m'])/2)
            obs.append((.55*lib+.45*park,weight))
        total=sum(w for _,w in obs)
        if not total>0:raise ValueError('NO_POPULATION')
        avg=sum(a*w for a,w in obs)/total
        cum=0;q10=None
        for a,w in sorted(obs):
            cum+=w
            if cum>=.1*total:q10=a;break
        if q10 is None:raise ValueError('BAD_QUANTILE')
        m1=60*(m0/100)+40*(.75*avg+.25*q10)
        scored[city_id]=(m0,m1)
    expected=sorted(IDS,key=lambda gid:(-scored[gid][1], next(r['city'] for r in claimed if r['city_geoid'].zfill(7)==gid)))
    failures=[]
    for row in claimed:
        gid=row['city_geoid'].zfill(7)
        a,b=scored[gid]
        if abs(a-float(row['M0_acs_citywide']))>1e-5 or abs(b-float(row['M1_real_walk_20m']))>1e-5:
            failures.append(f'SCORE_DISAGREEMENT_{gid}')
        if expected[int(row['M1_rank'])-1]!=gid:failures.append(f'RANK_DISAGREEMENT_{gid}')
    receipt={'status':'INDEPENDENT_PYTHON_NUMERIC_REPLAY_PASS' if not failures else 'FAIL',
        'n_cities':len(scored),'ranking_csv_sha256':sha256_file(ranks),
        'highest_rank_city_geoid':expected[0],'max_abs_m1_difference':max(abs(scored[r['city_geoid'].zfill(7)][1]-float(r['M1_real_walk_20m'])) for r in claimed),
        'errors':failures}
    atomically_write_json(ROOT/'qa_v18/independent_replay.json',receipt)
    if failures:raise AssertionError(str(failures))
    print(receipt)
    return receipt
if __name__=='__main__':replay()
