# V18 real-source data (not pre-bundled)

This project contains **no** ACS original table bytes, Census TIGER shapefiles, OSM PBF, OSMnx Overpass originals, real GIS network results or final ranking. It contains acquisition scripts only.

Required: download and verify 28 official 2024 Census originals: four complete ACS pipe-separated `.dat` tables and a PLACE/TRACT shapefile ZIP for each of 12 states. Record each file's SHA256, byte count and provenance under `qa_v18/census_original_manifest.json`.

```bash
python code_v18/run_v18.py --stage census
python code_v18/run_v18.py --stage geography
python code_v18/run_v18.py --stage networks --network auto
python code_v18/run_v18.py --stage all --network auto
```

OSM original bytes (Overpass cache or Geofabrik PBF) and derived GraphML have their own independent hashes. Data absent means no real ranking and no real empirical paper.
