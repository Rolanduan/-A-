# V18 research engineering changelog

## Preserved without changes to its scientific target

- Twelve-city United States cohort, 2024 ACS/TIGER, authentic OSM network requirements.
- M0 household-context reference and M1 road-reachable library/park opportunities with spatial fairness; same-facility controlled ablation.
- SHA256-provenanced official acquisition, independent OSM replay, IMLS external audit, 27 GIS preference scenarios, 18 real-OD stresses, ACS MOE endpoints, systems-science tests, Pareto/LP preference region, real maps, official-layout English paper and AI report.
- Hard `BLOCKED_FOR_FINAL_GIS_PAPER` state if original source, processing, model or paper proof missing.

## Actual new V18 code

| Script | New function |
|---|---|
| `evidence_frontier.py` | Outer evidence lower/upper, conservative exclusion and eligibility/ACS verification queue |
| `preference_paths.py` | Frozen M1 reconstruction, three analyst-only priorities, exact affine leader-switch intervals and finite family regret |
| `decision_atlas.py` | Two true-source PDF/SVG/PNG comparative figures, tied to input SHA |
| `decision_evidence_review.py` | Eight epistemic evidence claims, model-source linkages, conditionally generated English paper discussion |
| `decision_release.py` | Required file, row, city, source-hash, prose and figure consistency gate |
| `tests_v18/test_v18_decision_evidence.py` | Pure numerical, malformed-source, invariance, original model and negative-release tests |

`run_v18.py` now executes **30** ordered stages, with `evidence_frontier`, `preference_paths`, `decision_figures`, `evidence_review`, and `decision_gate` added before paper build. The paper and final release call the decision gate again and package the new results and source manifest. All active code/tests/config/outputs use V18 namespaces; earlier version source archives are not required or bundled.

## Research originality

We studied the public structure and high-level findings of `TypeThe0ry/HiMCM` and documented what we chose to rethink rather than copy in `research/V18_TRANSFER_AND_DIFFERENTIATION.md`. V18 uses its own Census/OSM inputs, six-component GIS score, exact piecewise weight-path method, conditional official-source verification queue and epistemic review. No other team's source code or city data is a runtime dependency.

## Truthful execution boundary

The code and its tests can be checked offline; the genuine 28-file Census download, twelve OSMap-derived walk networks, actual 12-city scores, figures and real-data English PDF **have not been produced in this source-only V18 release**. `V18_BUILD_AUDIT.json` records precisely what was tested now.
