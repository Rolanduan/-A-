# V19 — GIS ALL MAPS PRESERVATION LOCK

Status: design/implementation requirement, NOT evidence of actual full-city GIS outputs.

## Non-negotiable decision

The paper's ~7 selected primary figures are a **subset** for editorial clarity only. This limitation shall never delete, skip, overwrite, or drop any GIS figure, map producer, city, layer, route-corridor threshold, or full-resolution source output from the separate research atlas. The V18 source ZIP remains immutable. Migrate code under a new V19 namespace by copying and regression testing, not editing original V18 assets in place.

## Existing V18 GIS source code verified in the archived ZIP

- `code_v18/render_city_atlas_v18.py`: `run()` iterates through all 12 frozen city GEOIDs; each city's combined figure includes (A) 20-minute tract opportunity choropleth, and (B) directed walking-network 10/20/30-minute **corridors** and mapped library/park candidates. Each is saved as an individual PDF and SVG, and all twelve entries go into the evidence manifest. These are network-edge buffered display corridors; they are NOT proven full-space isochrone polygons or verified facility gates.
- `code_v18/render_atlas.py`: retains all 10 source-backed V18 analytic figure generators, including Austin network case, cross-boundary exposure, 12-city ranking, equity comparison, and systems provenance.
- `code_v18/render_real_gis_figures.py`: retains ranking, rank bump and Austin walking-network output code; historic F17 filenames must be migrated with compatible output aliases, not silently eliminated.
- `code_v18/decision_atlas.py`: retains the separate evidence and preference plots.

## Full V19 GIS catalog (regardless of paper page budget)

1. Twelve individual city-level tract opportunity choropleths on actual Census TIGER geographies, consistent scales and legends.
2. Twelve individual city pedestrian-network maps with actual OSM topology, public/unknown/restricted POIs clearly distinguished and authentic OD anchors.
3. 10/20/30-minute actual-network **reachable edge corridor** maps, with separate native cutoff semantics; never mislabel as a verified pedestrian isochrone polygon.
4. Cross-municipal-boundary service access and city-edge flow maps using actual routed pairs.
5. Twelve-city comparative small multiples with frozen colormap scales and common units.
6. Map of 15–17 ACS tract youth-proxy allocations and city/tract overlay, identifying area interpolation.
7. Street-network algorithm I: selected real directed path and accessibility computation diagnostics.
8. Facility-placement algorithm II: observed candidate location layer and clearly labeled hypothetical, optimizer-selected locations (not approved real construction sites).
9. Tail-fairness and road-break algorithm III: low-opportunity tracts and hypothetical closure-risk maps; not observed closures.
10. City-scale evidence/provenance maps and source-to-claim figure records.
11. Existing 10-frame V18 scientific atlas graphics and 2 decision-evidence figures stay available; title renaming cannot drop an output.
12. Original real data maps must be editable where feasible as PDF/SVG, with noneditable source or any additional cartographic GeoPackage / GeoJSON published as reproducibility source when allowed.

## Preservation and acceptance gates

- The V19 figure registry shall distinguish MAIN_PAPER, COMPLETE_ATLAS, ALGORITHM_ATLAS, and GIS_DATA_LAYER, with no figure omitted solely due to main-paper length.
- All 12 frozen GEOIDs must appear in the final map manifest. Save per-city PDF + SVG with city GEOID and run_id. Include input graph and Census geometry SHA256.
- Exports must pass legibility at the actual target page size, no clipped labels, matched legend and scale, readable source timestamp and network speed.
- GIS graphics require 28 original Census files, real OSM source bytes, 12 valid pedestrian graphs and actual derived tract/route metrics. If missing, the manifest status is `BLOCKED_FOR_REAL_CITY_GIS_ATLAS`, not success.
- The complete atlas is a separate deliverable from the 25-page paper, not squeezed into the main PDF. All legacy V18 drawing functions remain accessible or demonstrably replaced with equivalent-or-better tested implementations.
- Regression check: enumerate V18 existing figure-generation functions/files before migration, compare with V19 registry, fail if a GIS category or one of the 12 cities disappears.

## Frozen city set

Austin (4805000), Boston (2507000), Chicago (1714000), Denver (0820000), Madison (5548000), Minneapolis (2743000), Pittsburgh (4261000), Portland (4159000), Raleigh (3755000), San Diego (0666000), Seattle (5363000), Atlanta (1304000).

This is an additional V19 GIS design contract. It does not claim that GIS outputs have already been rendered or independently validated.
