# V19 决策锁定记录｜算法主线与设计边界

状态：**DESIGN DECISIONS FROZEN / 实证和正式 V19 代码尚未执行**。记录来源：用户在本次会话明确同意上轮三层算法建议。

## 固定且不允许视觉改版偷换的主干

- 对象：预设美国12城；2024 ACS 五年期真实原始 DAT、TIGER 2024、真实 OSM 步行网络原始响应或 Geofabrik PBF；保留来源 SHA256 与同版本审计。
- 研究逻辑：系统边界 → 真实观测 → M0 家庭条件基线 → 同设施集库存/直线/路网/资格/公平控制消融 → M1 冻结参考榜单 → M2 稳健性与决策边界 → 论文。
- **Algorithm I:** Adaptive Directed Truncated Dijkstra（根据居住起点/设施数量选择正向与逆向截断精确最短路；必须验证有向性、同一OD结果与性能提升，不是伪称新算法）。
- **Algorithm II:** GIS-grounded Monotone Submodular Facility Opportunity Optimization + Lazy Greedy/CELF（固定非负人口权重与饱和机会效用时验证次模性，等成本 cardinality 约束下才使用 1-1/e 经典近似界；候选增设点是反事实方案，绝不覆盖 M1 现状榜单）。
- **Algorithm III:** Population-weighted Lower-Tail CVaR + Edge-Removal Network Resilience（尾部人口加权均值是 Q10 的补充；关闭边后重算真实最短路，不能假称城市真实动态反馈）。
- 原 V18 Pareto/LP、证据外包络、定向核验与偏好路径保留作支持性决策分析，不改变参考模型权重、得分和城市样本。
- 图谱坚持 GIS真实坐标、算法真实中间量、数学对象一致和论文一源多输出，禁止假数据、手工编辑图上结果、用装饰性3D冒充实测地形。

## V19 视觉锁定决策

1. 正式解答：**英文、一份PDF、Summary第1页、正文+目录+新闻稿+参考文献不超过25页、12pt或更大可读文字**；AI使用报告按COMAP规则附在25页解答之后。此为“COMAP样式约束”，项目当前是独立研究，不得生成假 Team Control Number。
2. 设计语言：理性、克制、高清晰度；论文采用浅底色、科学图像采用矢量 PDF/SVG，必要栅格地图分辨率300–600dpi，黑白打印可辨识。
3. 唯一重要视觉主线：系统边界与证据链 → Algorithm I 测量 → M0/M1 控制实验 → 十二城现状结论 → Algorithm II 改善 → Algorithm III 公平/脆弱性 → 稳健决策。
4. 主文选择约7幅“必须解释”的图、3个关键表、3份算法/证明块；其余置于独立研究图谱，不以巨幅不可读多联图硬塞25页。
5. 论文与图均从同一个冻结 release_id / rank CSV / source hash manifest / run config 渲染，并对 PDF 每页渲染做可读性与重叠审计。
6. 本指令是**设计决议**，不声明真正的HiMCM评委参与，不替代真实科学同行评审与实际数据计算。

## 来源
- COMAP 2026: https://contest.comap.org/highschool/contests/himcm/instructions.html
- COMAP 2026 A题: https://contest.comap.org/highschool/contests/himcm/2026_Problems/2026_HiMCMProblem_A.pdf
- COMAP 官方 Summary TeX: https://www.contest.comap.com/highschool/contests/himcm/flyers/HiMCM-MidMCM_Summary.tex
- Consortium Judges Commentary: https://www.contest.comap.com/highschool/contests/himcm/flyers/Cons_HiMCM.pdf
- Nature Figure Guide: https://research-figure-guide.nature.com/figures/preparing-figures-our-specifications/
- PLOS Figure Requirements: https://journals.plos.org/plosbiology/s/figures
