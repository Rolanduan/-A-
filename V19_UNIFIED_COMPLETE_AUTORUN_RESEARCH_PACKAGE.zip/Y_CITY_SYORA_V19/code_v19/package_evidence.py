#!/usr/bin/env python3
"""After REAL pipeline passes, publish a PDF+TeX+code package and a separate large raw-byte archive.
No official raw data are invented, and the raw archive may be very large.
"""
from pathlib import Path
import json,zipfile,os
from fetch_verified import sha256_file,atomically_write_json
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'deliverables_v19'

def emit():
    audit=ROOT/'qa_v19/final_release_audit.json'
    if not audit.exists():raise RuntimeError('NO_REAL_GIS_RELEASE_AUDIT')
    qa=json.loads(audit.read_text())
    if qa.get('status')!='TECHNICAL_PRECHECK_PASS_HUMAN_SCIENCE_REVIEW_PENDING':
        raise RuntimeError('REAL_GIS_PAPER_GATE_NOT_PASSED')
    doc=ROOT/'paper_v19_official_gis/V19_EMPIRICAL_YOUTH_CITY_NETWORK_RESEARCH.pdf'
    if not doc.exists():raise RuntimeError('NO_EMPIRICAL_COMPILED_PDF')
    census=json.loads((ROOT/'qa_v19/census_original_manifest.json').read_text())
    if not census.get('all_pass') or len(census.get('sources',[]))!=28:raise RuntimeError('NOT_ALL_28_ORIGINALS')
    raw=[Path(r['path']) for r in census['sources']]
    for geoid in ['4805000','2507000','1714000','0820000','5548000','2743000','4261000','4159000','3755000','0666000','5363000','1304000']:
        rec=json.loads((ROOT/f'data/processed/v19_network/receipt_{geoid}.json').read_text())
        if rec.get('source_kind')=='RAW_GEOFABRIK_PBF':raw.append(Path(rec['source_pbf_path']))
        else:raw.extend(ROOT/r['path'] for r in rec['original_overpass_cached_response_files'])
    imls=ROOT/'data/raw_external/v19/imls_fy2024_official_csv_original.zip'
    imls_receipt=ROOT/'data/raw_external/v19/imls_fy2024_receipt.json'
    if not imls.is_file() or not imls_receipt.is_file() or sha256_file(imls)!=json.loads(imls_receipt.read_text()).get('sha256'):
        raise RuntimeError('IMLS_ORIGINAL_EVIDENCE_NOT_AVAILABLE_FOR_FINAL_REPRODUCIBILITY_PACKAGE')
    raw.append(imls)
    raw=list(dict.fromkeys(raw))
    for p in raw:
        if not p.is_file():raise RuntimeError('MISSING_DOWNLOADED_ORIGINAL:'+str(p))
    OUT.mkdir(exist_ok=True)
    archive_a=OUT/'V19_ALL_ORIGINAL_CENSUS_AND_OSM_BYTES_SHA256.zip'
    archive_b=OUT/'V19_COMPLETE_PAPER_TEX_CODE_ATLAS_AND_AUDITS.zip'
    original_manifest=[]
    with zipfile.ZipFile(archive_a,'w',allowZip64=True) as z:
        for p in raw:
            rel=p.relative_to(ROOT) if p.is_relative_to(ROOT) else Path('external_originals')/p.name
            compression=zipfile.ZIP_STORED if p.suffix in ('.zip','.pbf') else zipfile.ZIP_DEFLATED
            z.write(p,arcname=str(rel),compress_type=compression,compresslevel=1 if compression==zipfile.ZIP_DEFLATED else None)
            original_manifest.append(dict(path=str(rel),sha256=sha256_file(p),size_bytes=p.stat().st_size))
        z.writestr('V19_ORIGINAL_SOURCE_SHA256_MANIFEST.json',json.dumps(original_manifest,indent=2))
        z.writestr('OSM_ATTRIBUTION_AND_LICENSE.txt','Data © OpenStreetMap contributors; Open Database License (ODbL). Source: https://www.openstreetmap.org/copyright . Verify Geofabrik redistribution notices before any public publication.\n')
    dirs=['code_v19','tests_v19','config_v19','qa_v19',
          'results_v19_gis','results_v19','figures/v19_real_gis_atlas',
          'figures/v19_official_gis','figures/v19_multicity_gis','paper_v19_official_gis',
          'paper_supplemental','sources','data/processed/v19_gis',
          'data/processed/v19_network','data/processed/v19_official_acs',
          'research','figures/v19_decision_evidence','figures/v19_complete_gis_atlas','drawio']
    with zipfile.ZipFile(archive_b,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=5,allowZip64=True) as z:
        for d in dirs:
            directory=ROOT/d
            if not directory.exists():continue
            for f in directory.rglob('*'):
                if f.is_file() and f.suffix not in ('.pyc',):z.write(f,arcname=str(f.relative_to(ROOT)))
        for f in ['V19_MASTER.md','README_START_V19.md']:
            z.write(ROOT/f,arcname=f)
    receipt={'status':'ACTUAL_POSTRUN_RELEASE_PACKAGES_CREATED','human_scientific_review':'NOT_YET_ATTESTED',
             'original_files':original_manifest,'raw_zip':str(archive_a),'raw_zip_sha256':sha256_file(archive_a),
             'repro_zip':str(archive_b),'repro_zip_sha256':sha256_file(archive_b),
             'pdf_path':str(doc),'pdf_sha256':sha256_file(doc)}
    atomically_write_json(OUT/'V19_PACKAGE_RELEASE_RECEIPT.json',receipt)
    print(json.dumps({k:v for k,v in receipt.items() if k!='original_files'},indent=2))
    return receipt
if __name__=='__main__':emit()
