#!/usr/bin/env python3
"""Independent full official raw+OSM hash audit. No released ranking without passing."""
from pathlib import Path
from score_official_gis import CITY,RAW,NET,OUT,ROOT,TABLES,digest
import pandas as pd, json,math

def check():
 errors=[];receipts_path=ROOT/'qa_v19/census_original_manifest.json'
 if not receipts_path.exists():errors.append('MISSING_OFFICIAL_DOWNLOAD_RECEIPTS');official=[]
 else:
  manifest=json.loads(receipts_path.read_text());official=manifest.get('sources',[])
  if not manifest.get('all_pass'):errors.append('CENSUS_MANIFEST_NOT_FULLY_PASSED')
  required={'ACS_'+t for t in TABLES}|{f'TIGER2024_{layer}_{st}' for st in {g[:2] for g in CITY} for layer in ('PLACE','TRACT')}
  byid={x['source_id']:x for x in official}
  for key in required:
   if key not in byid or byid[key].get('release_eligible') is not True:errors.append('OFFICIAL_MISSING:'+key);continue
   x=byid[key];path=__import__('pathlib').Path(x['path']);path=path if path.is_absolute() else ROOT/path
   if not path.exists() or digest(path)!=x.get('sha256'):errors.append('OFFICIAL_HASH_MISMATCH:'+key)
 resultpath=OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv';receiptpath=OUT/'REAL_GIS_COMPUTATION_RECEIPT.json'
 if not resultpath.exists() or not receiptpath.exists():errors.append('NO_COMPUTED_GIS_12CITY_RANKING')
 else:
  data=pd.read_csv(resultpath,dtype={'city_geoid':str});data.city_geoid=data.city_geoid.str.zfill(7)
  if len(data)!=12 or set(data.city_geoid)!=set(CITY):errors.append('WRONG_CITY_COVERAGE')
  if len(set(data.M1_rank))!=12:errors.append('NONUNIQUE_RANK')
  if data[['M0_acs_citywide','M1_real_walk_20m']].isna().any().any():errors.append('NAN_SCORES')
  rec=json.loads(receiptpath.read_text())
  if rec.get('ranking_sha256')!=digest(resultpath):errors.append('RANKING_HASH_MISMATCH')
 for geoid in CITY:
  rfile=NET/f'receipt_{geoid}.json';gfile=NET/f'city_origins_access_{geoid}.csv';pfile=NET/f'poi_osm_{geoid}.csv'
  if not rfile.exists() or not gfile.exists() or not pfile.exists():errors.append('CITY_NOT_ROUTED:'+geoid);continue
  r=json.loads(rfile.read_text())
  for fn,expected in [(gfile,'processed_csv_sha256'),(pfile,'osm_poi_csv_sha256')]:
   if digest(fn)!=r.get(expected):errors.append(expected+'_MISMATCH:'+geoid)
  if r.get('source_kind')=='RAW_GEOFABRIK_PBF':
   pbf=__import__('pathlib').Path(r['source_pbf_path']);pbf=pbf if pbf.is_absolute() else ROOT/pbf
   if not pbf.is_file() or digest(pbf)!=r.get('source_pbf_sha256'):errors.append('GEOFABRIK_ORIGINAL_PBF_HASH_ERROR:'+geoid)
  elif not r.get('original_overpass_cached_response_files'):errors.append('NO_ORIGINAL_OSM_EVIDENCE:'+geoid)
  for f in r.get('original_overpass_cached_response_files',[]):
   target=ROOT/f['path']
   if not target.is_file() or digest(target)!=f['sha256']:errors.append('OSM_ORIGINAL_HASH_ERROR:'+geoid)
  df=pd.read_csv(gfile)
  if df.empty or not df['tract_geoid'].is_unique or df['youth_15_17'].sum()<=0:errors.append('INVALID_TRACT_ORIGINS:'+geoid)
  POIs=pd.read_csv(pfile)
  if 'access_status' not in POIs:errors.append('V19_ELIGIBILITY_STATUS_ABSENT:'+geoid)
  else:
   if not set(POIs.access_status).issubset({'OSM_TAGGED_PUBLIC','UNKNOWN','RESTRICTED'}):errors.append('INVALID_ELIGIBILITY_ENUM:'+geoid)
   for typ in ('library','park'):
    if not len(POIs[(POIs.kind==typ)&(POIs.access_status=='OSM_TAGGED_PUBLIC')]):
     errors.append('NO_OBSERVED_OSM_TAGGED_PUBLIC_CANDIDATES_'+typ+':'+geoid)
  for typ in ('library','park'):
   for minutes in (10,20,30):
    lower=f'{typ}_access_{minutes}m';upper=f'{typ}_access_upper_{minutes}m'
    if lower not in df or upper not in df:errors.append('V19_ACCESS_INTERVAL_MISSING:'+geoid+':'+typ);continue
    if not ((df[lower]>=-1e-10)&(df[upper]>=df[lower]-1e-8)).all():errors.append('UNKNOWN_ACCESS_UPPER_LT_REFERENCE:'+geoid+':'+typ)
  for typ in ('library','park'):
   if not ((df[f'{typ}_access_10m']<=df[f'{typ}_access_20m']+1e-8)&(df[f'{typ}_access_20m']<=df[f'{typ}_access_30m']+1e-8)).all():errors.append('SENSITIVITY_TIME_MONOTONICITY:'+geoid+':'+typ)
 qa={'status':'PASS' if not errors else 'BLOCKED_FOR_FULL_GIS_MANUSCRIPT','checked_cities':len(CITY),'issues':sorted(set(errors))}
 out=ROOT/'qa_v19/full_gis_qa.json';out.parent.mkdir(exist_ok=True);out.write_text(json.dumps(qa,indent=2))
 print(json.dumps(qa,indent=2));return qa
if __name__=='__main__':
 import sys
 sys.exit(0 if check()['status']=='PASS' else 3)
