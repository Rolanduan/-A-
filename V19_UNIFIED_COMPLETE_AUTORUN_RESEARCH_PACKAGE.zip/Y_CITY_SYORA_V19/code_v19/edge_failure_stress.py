#!/usr/bin/env python3
"""Observed OSM-graph edge-removal sensitivity, stratified tract-origin sample only.

A hypothetical 2% edge interruption is NOT an observed road closure or a
full-city intervention. Report no full-city ranking from this sample.
"""
from __future__ import annotations
import hashlib,json,math
from pathlib import Path
import networkx as nx
import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point
from acquire_osm_walk import ROOT,CITY,digest

NET=ROOT/'data/processed/v19_network'

def edge_dropout(key,fraction):
    return int.from_bytes(hashlib.sha256(repr(tuple(key)).encode('utf-8')).digest()[:8],'big')/2**64<fraction

def compare_graphs(graph,origins,targets,cutoff_m=2250):
    scores=[]
    for start in origins:
        distances=nx.single_source_dijkstra_path_length(graph,start,cutoff=cutoff_m,weight='length')
        scores.append(sum(1 for t in targets if t in distances))
    return scores

def run_city(geoid,rate=.02):
    import osmnx as ox
    receipt=json.loads((NET/f'receipt_{geoid}.json').read_text())
    path=ROOT/receipt['real_osm_graph_file']
    if not path.is_file() or digest(path)!=receipt['graph_sha256']:
        raise ValueError('BASELINE_GRAPH_ORIGINAL_RECEIPT_MISMATCH')
    G=ox.load_graphml(filepath=path)
    H=ox.project_graph(G,to_crs='EPSG:5070')
    pp=pd.read_csv(ROOT/'data/processed/v19_gis/official_tract_origins_v19.csv',dtype={'city_geoid':str})
    pp=pp[pp.city_geoid.str.zfill(7)==geoid].sort_values('estimated_youth_15_17',ascending=False)
    if len(pp)<3:raise ValueError('INSUFFICIENT_STUDY_ORIGINS_FOR_EDGE_SAMPLE')
    stride=max(1,len(pp)//8)
    pp=pp.iloc[::stride].head(8)
    poi=pd.read_csv(NET/f'poi_osm_{geoid}.csv')
    poi=poi[poi.access_status=='OSM_TAGGED_PUBLIC']
    if poi.empty:raise ValueError('EDGE_ANALYSIS_NEEDS_TAGGED_PUBLIC_CANDIDATES')
    tracts=gpd.GeoDataFrame(pp,geometry=gpd.points_from_xy(pp.longitude,pp.latitude),crs='EPSG:4326').to_crs('EPSG:5070')
    facilities=gpd.GeoDataFrame(poi,geometry=gpd.points_from_xy(poi.lon,poi.lat),crs='EPSG:4326').to_crs('EPSG:5070')
    origins=list(ox.distance.nearest_nodes(H,tracts.geometry.x.to_numpy(),tracts.geometry.y.to_numpy()))
    targets=list(ox.distance.nearest_nodes(H,facilities.geometry.x.to_numpy(),facilities.geometry.y.to_numpy()))
    before=compare_graphs(H,origins,targets)
    cut=H.copy()
    removed=[(u,v,k) for u,v,k in H.edges(keys=True) if edge_dropout((u,v,k),rate)]
    cut.remove_edges_from(removed)
    after=compare_graphs(cut,origins,targets)
    if any(b>a for b,a in zip(after,before)):
        raise AssertionError('REMOVING_EDGES_INCREASED_REACHABILITY')
    return dict(city_geoid=geoid,city=CITY[geoid],sampled_origins=len(origins),
        actual_original_graph_sha256=receipt['graph_sha256'],
        original_edges=H.number_of_edges(),hypothetical_removed_edges=len(removed),
        baseline_reachable_POl_pairs=sum(before),removed_edges_reachable_POI_pairs=sum(after),
        relative_decline=(sum(before)-sum(after))/max(1,sum(before)),
        scope='Stratified origin sample; hypothetical random edge deletion; NOT full-city ranking')

def run():
    from audit_full_gis import check
    if check()['status']!='PASS':raise RuntimeError('REAL_12_CITY_GIS_NOT_AUDITED')
    rows=[run_city(gid) for gid in CITY]
    target=ROOT/'results_v19_gis/V19_ACTUAL_GRAPH_HYPOTHETICAL_EDGE_BLOCK_SAMPLE.csv'
    target.parent.mkdir(exist_ok=True)
    pd.DataFrame(rows).to_csv(target,index=False)
    receipt={'status':'REAL_GRAPH_EDGE_FAILURE_SAMPLE_PASS','n_cities':len(rows),'source_result_sha256':digest(target),
      'not_full_city_rank':'Only a sampled fragility diagnostic, not citywide changed-score estimates.'}
    (ROOT/'results_v19_gis/V19_EDGE_SAMPLE_RECEIPT.json').write_text(json.dumps(receipt,indent=2))
    print(receipt);return receipt
if __name__=='__main__':run()
