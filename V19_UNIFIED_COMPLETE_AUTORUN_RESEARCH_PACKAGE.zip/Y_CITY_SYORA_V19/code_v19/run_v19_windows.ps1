# V19 genuine federal-data + OSM GIS research pipeline, Windows PowerShell.
# Run from the unzipped Y_CITY_SYORA_V19 folder, not from inside the ZIP.
param(
    [ValidateSet('auto','overpass','geofabrik')][string]$Network='auto',
    [string]$ImportDir='',
    [string]$AttestationDir='',
    [switch]$AllowAttestedOrigin,
    [switch]$DryRun
)
$ErrorActionPreference = 'Stop'
Set-Location (Resolve-Path (Join-Path $PSScriptRoot '..'))
$Python = 'python'
& $Python -m pip install -r code_v19/requirements_v19.txt
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed; try Miniforge/conda-forge.' }
$argsV19 = @('code_v19/run_v19.py','--stage','all','--network',$Network)
if ($ImportDir) { $argsV19 += @('--import-dir',$ImportDir) }
if ($AttestationDir) { $argsV19 += @('--attestation-dir',$AttestationDir) }
if ($AllowAttestedOrigin) { $argsV19 += '--allow-attested-origin' }
if ($DryRun) { $argsV19 += '--dry-run' }
& $Python @argsV19
if ($LASTEXITCODE -ne 0) { throw "V19 empirical pipeline blocked; consult qa_v19/v19_execution_state.json" }
Write-Host 'V19 pipeline completed technically; human scientific review remains required.'
