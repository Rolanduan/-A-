"""V19 sparse graph-to-matrix bridge. Matrix algebra must reproduce ORIGINAL M1 category saturation."""
from __future__ import annotations
import math
import numpy as np
import networkx as nx
from scipy.sparse import csr_matrix
from algorithm1_adaptive_routing import compute_kernel

def incidence_matrix(G):
    # Incidence matrix is a representation, not a replacement for directed shortest paths.
    edges=list(G.edges(keys=True) if G.is_multigraph() else G.edges()); nodes=list(G.nodes());idx={n:i for i,n in enumerate(nodes)}
    rows=[];cols=[];vals=[]
    for j,e in enumerate(edges):
        u,v=e[:2];rows.extend([idx[u],idx[v]]);cols.extend([j,j]);vals.extend([-1,1])
    return csr_matrix((vals,(rows,cols)),shape=(len(nodes),len(edges))),nodes,edges

def kernel_matrix(G,origins,facilities,cutoff_seconds=1200,tau_seconds=720):
    computed=compute_kernel(G,origins,facilities,cutoff_seconds,tau_seconds)
    mat=csr_matrix(np.asarray([[computed['kernel'][(o,f)] for f in facilities] for o in origins],dtype=float))
    return mat,computed

def category_saturated_opportunity(K,public_mask,category_matrix,category_weights=(.55,.45),scale=2.):
    """Original M1: A=K diag(public) C; u_k=1-exp(-A_k/2); a=u @ [.55,.45]."""
    from scipy.sparse import diags
    if scale<=0:raise ValueError('INVALID_SCALE')
    y=np.asarray(public_mask,dtype=float);C=np.asarray(category_matrix,dtype=float)
    if K.shape[1]!=len(y) or C.shape[0]!=len(y):raise ValueError('MATRIX_DIMENSION_MISMATCH')
    if not np.all((y==0)|(y==1)):raise ValueError('BINARY_ACCESS_MASK_REQUIRED')
    A=(K@diags(y)@csr_matrix(C)).toarray()
    W=np.asarray(category_weights,dtype=float)
    if A.shape[1]!=len(W) or np.any(W<0) or abs(W.sum()-1)>1e-9:raise ValueError('BAD_CATEGORY_WEIGHTS')
    U=-np.expm1(-A/scale)
    return A,U,U@W
