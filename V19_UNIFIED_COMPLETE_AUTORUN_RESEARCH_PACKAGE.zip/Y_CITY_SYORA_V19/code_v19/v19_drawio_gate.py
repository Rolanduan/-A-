"""Check fully editable V19 Draw.io diagrams and companion SVG/PDF exports."""
from pathlib import Path
from xml.etree import ElementTree as ET
import json
from acquire_osm_walk import ROOT
from fetch_verified import sha256_file

def check():
    p=ROOT/'drawio/V19_DRAWIO_MANIFEST.json'
    if not p.is_file():raise FileNotFoundError('DRAWIO_MANIFEST_MISSING')
    entries=json.loads(p.read_text())['diagrams']
    if len(entries)!=8:raise ValueError('DRAWIO_COUNT_NOT_EIGHT')
    for x in entries:
        d=ROOT/x['editable_drawio'];svg=ROOT/x['svg'];pdf=ROOT/x['pdf']
        if not d.is_file() or not svg.is_file() or not pdf.is_file():raise FileNotFoundError('DRAWIO_EXPORT_MISSING_'+x['diagram'])
        if sha256_file(d)!=x['source_sha256']:raise ValueError('DRAWIO_EDITABLE_SOURCE_CHANGED')
        tree=ET.parse(d)
        cells=tree.findall('.//mxCell')
        if not any(c.get('vertex')=='1' for c in cells) or not any(c.get('edge')=='1' for c in cells):raise ValueError('NOT_ACTUAL_EDITABLE_DRAWIO_GRAPH')
        if '<svg' not in svg.read_text()[:1500]:raise ValueError('SVG_EXPORT_INVALID')
        if not pdf.read_bytes().startswith(b'%PDF'):raise ValueError('PDF_EXPORT_INVALID')
    return len(entries)
if __name__=='__main__':print('EDITABLE_DRAWIO_ASSETS_PASS',check())
