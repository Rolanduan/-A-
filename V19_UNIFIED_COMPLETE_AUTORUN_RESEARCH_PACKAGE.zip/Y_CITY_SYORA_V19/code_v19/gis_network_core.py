#!/usr/bin/env python3
"""V19 network accessibility calculation. No Euclidean distances are accepted as walk times.

Graph edges must have measured OSM lengths and explicitly selected walking speed.
On directed road networks, point->facility shortest paths are computed by reversing
edges and solving from each facility. Cross-city reachability is allowed by data scope.
"""
import hashlib,math,networkx as nx

def annotate_walk_seconds(graph,speed_mps=1.25):
    if speed_mps<=0:raise ValueError('walking speed must be positive')
    G=graph.copy()
    for a,b,key,data in G.edges(keys=True,data=True) if G.is_multigraph() else ((a,b,None,d) for a,b,d in G.edges(data=True)):
        try:length=float(data['length'])
        except Exception as e:raise ValueError('edge length required') from e
        if not math.isfinite(length) or length<0:raise ValueError('invalid OSM edge length')
        data['walking_seconds']=length/speed_mps
    return G

def walking_opportunity(graph, origin_nodes, facility_nodes, time_limit_minutes=20, tau_minutes=12):
    if time_limit_minutes<=0 or tau_minutes<=0:raise ValueError('travel limit and decay must be positive')
    if not origin_nodes or not facility_nodes:raise ValueError('both origins and facilities required')
    for node in set(origin_nodes)|set(facility_nodes):
        if node not in graph:raise ValueError('origin or facility snapped outside graph: '+str(node))
    G=graph.reverse(copy=False) if graph.is_directed() else graph
    score={node:0. for node in origin_nodes};reach={node:0 for node in origin_nodes}
    limit=time_limit_minutes*60
    for poi in facility_nodes:
        dist=nx.single_source_dijkstra_path_length(G,poi,cutoff=limit,weight='walking_seconds')
        for origin in score:
            t=dist.get(origin)
            if t is not None:
                score[origin]+=math.exp(-t/(60*tau_minutes))
                reach[origin]+=1
    return [{'origin_node':n,'access_score':score[n],'facilities_reachable':reach[n]} for n in origin_nodes]

def population_weighted_accessibility(rows,population):
    if len(rows)!=len(population) or not rows:raise ValueError('wrong or empty population weights')
    p=list(map(float,population));x=[float(z['access_score']) for z in rows]
    if any(not math.isfinite(t) or t<0 for t in p+x) or sum(p)<=0:raise ValueError('invalid or zero population')
    return sum(a*b for a,b in zip(x,p))/sum(p)
