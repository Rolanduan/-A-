"""V19 Algorithm II: audit-ready CELF monotone submodular site selection.
Candidate rows are fixed routed opportunity kernels, not proposed real permits.
A nonnegative fixed-weight concave separable objective permits 1-1/e bound.
"""
from __future__ import annotations
import heapq,itertools,math
import numpy as np

def objective(selected,base,kernel,weights,scale=2.):
    base=np.asarray(base,dtype=float); kernel=np.asarray(kernel,dtype=float); w=np.asarray(weights,dtype=float)
    if base.ndim!=1 or w.shape!=base.shape or kernel.ndim!=2 or kernel.shape[0]!=len(base):
        raise ValueError('BAD_MATRIX_DIMENSIONS')
    if scale<=0 or np.any(~np.isfinite(base)) or np.any(base<0) or np.any(~np.isfinite(w)) or np.any(w<0) or np.any(~np.isfinite(kernel)) or np.any(kernel<0):
        raise ValueError('NONNEGATIVE_FINITE_INPUTS_REQUIRED')
    if len(set(selected))!=len(selected) or any(not 0<=i<kernel.shape[1] for i in selected):raise ValueError('BAD_SELECTION')
    updated=base+kernel[:,list(selected)].sum(axis=1) if selected else base
    return float(np.sum(w*np.exp(-base/scale)*(-np.expm1(-(updated-base)/scale))))

def celf(base,kernel,weights,budget,scale=2.):
    kernel=np.asarray(kernel,dtype=float)
    if not 0<=budget<=kernel.shape[1]:raise ValueError('BAD_CARDINALITY')
    def f(s):return objective(s,base,kernel,weights,scale)
    heap=[(-f([i]),i,0) for i in range(kernel.shape[1])];heapq.heapify(heap)
    chosen=[];history=[];current=0.
    while len(chosen)<budget:
        while True:
            neg,i,last=heapq.heappop(heap)
            if last==len(chosen):
                gain=-neg;chosen.append(i);current+=gain;history.append({'k':len(chosen),'candidate_id':i,'marginal_gain':gain,'objective':current});break
            gain=f(chosen+[i])-current
            heapq.heappush(heap,(-gain,i,len(chosen)))
    exact=f(chosen)
    if abs(current-exact)>1e-9:raise AssertionError('CELF_VALUE_MISMATCH')
    return {'selected':chosen,'value':exact,'history':history,'guarantee':'1-1/e only for fixed nonnegative weights, concave saturation and cardinality budget'}

def exhaustive_optimum(base,kernel,weights,budget,scale=2.):
    n=np.asarray(kernel).shape[1]
    if n>18:raise ValueError('SMALL_INSTANCE_ONLY')
    values=[(objective(c,base,kernel,weights,scale),c) for c in itertools.combinations(range(n),budget)]
    return max(values,key=lambda v:(v[0],tuple(-i for i in v[1])))
