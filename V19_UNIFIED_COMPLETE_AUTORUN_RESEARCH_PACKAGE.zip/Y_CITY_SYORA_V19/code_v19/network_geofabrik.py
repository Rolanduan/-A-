#!/usr/bin/env python3
"""Geofabrik official-provider PBF fallback. Full raw PBF retained with SHA256.
Parses genuine OSM walk-only edges via Pyrosm; routes on graph (not Euclidean distance).
This path is independent of Overpass. OSM data are © OSM contributors/ODbL, not Census.
"""
from __future__ import annotations
import csv,datetime as dt,gzip,json,math,os,sys
from collections import defaultdict
from pathlib import Path
import geopandas as gpd
import networkx as nx
from shapely.geometry import Point
ROOT=Path(__file__).resolve().parents[1]
from acquire_osm_walk import CITY,load_origins,sample_points,digest
from access_policy import bounds
from fetch_verified import fetch,atomically_write_json
STATES={'48':'texas','25':'massachusetts','17':'illinois','08':'colorado','55':'wisconsin',
        '27':'minnesota','42':'pennsylvania','41':'oregon','37':'north-carolina',
        '06':'california','53':'washington','13':'georgia'}
RAW=ROOT/'data/raw_osm/v19_geofabrik'
PROCESSED=ROOT/'data/processed/v19_network'


def acquire_state(state):
    p=RAW/(STATES[state]+'-latest.osm.pbf')
    url=f'https://download.geofabrik.de/north-america/us/{STATES[state]}-latest.osm.pbf'
    receipt=RAW/(STATES[state]+'_download_receipt.json')
    if p.exists() and receipt.exists():
        record=json.loads(receipt.read_text())
        if digest(p)==record.get('sha256') and record.get('origin_verification') in ('DIRECT_TLS_SOURCE','HUMAN_ATTESTED_OFFICIAL_TLS'):
            return p,record
    # Human can download exactly this PBF from Geofabrik HTTPS through a browser,
    # then provide a SHA-matching human-signed attestation if automated HTTP fails.
    import_dir=os.environ.get('V19_OSM_IMPORT_DIR')
    attestation_dir=os.environ.get('V19_OSM_ATTEST_DIR')
    if import_dir and not p.exists():
        source=Path(import_dir)/p.name
        if source.is_file():
            import shutil
            p.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(source,p)
    record=fetch(url,p,source_id='GEOFABRIK_'+STATES[state],publisher='Geofabrik/OSM contributors',extension='pbf',attempts=2,transports=('urllib','aria2','curl'))
    if record.get('origin_verification')!='DIRECT_TLS_SOURCE' and attestation_dir and record.get('status')=='DOWNLOADED_ORIGINAL_WITH_SHA':
        w=Path(attestation_dir)/('GEOFABRIK_'+STATES[state]+'.json')
        if w.is_file():
            proof=json.loads(w.read_text())
            if (proof.get('sha256')==record.get('sha256') and proof.get('exact_download_url')==url and
                    proof.get('confirmed_direct_https_download') is True and
                    len(str(proof.get('human_reviewed_by','')).strip())>=2):
                record['origin_verification']='HUMAN_ATTESTED_OFFICIAL_TLS'
                record['human_attestation_sha256']=digest(w)
    atomically_write_json(receipt,record)
    if record['status']!='DOWNLOADED_ORIGINAL_WITH_SHA' or record.get('origin_verification') not in ('DIRECT_TLS_SOURCE','HUMAN_ATTESTED_OFFICIAL_TLS'):
        raise RuntimeError('GEOFABRIK_PBF_UNAVAILABLE:'+str(record.get('failures')))
    return p,record


def route_graph(geoid, G, features, source_record, speed_mps=1.25):
    """Shared outputs and receipt schema consumed by V19 score/figure engines."""
    import osmnx as ox
    name=CITY[geoid]; sample=load_origins(geoid)
    graphdir=ROOT/'data/raw_osm/v19/graphml'; graphdir.mkdir(parents=True,exist_ok=True)
    PROCESSED.mkdir(parents=True,exist_ok=True)
    if G.number_of_nodes()<100 or G.number_of_edges()<100:raise ValueError('NETWORK_TOO_SMALL')
    if not isinstance(G,(nx.MultiDiGraph,nx.MultiGraph)):
        G=nx.MultiDiGraph(G)
    if not G.is_directed():
        # Walking both ways unless a real signed restriction was preserved by parser.
        G=G.to_directed()
    if 'crs' not in G.graph:G.graph['crs']='EPSG:4326'
    if str(G.graph['crs']).lower() not in ('epsg:4326','4326'):
        raise ValueError('PBF_NETWORK_GRAPH_EXPECTED_WGS84_AND_NEEDS_EXPLICIT_TRANSFORM')
    H=ox.projection.project_graph(G,to_crs='EPSG:5070')
    for u,v,k,d in H.edges(keys=True,data=True):
        # Pyrosm edges are metric when exported, but validate/derive from projected geometry.
        val=d.get('length')
        if val is None or not isinstance(val,(int,float)) or not math.isfinite(float(val)) or float(val)<=0:
            geometry=d.get('geometry')
            val=geometry.length if geometry is not None else math.hypot(H.nodes[u]['x']-H.nodes[v]['x'],H.nodes[u]['y']-H.nodes[v]['y'])
            d['length']=float(val)
        if float(d['length'])<=0 or not math.isfinite(float(d['length'])):raise ValueError('BAD_EDGE_METERS')
    gfile=graphdir/f'{geoid}_{name}_walk.graphml'
    # Save original lat/lon OSM network; hash of transformed graph is not necessary to replicate raw.
    ox.io.save_graphml(G,filepath=gfile)
    points=sample_points(features,'library')+sample_points(features,'park')
    points=list({(r['osm_id'],r['kind']):r for r in points}.values())
    if not any(p['kind']=='library' for p in points) or not any(p['kind']=='park' for p in points):
        raise ValueError('PBF_NO_LIBRARY_OR_PARK_FEATURES')
    origins=gpd.GeoDataFrame(sample,geometry=[Point(float(x['longitude']),float(x['latitude'])) for x in sample],crs='EPSG:4326').to_crs('EPSG:5070')
    pois=gpd.GeoDataFrame(points,geometry=[Point(x['lon'],x['lat']) for x in points],crs='EPSG:4326').to_crs('EPSG:5070')
    on=list(ox.distance.nearest_nodes(H,origins.geometry.x.tolist(),origins.geometry.y.tolist()))
    pn=list(ox.distance.nearest_nodes(H,pois.geometry.x.tolist(),pois.geometry.y.tolist()))
    xs=nx.get_node_attributes(H,'x');ys=nx.get_node_attributes(H,'y')
    osnap=[math.hypot(xs[n]-p.x,ys[n]-p.y) for n,p in zip(on,origins.geometry)]
    psnap=[math.hypot(xs[n]-p.x,ys[n]-p.y) for n,p in zip(pn,pois.geometry)]
    if max(osnap)>800 or max(psnap)>1200:raise ValueError('SNAP_DISTANCES_TOO_LARGE')
    lookup=defaultdict(list)
    for p,n,s in zip(points,pn,psnap):lookup[n].append((p['kind'],p['osm_id'],s,p['access_status']))
    pair=PROCESSED/f'walk_pairs_{geoid}.csv.gz';rows=[];gh=digest(gfile)
    # 30 min at upper scenario speed 1.50 m/s => 2700 m; extra snap allowance.
    with gzip.open(pair,'wt',encoding='utf-8',newline='') as f:
        wr=csv.writer(f);wr.writerow(['city_geoid','tract_geoid','facility_osm_id','kind','route_dist_m','approach_dist_m','facility_snap_m','speed_mps','source_graph_sha256','access_status','origin_node_id','facility_node_id'])
        for row,node,snap in zip(sample,on,osnap):
            distances=nx.single_source_dijkstra_path_length(H,node,cutoff=3500,weight='length')
            sums={(kind,minutes):0.0 for kind in ('library','park') for minutes in (10,20,30)}
            sums_upper=dict(sums)
            for end,route in distances.items():
                for kind,id,ps,status in lookup.get(end,[]):
                    meters=route+snap+ps
                    if meters>3500:continue
                    wr.writerow([geoid,row['tract_geoid'],id,kind,round(route,2),round(snap,2),round(ps,2),speed_mps,gh,status,str(node),str(end)])
                    sec=meters/speed_mps
                    for minutes in (10,20,30):
                        if sec<=minutes*60:
                            lo,hi=bounds(status)
                            val=math.exp(-sec/720)
                            sums[(kind,minutes)]+=lo*val
                            sums_upper[(kind,minutes)]+=hi*val
            rows.append(dict(city_geoid=geoid,city=name,tract_geoid=row['tract_geoid'],
                youth_15_17=float(row['estimated_youth_15_17']),snap_m=round(snap,2),
                **{f'{kind}_access_{mins}m':round(sums[(kind,mins)],8) for kind in ('library','park') for mins in (10,20,30)},
                **{f'{kind}_access_upper_{mins}m':round(sums_upper[(kind,mins)],8) for kind in ('library','park') for mins in (10,20,30)}))
    poi_path=PROCESSED/f'poi_osm_{geoid}.csv'
    with poi_path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(points[0]));w.writeheader();w.writerows(points)
    mfile=PROCESSED/f'city_origins_access_{geoid}.csv'
    with mfile.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    receipt={'city':name,'city_geoid':geoid,'started_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
        'source_kind':'RAW_GEOFABRIK_PBF','source_pbf_sha256':source_record['sha256'],
        'source_pbf_url':source_record['original_url'],'source_pbf_path':source_record['path'],
        'original_overpass_cached_response_files':[], 'real_osm_graph_file':str(gfile.relative_to(ROOT)),
        'graph_sha256':gh,'graph_node_count':G.number_of_nodes(),'graph_edge_count':G.number_of_edges(),
        'library_osm_poi':sum(p['kind']=='library' for p in points),'park_osm_poi':sum(p['kind']=='park' for p in points),
        'tract_origins':len(rows),'origin_snap_max_m':max(osnap),'poi_snap_max_m':max(psnap),
        'processed_csv_sha256':digest(mfile),'osm_poi_csv_sha256':digest(poi_path),'od_pairs_sha256':digest(pair),'access_policy':'V19: OSM_TAGGED_PUBLIC reference, UNKNOWN upper bound only',
        'status':'REAL_OSM_NETWORK_ACQUIRED_AND_GRAPH_ROUTED',
        'limit':'All OSM park polygons are potential public access proxies, not verified entrances'}
    atomically_write_json(PROCESSED/f'receipt_{geoid}.json',receipt)
    return receipt


def run_city(geoid):
    import osmnx as ox
    from pyrosm import OSM
    st=geoid[:2];place=geoid[2:]
    census=ROOT/f'data/raw_official/v19/tl_2024_{st}_place.zip'
    if not census.is_file():raise FileNotFoundError(census)
    city=gpd.read_file('zip://'+str(census));select=city[city.PLACEFP.astype(str)==place]
    if len(select)!=1:raise ValueError('CENSUS_PLACE_AMBIGUOUS')
    geometry=gpd.GeoSeries(select.geometry,crs=city.crs).to_crs('EPSG:5070').iloc[0]
    bbox_geom=gpd.GeoSeries([geometry.buffer(4000)],crs='EPSG:5070').to_crs('EPSG:4326').iloc[0]
    pbf,record=acquire_state(st)
    osmr=OSM(str(pbf),bounding_box=list(bbox_geom.bounds),keep_metadata=False)
    nodes,edges=osmr.get_network(network_type='walking',nodes=True)
    if nodes is None or edges is None or len(edges)<100:raise ValueError('NO_REAL_WALK_EDGES_IN_PBF')
    G=osmr.to_graph(nodes,edges,graph_type='networkx',simplify=True)
    features=osmr.get_pois(custom_filter={'amenity':['library'],'leisure':['park']})
    if features is None or features.empty:raise ValueError('NO_PBF_POIS')
    return route_graph(geoid,G,features,record)

if __name__=='__main__':
    import argparse
    a=argparse.ArgumentParser();a.add_argument('--city',choices=list(CITY),required=True)
    args=a.parse_args()
    print(json.dumps(run_city(args.city),indent=2))
