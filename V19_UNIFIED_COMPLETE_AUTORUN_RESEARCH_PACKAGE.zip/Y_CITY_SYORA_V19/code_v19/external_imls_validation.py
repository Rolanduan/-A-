#!/usr/bin/env python3
"""Independent IMLS FY2024 outlet-vs-OSM candidate facility cross-check.

Do NOT use an administrative-entity ('AE') file instead of an outlet file.
The comparison tests mapping/coverage, not school eligibility or library quality.
"""
from __future__ import annotations
import csv,io,json,re,urllib.request,urllib.parse,zipfile,os,shutil
from html.parser import HTMLParser
from pathlib import Path
import numpy as np
import pandas as pd
import geopandas as gpd
from scipy.spatial import cKDTree
from pyproj import Transformer
from acquire_osm_walk import ROOT,CITY,digest
from fetch_verified import fetch,atomically_write_json

URL='https://www.imls.gov/research-evaluation/surveys/public-libraries-survey-pls'
RAW=ROOT/'data/raw_external/v19';OUT=ROOT/'results_v19_gis'

class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[];self.href=None
    def handle_starttag(self,tag,attrs):
        if tag=='a':self.href=dict(attrs).get('href','')
    def handle_endtag(self,tag):
        if tag=='a':self.href=None
    def handle_data(self,data):
        if self.href:self.links.append((data.strip(),self.href))

def discover_imls_2024_csv_link(page):
    # Limit discovery to the official FY2024 block to avoid 2023/2022 substitution.
    match=re.search(r'FY\s*2024',page,re.I)
    if not match:raise ValueError('IMLS_FY2024_MARKER_NOT_PRESENT')
    tail=page[match.start():]
    end=re.search(r'FY\s*2023',tail,re.I)
    html=tail[:end.start() if end else 12000]
    links=Links();links.feed(html)
    candidates=[urllib.parse.urljoin(URL,href) for label,href in links.links
                if ('csv' in label.lower() or 'csv' in href.lower()) and ('zip' in href.lower() or 'csv' in label.lower())]
    candidates=[a for a in candidates if urllib.parse.urlparse(a).hostname in ('www.imls.gov','imls.gov')]
    if not candidates:raise ValueError('IMLS_CSV_LINK_NOT_DISCOVERED_IN_2024_SECTION')
    return candidates[0]

def acquire_imls():
    RAW.mkdir(parents=True,exist_ok=True)
    dest=RAW/'imls_fy2024_official_csv_original.zip';receipt=RAW/'imls_fy2024_receipt.json'
    if dest.is_file() and receipt.is_file():
        r=json.loads(receipt.read_text())
        if digest(dest)==r.get('sha256') and r.get('origin_verification') in ('DIRECT_TLS_SOURCE','HUMAN_ATTESTED_OFFICIAL_TLS'):
            return dest,r
    manual=os.getenv('V19_IMLS_IMPORT_ZIP','').strip()
    attest=os.getenv('V19_IMLS_SOURCE_ATTESTATION','').strip()
    if manual:
        from fetch_verified import validate_bytes
        fp=Path(manual)
        if not fp.is_file() or not attest or not Path(attest).is_file():
            raise ValueError('IMLS_MANUAL_SOURCE_REQUIRES_ORIGINAL_ZIP_AND_ATTESTATION_JSON')
        review=json.loads(Path(attest).read_text())
        validate_bytes(fp,'imls_zip')
        if (review.get('sha256')!=digest(fp) or review.get('publisher')!='Institute of Museum and Library Services'
                or review.get('official_landing_url')!=URL or review.get('human_confirmed_official_https') is not True
                or not str(review.get('human_reviewed_by','')).strip()):
            raise ValueError('IMLS_EXTERNAL_ORIGIN_NOT_HUMAN_ATTESTED')
        shutil.copy2(fp,dest)
        r={'status':'DOWNLOADED_ORIGINAL_WITH_SHA','source_id':'IMLS_PLS_FY2024_OUTLET_ZIP',
           'publisher':'Institute of Museum and Library Services','original_url':review.get('actual_download_url'),
           'sha256':digest(dest),'path':str(dest),'bytes':dest.stat().st_size,
           'origin_verification':'HUMAN_ATTESTED_OFFICIAL_TLS',
           'human_attestation_sha256':digest(Path(attest)),'official_landing_url':URL}
        atomically_write_json(receipt,r)
        return dest,r
    with urllib.request.urlopen(urllib.request.Request(URL,headers={'User-Agent':'Academic-Research-V19/1.0'}),timeout=40) as f: html=f.read().decode('utf-8','replace')
    link=discover_imls_2024_csv_link(html)
    r=fetch(link,dest,source_id='IMLS_PLS_FY2024_OUTLET_ZIP',publisher='Institute of Museum and Library Services',
            extension='imls_zip',attempts=2,transports=('urllib','curl','wget'))
    r['official_landing_url']=URL;atomically_write_json(receipt,r)
    if r.get('status')!='DOWNLOADED_ORIGINAL_WITH_SHA' or r.get('origin_verification')!='DIRECT_TLS_SOURCE':
        raise RuntimeError('IMLS_ZIP_SOURCE_DOWNLOAD_NOT_ATTESTED')
    return dest,r

def read_outlets(original):
    if not zipfile.is_zipfile(original):raise ValueError('IMLS_ORIGINAL_NOT_A_ZIP')
    with zipfile.ZipFile(original) as z:
        candidates=[n for n in z.namelist() if 'outlet' in n.lower() and n.lower().endswith('.csv')]
        if len(candidates)!=1:raise ValueError('IMLS_OUTLET_CSV_NOT_UNAMBIGUOUS:'+str(candidates))
        with z.open(candidates[0]) as raw:
            text=io.TextIOWrapper(raw,encoding='utf-8-sig',errors='replace')
            df=pd.read_csv(text,low_memory=False)
    names={c.upper():c for c in df.columns}
    def find(*alternates):
        for k in alternates:
            if k in names:return names[k]
        raise ValueError('OFFICIAL_IMLS_OUTLET_REQUIRED_FIELD_MISSING:'+repr(alternates))
    lat=find('LATITUDE','LAT','C_LAT','C_LATITUDE')
    lon=find('LONGITUDE','LONGITUD','LON','LONG','C_LONGITUDE','C_LON')
    xy=df[[lat,lon]].apply(pd.to_numeric,errors='coerce')
    good=(xy[lat].between(15,72)&xy[lon].between(-180,-60))
    out=df.loc[good].copy();out['_lat']=xy.loc[good,lat];out['_lon']=xy.loc[good,lon]
    # Bookmobiles and closed outlets are retained with status in QA; filtering needs exact data dictionary.
    if len(out)<1000:raise ValueError('IMLS_OUTLET_UNEXPECTEDLY_FEW_VALID_COORDINATES')
    return out,candidates[0]

def greedy_nearest_match(A,B,radius=500):
    """Deterministic 1-to-1 matching in EPSG5070, avoids multiple OSM POIs inflating recall."""
    if not len(A) or not len(B):return 0
    tree=cKDTree(B);pairs=[]
    dd,idx=tree.query(A,k=min(5,len(B)),distance_upper_bound=radius)
    dd=np.asarray(dd).reshape(len(A),-1);idx=np.asarray(idx).reshape(len(A),-1)
    for i in range(len(A)):
        for d,j in zip(dd[i],idx[i]):
            if np.isfinite(d) and j<len(B):pairs.append((float(d),i,int(j)))
    used_a=set();used_b=set()
    for _,i,j in sorted(pairs):
        if i not in used_a and j not in used_b:used_a.add(i);used_b.add(j)
    return len(used_a)

def validate_city(geoid,official,city_shape,threshold_m=500):
    geom=city_shape.to_crs('EPSG:5070').geometry.iloc[0]
    # compare within city + 500m border, both sources same geographic selection
    bounds=gpd.GeoDataFrame(official,geometry=gpd.points_from_xy(official._lon,official._lat),crs='EPSG:4326').to_crs('EPSG:5070')
    true=bounds[bounds.geometry.intersects(geom.buffer(threshold_m))]
    poi=pd.read_csv(ROOT/f'data/processed/v19_network/poi_osm_{geoid}.csv')
    poi=poi[(poi.kind=='library')&(poi.access_status!='RESTRICTED')]
    osm=gpd.GeoDataFrame(poi,geometry=gpd.points_from_xy(poi.lon,poi.lat),crs='EPSG:4326').to_crs('EPSG:5070')
    osm=osm[osm.geometry.intersects(geom.buffer(threshold_m))]
    if len(true)<1:raise ValueError('OFFICIAL_IMLS_NO_OUTLETS_CITY_'+geoid)
    if len(osm)<1:raise ValueError('OSM_LIBRARIES_NO_OUTLETS_CITY_'+geoid)
    match=greedy_nearest_match(np.array([(x.x,x.y) for x in osm.geometry]),np.array([(x.x,x.y) for x in true.geometry]),radius=threshold_m)
    return dict(city_geoid=geoid,city=CITY[geoid],imls_outlets=len(true),osm_candidate_libraries=len(osm),
                one_to_one_matches=match,osm_match_fraction=match/len(osm),imls_coverage_fraction=match/len(true),
                radius_m=threshold_m,
                qualification='Coordinate proximity cross-check only: not a validated public access, hours or school eligibility measurement')

def run():
    original,receipt=acquire_imls()
    outlets,member=read_outlets(original)
    rows=[]
    for geoid in CITY:
        p=ROOT/f'data/raw_official/v19/tl_2024_{geoid[:2]}_place.zip'
        t=gpd.read_file('zip://'+str(p))
        subset=t[(t.PLACEFP.astype(str).str.zfill(5))==geoid[2:]]
        if len(subset)!=1:raise ValueError('TIGER_PLACE_INVALID_'+geoid)
        rows.append(validate_city(geoid,outlets,subset))
    OUT.mkdir(parents=True,exist_ok=True)
    result=OUT/'V19_IMLS_OSM_INDEPENDENT_COVERAGE.csv'
    pd.DataFrame(rows).to_csv(result,index=False)
    audit={'status':'INDEPENDENT_IMLS_OUTLET_COVERAGE_CROSSCHECK_COMPLETED',
           'n_cities':len(rows),'imls_raw_sha256':digest(original),'imls_original_csv_member':member,
           'comparison_sha256':digest(result),'source_url':receipt.get('original_url'),
           'not_a_causal_validation':True}
    (OUT/'V19_IMLS_CROSSCHECK_RECEIPT.json').write_text(json.dumps(audit,indent=2))
    print(audit);return audit
if __name__=='__main__':run()
