#!/usr/bin/env python3
"""V19: exact linear preference-path switchpoints on observed spatial utility vectors.

No TOPSIS, imputed observations, sampled surveys, or empirical inference about teens.
The frozen V19 reference M1 is never overwritten by exploratory preference paths.
"""
from __future__ import annotations
import json,math
import numpy as np
import pandas as pd
from robustness_lp import utility_matrix,COLS
from acquire_osm_walk import ROOT,digest,CITY
from audit_full_gis import check
OUT=ROOT/'results_v19_gis'

MULTIPLIERS={
    'reference':(1,1,1,1,1,1),
    'household_continuity':(1.6,1.6,1.25,.65,.65,.85),
    'nearby_public_opportunity':(.75,.75,.75,1.75,1.65,1.0),
    'lower_access_safeguard':(.85,.85,.8,.85,.85,2.6),
}

def frozen_reference_weights(scoring):
    s=scoring;wa=s['citywide_population_weight'];wo=s['opportunity_weight'];wt=s['M0_weights'];we=s['opportunity_mean_weight'];wq=s['opportunity_low_decile_weight'];amen=s['amenity_weights']
    w=np.array([wa*wt['rent'],wa*wt['poverty'],wa*wt['broadband'],wo*we*amen['library'],wo*we*amen['park'],wo*wq],float)
    if not np.isfinite(w).all() or (w<=0).any() or abs(w.sum()-1)>1e-8:raise ValueError('REFERENCE_PREFERENCES_NOT_NORMALIZED')
    return w

def policy_archetypes(base):
    b=np.asarray(base,float)
    if len(b)!=6 or abs(b.sum()-1)>1e-8 or (b<=0).any():raise ValueError('EXPECTED_SIX_COMPONENT_BASE')
    ans={}
    for key,mult in MULTIPLIERS.items():
        m=b*np.array(mult,float)
        ans[key]=m/m.sum()
    if not np.allclose(ans['reference'],b,atol=1e-12):raise ValueError('REFERENCE_WAS_CHANGED')
    return ans

def rank_scores(names,values,weights):
    x=np.asarray(values,float);w=np.asarray(weights,float)
    if x.ndim!=2 or len(names)!=len(x) or x.shape[1]!=len(w) or len(set(names))!=len(names):raise ValueError('BAD_SCORING_DIMENSIONS')
    if not np.isfinite(x).all() or not np.isfinite(w).all() or (x<0).any() or (x>1).any() or abs(w.sum()-1)>1e-9 or (w<0).any():raise ValueError('INVALID_SCORE_DOMAIN')
    s=100*(x@w)
    indexed=sorted(range(len(names)),key=lambda i:(-s[i],names[i]))
    ranks={names[i]:k for k,i in enumerate(indexed,1)}
    top=float(s.max())
    return [(names[i],float(s[i]),ranks[names[i]],float(top-s[i])) for i in range(len(names))]

def exact_leader_segments(names,values,w0,w1,tol=1e-9):
    """Champion is piecewise constant along w(t)=(1-t)w0+t*w1.

    Build all pairwise score-line intersections, evaluate each OPEN interval,
    then merge same-champion neighbors. No grid-resolution ambiguity.
    Exact in floating-point arithmetic given frozen observed utility inputs.
    """
    x=np.asarray(values,float);w0=np.asarray(w0,float);w1=np.asarray(w1,float)
    if x.ndim!=2 or x.shape[0]!=len(names) or x.shape[1]!=len(w0) or len(w0)!=len(w1):raise ValueError('PATH_SHAPE_MISMATCH')
    if len(set(names))!=len(names) or not np.isfinite(x).all() or not np.isfinite(w0).all() or not np.isfinite(w1).all():
        raise ValueError('NONFINITE_OR_DUPLICATE_PREFERENCE_PATH_INPUT')
    if abs(w0.sum()-1)>1e-9 or abs(w1.sum()-1)>1e-9 or (w0<0).any() or (w1<0).any():
        raise ValueError('INVALID_PREFERENCE_PATH_WEIGHTS')
    b=x@w0; slope=x@(w1-w0)
    knots=[0.0,1.0]
    for i in range(len(names)):
        for j in range(i+1,len(names)):
            denominator=slope[i]-slope[j]
            if abs(denominator)<1e-13:continue
            t=(b[j]-b[i])/denominator
            if tol<t<1-tol:knots.append(float(t))
    knots=sorted(knots)
    collapsed=[]
    for t in knots:
        if not collapsed or t-collapsed[-1]>1e-10:collapsed.append(t)
    rows=[]
    for lo,hi in zip(collapsed[:-1],collapsed[1:]):
        if hi-lo<=tol:continue
        mid=(lo+hi)/2;score=b+mid*slope
        winner=sorted(range(len(names)),key=lambda i:(-score[i],names[i]))[0]
        if rows and rows[-1]['winner']==names[winner] and abs(rows[-1]['t_to']-lo)<1e-8:
            rows[-1]['t_to']=hi
        else:rows.append({'t_from':lo,'t_to':hi,'winner':names[winner]})
    if not rows or abs(rows[0]['t_from'])>tol or abs(rows[-1]['t_to']-1)>tol:raise ValueError('COVERAGE_OF_PREFERENCE_PATH_FAILED')
    return rows


def calculate_preference_paths(rank,scoring, atol=2e-4):
    names=rank.city.astype(str).tolist();u=utility_matrix(rank)
    w=frozen_reference_weights(scoring)
    observed=100*(u@w)
    if not np.allclose(observed,rank.M1_real_walk_20m.astype(float).to_numpy(),atol=atol,rtol=0):
        raise ValueError('UTILITY_DECOMPOSITION_DISAGREES_WITH_REFERENCE_M1')
    archetypes=policy_archetypes(w)
    rows=[];segments=[]
    for typ,weights in archetypes.items():
        for city,score,order,regret in rank_scores(names,u,weights):
            rows.append(dict(city=city,preference_id=typ,score=round(score,9),rank=order,
              regret_vs_family_leader=round(regret,9),reference_primary=(typ=='reference'),
              scope='Analyst-declared normative scenario, not observed youth preference'))
        if typ!='reference':
            for seg in exact_leader_segments(names,u,w,weights):segments.append(dict(preference_id=typ,**seg,
                    interpretation='Analytic leader-switch intervals on a deterministic affine weight path; no probability'))
    table=pd.DataFrame(rows)
    rg=table.groupby('city',as_index=False)['regret_vs_family_leader'].max().rename(columns={'regret_vs_family_leader':'worst_regret_across_declared_families'})
    rg['minimax_family_choice']=rg.worst_regret_across_declared_families<=rg.worst_regret_across_declared_families.min()+1e-9
    return table,pd.DataFrame(segments),rg,archetypes


def run():
    if check()['status']!='PASS':raise RuntimeError('OFFICIAL_RAW_BYTES_AND_GIS_REQUIRED')
    path=OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv'
    if not path.is_file():raise FileNotFoundError('NO_REAL_NETWORK_RANKING')
    rank=pd.read_csv(path,dtype={'city_geoid':str})
    if len(rank)!=12 or set(rank.city_geoid.str.zfill(7))!=set(CITY):raise ValueError('REQUIRES_FIXED_TWELVE_CITIES')
    cfg=ROOT/'config_v19/reference_model_v19.json';scoring=json.loads(cfg.read_text())['scoring']
    table,segments,regret,archetypes=calculate_preference_paths(rank,scoring)
    files={'scenarios':OUT/'V19_DECLARED_PREFERENCE_FAMILIES.csv',
           'transitions':OUT/'V19_EXACT_LEADER_TRANSITIONS.csv',
           'regret':OUT/'V19_CROSS_FAMILY_MINIMAX_REGRET.csv'}
    for data,filepath in ((table,files['scenarios']),(segments,files['transitions']),(regret,files['regret'])):data.to_csv(filepath,index=False)
    doc={'status':'V19_PREFERENCE_PATHS_COMPUTED','source_ranking_sha256':digest(path),
         'config_sha256':digest(cfg),'file_sha256':{k:digest(v) for k,v in files.items()},
         'archetype_weights':{k:dict(zip(COLS,map(float,v))) for k,v in archetypes.items()},
         'interpretation':'V19 reference scores unchanged. Three analyst-defined counterfactual families, not a teen survey or random probability. Switchpoints are exact within the stated linear-in-weights utility model.'}
    (OUT/'V19_PREFERENCE_PATH_RECEIPT.json').write_text(json.dumps(doc,indent=2));print(json.dumps(doc,indent=2));return doc
if __name__=='__main__':run()
