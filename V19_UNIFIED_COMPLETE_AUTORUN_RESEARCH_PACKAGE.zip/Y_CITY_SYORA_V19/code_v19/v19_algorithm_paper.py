"""Source-bound algorithm discussion for the V19 empirical manuscript."""
from pathlib import Path
import json
from acquire_osm_walk import ROOT,digest

def generate():
    p=ROOT/'results_v19_gis/V19_REAL_GRAPH_ALGORITHM_PILOTS.json'
    if not p.is_file():raise FileNotFoundError('REAL_V19_ALGORITHM_PILOTS_REQUIRED')
    obj=json.loads(p.read_text())
    rows=obj.get('cities',[])
    if obj.get('status')!='REAL_12_CITY_SAMPLED_ALGORITHM_PILOTS' or len(rows)!=12 or not obj.get('reference_M1_unchanged'):
        raise ValueError('ALGORITHM_EVIDENCE_NOT_VALIDATED')
    if any(x['algorithm1_max_abs_distance_difference_m']>1e-7 for x in rows):raise ValueError('DIJKSTRA_REPLAY_DIFF_TOO_BIG')
    gains=[float(x['algorithm2_celf_gain']) for x in rows]
    npaths=sum(int(x['algorithm1_checked_od_pairs']) for x in rows)
    nsmall=sum(x['algorithm2_exact_small_instance_gain'] is not None for x in rows)
    if nsmall!=12:raise ValueError('EXACT_SMALL_INSTANCE_CHECK_MISSING')
    if any(float(x['algorithm2_celf_gain'])>float(x['algorithm2_exact_small_instance_gain'])+1e-9 for x in rows):
        raise ValueError('GREEDY_EXCEEDS_EXACT_OPTIMUM')
    out=ROOT/'paper_v19_official_gis';out.mkdir(parents=True,exist_ok=True)
    t=r'''\subsection{Algorithm I: exact sparse access computation}
We express the directed pedestrian graph with a signed incidence matrix $B$ and conceptual shortest-path operator $D$ in the min-plus algebra. Residential and facility node selectors produce $D_{RF}=S_R D S_F^\top$. Our supplementary V19 routing benchmark computes required sampled OD entries with adaptive forward or reversed-graph Dijkstra rather than constructing a dense $n\times n$ matrix. The resulting accessibility kernel is $K_{gj}=\mathbf{1}(d_{gj}\leq vT)\exp[-d_{gj}/(v\tau)]$. Independent Dijkstra replay on the frozen main engine's genuine graph inputs agreed for __NPATHS__ sampled ordered OD pairs across all twelve real acquired graphs; the verification is a sampled computational equivalence check, not an observed full-city speedup and not proof that OSM records every legal entrance. The original M1 production path remains unchanged.

\subsection{Matrix-consistent opportunity aggregation}
Let $Y$ be the diagonal public-access indicator and $C$ the facility-category incidence matrix. The raw category opportunity matrix is $A=KYC$. Crucially, we preserve the reference model's \emph{nonlinear category saturation}: $a_g=0.55(1-e^{-A_{gL}/2})+0.45(1-e^{-A_{gP}/2})$, before computing its population-weighted mean and weighted tenth percentile. The linear shortcut $KYC\lambda$ is a different model and is prohibited.

\subsection{Algorithm II: conditional facility allocation using lazy greedy}
For candidate contributions $k_{gc}\ge0$, frozen weights $w_g\ge0$, and concave increasing $\phi(x)=1-e^{-x/2}$, the intervention value $F(S)=\sum_gw_g[\phi(A_g^0+\sum_{c\in S}k_{gc})-\phi(A_g^0)]$ is monotone submodular. Diminishing returns follows from the nonincreasing increment of a concave function. Classical cardinality-constrained greedy therefore has the standard $1-1/e$ approximation guarantee; CELF only accelerates identical marginal-gain decisions. We validated the implementation against exact small-instance enumeration for __NSMALL__ city-specific sampled pilots. The candidates are graph-attached, hypothetical service sites, not approved public construction locations; this pilot is not a new city-ranking model.

\subsection{Algorithm III: lower-tail and network-disruption stress}
For tract opportunities $a_g$ and population weights $p_g$, the bottom-$\alpha$ mean $L_\alpha$ averages precisely the lowest $\alpha\sum p_g$ weight, including a fractional boundary tract. This complements rather than replaces the reference $Q_{0.1}$. For an edge removal $e$, we explicitly recompute $D^{(-e)}$, $K^{(-e)}$ and associated tract opportunity; the loss is not inferred by simply subtracting former edge-use counts. All hypothetical closure effects are static graph stress scenarios; they are not observations of real road closures or evidence of temporal urban stability.

\paragraph{Audit and interpretation.} All twelve pilot records are tied to the graph SHA in the source receipt and the artifact SHA256 __HASH__. The optimization and risk results measure bounded computational test cases, not a city-wide optimal public policy. Frozen M0/M1 scores are unaffected.
'''
    t=t.replace('__NPATHS__',str(npaths)).replace('__NSMALL__',str(nsmall)).replace('__HASH__',digest(p))
    path=out/'V19_ALGORITHM_MATRIX_AND_VALIDATION.tex';path.write_text(t)
    return path
if __name__=='__main__':print(generate())
