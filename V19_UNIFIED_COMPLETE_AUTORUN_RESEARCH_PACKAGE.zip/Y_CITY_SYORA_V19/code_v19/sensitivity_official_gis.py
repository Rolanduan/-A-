#!/usr/bin/env python3
"""Deterministic real-GIS structural scenario checks; not statistical confidence levels."""
from pathlib import Path
import pandas as pd,math,json
from score_official_gis import ROOT,CITY,OUT
from acquire_osm_walk import weighted_quantile,digest
from audit_full_gis import check

def run():
 if check()['status']!='PASS':raise RuntimeError('OFFICIAL_GIS_NOT_QA_PASSED')
 d=pd.read_csv(OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv',dtype={'city_geoid':str});d.city_geoid=d.city_geoid.str.zfill(7)
 runs=[]
 for minutes in (10,20,30):
  for w_acs in (.50,.60,.70):
   for equity_rho in (0,.25,.50):
    values=[]
    for row in d.itertuples():
     r=ROOT/f'data/processed/v19_network/city_origins_access_{row.city_geoid}.csv'
     df=pd.read_csv(r);wt=df.youth_15_17.astype(float)
     l=df[f'library_access_{minutes}m'].apply(lambda x:1-math.exp(-x/2))
     p=df[f'park_access_{minutes}m'].apply(lambda x:1-math.exp(-x/2))
     a=.55*l+.45*p
     mean=float((wt*a).sum()/wt.sum());q10=weighted_quantile(a,wt,.1)
     final=w_acs*row.M0_acs_citywide+(1-w_acs)*100*((1-equity_rho)*mean+equity_rho*q10)
     values.append(dict(city_geoid=row.city_geoid,city=row.city,score=final))
    winner=sorted(values,key=lambda x:(-x['score'],x['city']))[0]
    for v in values:
     runs.append(dict(minutes=minutes,w_citywide_acs=w_acs,equity_rho=equity_rho,city=v['city'],score=round(v['score'],7),is_winner=int(v['city']==winner['city'])))
 out=pd.DataFrame(runs)
 if len(out)!=27*12:raise ValueError('SCENARIO_COUNT_MISMATCH')
 path=OUT/'REAL_GIS_27_SCENARIOS.csv';out.to_csv(path,index=False)
 champ=out.groupby('city',as_index=False).is_winner.sum().sort_values(['is_winner','city'],ascending=[False,True])
 champ.to_csv(OUT/'REAL_GIS_WINNER_SCENARIO_COUNTS.csv',index=False)
 receipt={'status':'SCENARIOS_ACTUALLY_RECOMPUTED','scenario_count':27,'metric':'frequency_under_specified_deterministic_scenarios_not_statistical_confidence','csv_sha256':digest(path),'winners':champ.to_dict(orient='records')}
 (OUT/'scenario_receipt.json').write_text(json.dumps(receipt,indent=2))
 print(json.dumps(receipt,indent=2));return out
if __name__=='__main__':run()
