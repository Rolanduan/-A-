#!/usr/bin/env python3
"""Exact linear multiobjective robustness of observed 12-city dimension vectors.

LP certificates quantify rankings over a SPECIFIED normative weight polytope.
These results are not uncertainty about unobserved student outcomes.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import linprog
from acquire_osm_walk import ROOT,digest,CITY

COLS=['rent_burden','poverty','broadband','library_access','park_access','equity_access']


def utility_matrix(df):
    if not {'city','rent_burden','poverty','broadband','library_mean_normalized','park_mean_normalized','opportunity_weighted_Q10'}<=set(df.columns):
        raise ValueError('SIX_DIMENSION_SOURCE_COLUMNS_REQUIRED')
    vals=np.column_stack([df['rent_burden'].to_numpy(dtype=float),df['poverty'].to_numpy(dtype=float),
        df['broadband'].to_numpy(dtype=float),df['library_mean_normalized'].to_numpy(dtype=float),
        df['park_mean_normalized'].to_numpy(dtype=float),df['opportunity_weighted_Q10'].to_numpy(dtype=float)])
    if not np.isfinite(vals).all() or (vals<-1e-9).any() or (vals>1+1e-9).any():
        raise ValueError('UNNORMALIZED_OR_UNOBSERVED_UTILITY')
    return vals


def validate_bounds(lower,upper,d):
    lo=np.broadcast_to(np.array(lower,float),(d,));hi=np.broadcast_to(np.array(upper,float),(d,))
    if not np.isfinite(lo).all() or not np.isfinite(hi).all() or (lo<0).any() or (hi>1).any() or (lo>hi).any() or lo.sum()>1+1e-12 or hi.sum()<1-1e-12:
        raise ValueError('INFEASIBLE_PREFERENCE_WEIGHT_POLYTOPE')
    return [(float(a),float(b)) for a,b in zip(lo,hi)]


def polytope_extreme(delta,bounds,maximize=False):
    d=np.array(delta,float)
    opt=linprog(-d if maximize else d, A_eq=[np.ones(len(d))],b_eq=[1.],
                bounds=bounds,method='highs')
    if not opt.success:raise RuntimeError('WEIGHT_LP_FAILURE:'+opt.message)
    return float(d@opt.x),[float(v) for v in opt.x]


def dominance_and_regret(values,names,lower=.03,upper=.40,tolerance=1e-10):
    u=np.asarray(values,float);n,d=u.shape
    if n<2 or n!=len(names) or not np.isfinite(u).all() or np.any(u<-1e-9) or np.any(u>1+1e-9):
        raise ValueError('INVALID_CITY_UTILITY_MATRIX')
    bounds=validate_bounds(lower,upper,d)
    rows=[]
    for i in range(n):
        dominates=[];dominated_by=[];min_margin=float('inf');max_regret=0.;worst_city=None
        for j in range(n):
            if j==i:continue
            diff=u[i]-u[j]
            if np.all(diff>=-tolerance) and np.any(diff>tolerance):dominates.append(names[j])
            if np.all(diff<=tolerance) and np.any(diff<-tolerance):dominated_by.append(names[j])
            wmin,certificate=polytope_extreme(diff,bounds)
            min_margin=min(min_margin,wmin)
            worst_gap,_=polytope_extreme(u[j]-u[i],bounds,maximize=True)
            if worst_gap>max_regret:max_regret=worst_gap;worst_city=names[j]
        rows.append(dict(city=names[i],pareto_non_dominated=len(dominated_by)==0,
            dominates='|'.join(dominates),dominated_by='|'.join(dominated_by),
            all_opponent_worst_margin=round(min_margin,10),
            robust_rank_one_entire_polytope=bool(min_margin>=-tolerance),
            maximum_regret_over_weights=round(max_regret,10),
            max_regret_opponent=worst_city or 'none'))
    return rows


def run():
    from audit_full_gis import check
    if check()['status']!='PASS':raise RuntimeError('REAL_GIS_SOURCE_QA_REQUIRED_BEFORE_LP')
    p=ROOT/'results_v19_gis/FINAL_12_CITY_REAL_GIS_RANKING.csv'
    df=pd.read_csv(p,dtype={'city_geoid':str})
    if len(df)!=12 or len(set(df.city))!=12:raise ValueError('NOT_TWELVE_UNIQUE_CITIES')
    u=utility_matrix(df)
    result=pd.DataFrame(dominance_and_regret(u,df.city.to_list()))
    out=ROOT/'results_v19_gis/V19_PARETO_LP_MINIMAX_REGRET.csv'
    result.to_csv(out,index=False)
    p2=ROOT/'qa_v19/LP_WEIGHT_POLYTOPE_CERTIFICATE.json'
    p2.parent.mkdir(exist_ok=True,parents=True)
    p2.write_text(json.dumps({'status':'EXACT_SCIPY_LP_SOLVED_FOR_12_CITIES','source_ranking_sha256':digest(p),
       'output_sha256':digest(out),'utility_order':COLS,'weight_lower_each':.03,'weight_upper_each':.40,
       'scope':'Reference preference region is a normative choice, not sampled preferences or a posterior.\n'
               'Pareto and LP quantify only recorded utility dimensions, not causal outcomes.'},indent=2))
    print(result.to_string(index=False));return result
if __name__=='__main__':run()
