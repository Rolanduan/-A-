#!/usr/bin/env python3
"""Build the V19.2 empirical manuscript in the supplied official optional layout.

This builder is fail-closed: no paper is generated unless the actual 12-city
Census + OSM GIS audit, scenario receipt, system evidence and figures exist.
All quantitative claims are read from frozen result files.
"""
from pathlib import Path
import json, subprocess, shutil, re
import pandas as pd
import fitz
from audit_full_gis import check
from score_official_gis import ROOT, OUT, digest
from paper_layout_contract import validate_tex_structure, audit_pdf_layout, write_audit


def tex(s):
    return (str(s).replace('\\', r'\textbackslash{}').replace('&', r'\&')
            .replace('%', r'\%').replace('_', r'\_').replace('#', r'\#')
            .replace('$', r'\$').replace('{', r'\{').replace('}', r'\}'))


def _load_supplemental_manifest():
    manifest_path = ROOT / 'paper_supplemental' / 'manifest.json'
    if not manifest_path.is_file():
        raise FileNotFoundError('SUPPLEMENTAL_DOCUMENT_MANIFEST_MISSING:' + str(manifest_path))
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    docs = manifest.get('documents', [])
    seen = set()
    normalized = []
    for item in docs:
        doc_id = str(item.get('id', '')).strip()
        title = str(item.get('title', '')).strip()
        rel = str(item.get('path', '')).strip()
        if not doc_id or not title or not rel or doc_id in seen:
            raise ValueError('INVALID_OR_DUPLICATE_SUPPLEMENTAL_DOCUMENT_ENTRY')
        seen.add(doc_id)
        p = (ROOT / rel).resolve()
        if ROOT.resolve() not in p.parents or p.suffix.lower() != '.tex' or not p.is_file():
            raise FileNotFoundError('SUPPLEMENTAL_TEX_MISSING_OR_OUTSIDE_PROJECT:' + rel)
        min_pages = int(item.get('pages_min', 1)); max_pages = int(item.get('pages_max', 2))
        if min_pages != 1 or max_pages != 2:
            raise ValueError('OFFICIAL_OPTIONAL_LAYOUT_SUPPLEMENTAL_DOCS_MUST_BE_1_TO_2_PAGES:' + doc_id)
        normalized.append({'id': doc_id, 'title': title, 'source': p, 'pages_min': min_pages, 'pages_max': max_pages})
    registered = {x['source'].resolve() for x in normalized}
    folder = ROOT / 'paper_supplemental'
    unregistered = [p for p in folder.glob('*.tex') if p.resolve() not in registered]
    if unregistered:
        raise ValueError('UNREGISTERED_SUPPLEMENTAL_TEX_FILES:' + ','.join(p.name for p in unregistered))
    return normalized


def _assumption_rows(cfg):
    s = cfg['scoring']
    items = [
        ('A1', 'Fixed purposive sample', 'The twelve candidate municipalities are frozen before the final score is calculated; this prevents outcome-driven city substitution.', 'Inference is limited to these cities; no national representativeness is claimed.'),
        ('A2', 'Age 15–17 proxy', 'ACS detailed tables provide a consistent 15–17 proxy for the 14–18 target; ages 14 and 18 are not silently imputed.', 'The result describes an age proxy, not every person aged 14–18.'),
        ('A3', 'Tract-to-city population allocation', 'Tract counts are allocated by geometric overlap because full residential microdata are unavailable.', 'Uniform-within-tract allocation is an approximation; spatial uncertainty is reported.'),
        ('A4', f"Walking speed {s['walking_speed_m_per_s']:.2f} m/s", 'A transparent reference speed converts network distance to time; it is not an individually calibrated speed.', 'Travel-time conclusions are conditional; cutoff sensitivity is recomputed at 10, 20 and 30 minutes.'),
        ('A5', f"Reference cutoff {s['walk_threshold_minutes']} minutes; decay tau={s['travel_decay_tau_minutes']} minutes", 'A fixed reference threshold makes the primary comparison reproducible; alternative cutoffs are treated as scenarios.', 'The winner may change under other time budgets; scenario outcomes are not confidence probabilities.'),
        ('A6', 'Libraries and parks as candidate opportunities', 'These are observable public-resource categories with citywide coverage potential and are relevant to learning and recreation.', 'A mapped feature does not prove opening hours, gate location, fee status or individual eligibility.'),
        ('A7', 'Frozen M0 anchors and weights', 'Rent, poverty and broadband anchors/weights are fixed in the model configuration before interpreting the ranking.', 'The M0 score is a normative composite, not an objective natural constant.'),
        ('A8', 'Frozen M1 and opportunity weights', 'The configured ACS/opportunity, library/park and mean/lower-decile weights express an explicit reference preference.', 'Alternative weights are evaluated in the 27-scenario matrix; values are not estimated teen preferences.'),
        ('A9', 'No invented capacity or admission', 'No facility capacity, school admission right or actual participation rate is inferred from a point location.', 'E2SFCA and guaranteed-use claims are excluded unless independently observed capacity/eligibility data become available.'),
        ('A10', 'Cross-sectional and mixed-vintage evidence', 'ACS 2024 five-year data and the OSM acquisition snapshot have different temporal supports.', 'The model is a cross-sectional conditional comparison, not a causal or longitudinal measure of youth wellbeing.'),
    ]
    return '\n'.join(' & '.join([tex(a), tex(b), tex(c), tex(d)]) + r' \\' for a,b,c,d in items)


def _systems_rows(systems):
    rows = []
    for r in systems.itertuples(index=False):
        hyp = getattr(r, 'hypothesis', '')
        metric = getattr(r, 'observed_metric', '')
        value = getattr(r, 'value', '')
        status = getattr(r, 'status', '')
        rows.append(' & '.join([tex(hyp), tex(metric), tex(value), tex(status)]) + r' \\')
    return '\n'.join(rows)


def _load_ai_ledger():
    path = ROOT / 'sources/ai_tool_use_ledger.csv'
    if not path.is_file():
        raise FileNotFoundError('AI_TOOL_USE_LEDGER_MISSING:' + str(path))
    ledger = pd.read_csv(path, dtype=str).fillna('')
    required = {'tool_name', 'provider', 'model_version', 'access_date', 'used_for', 'citation_url'}
    if not required.issubset(ledger.columns) or ledger.empty:
        raise ValueError('AI_TOOL_USE_LEDGER_SCHEMA_OR_ROWS_INVALID')
    rows = []
    for r in ledger.to_dict(orient='records'):
        if not all(str(r.get(k, '')).strip() for k in required):
            raise ValueError('AI_TOOL_USE_LEDGER_HAS_BLANK_REQUIRED_FIELDS')
        rows.append(r)
    return rows


def _load_additional_references():
    path = ROOT / 'sources/additional_references.csv'
    if not path.is_file():
        raise FileNotFoundError('ADDITIONAL_REFERENCE_REGISTRY_MISSING:' + str(path))
    registry = pd.read_csv(path, dtype=str).fillna('')
    required = {'author_or_publisher', 'title', 'year', 'source_type', 'doi_or_url', 'used_in_manuscript'}
    if not required.issubset(registry.columns):
        raise ValueError('ADDITIONAL_REFERENCE_REGISTRY_SCHEMA_INVALID')
    selected = []
    for row in registry.to_dict(orient='records'):
        used = str(row.get('used_in_manuscript', '')).strip().casefold() in ('true', 'yes', '1', 'y')
        if not used:
            continue
        for key in ('author_or_publisher', 'title', 'year', 'source_type', 'doi_or_url'):
            if not str(row.get(key, '')).strip():
                raise ValueError('USED_REFERENCE_HAS_BLANK_FIELD:' + key)
        url = str(row['doi_or_url']).strip()
        if not url.startswith(('https://', 'http://')) or any(ch in url for ch in '{}\n\r'):
            raise ValueError('USED_REFERENCE_URL_INVALID:' + url)
        selected.append(row)
    return selected


def _reference_items(source_kinds, ai_rows, additional_refs):
    items = [
        r"U.S. Census Bureau. (2024). \textit{American Community Survey 2024 Five-Year Table-Based Summary File}. https://www.census.gov/programs-surveys/acs/data/summary-file.2024.html.",
        r"U.S. Census Bureau. (2024). \textit{2024 TIGER/Line Shapefiles: Places and Census Tracts}. https://www.census.gov/geographies/mapping-files/time-series/geo/tiger-line-file.2024.html.",
        r"OpenStreetMap contributors. (2026). \textit{OpenStreetMap geographic data and Open Database License (ODbL)}. https://www.openstreetmap.org/copyright.",
        r"Boeing, G. (2025). Modeling and analyzing urban networks and amenities with OSMnx. \textit{Geographical Analysis, 57}(4), 567--577. https://doi.org/10.1111/gean.70009.",
        r"Luo, W., \& Wang, F. (2003). Measures of spatial accessibility to health care in a GIS environment: Synthesis and a case study in the Chicago region. \textit{Environment and Planning B: Planning and Design, 30}(6), 865--884. https://doi.org/10.1068/b29120.",
        r"OECD \& European Commission Joint Research Centre. (2008). \textit{Handbook on constructing composite indicators: Methodology and user guide}. OECD Publishing. https://doi.org/10.1787/9789264043466-en.",
        r"von Bertalanffy, L. (1968). \textit{General system theory: Foundations, development, applications}. George Braziller.",
        r"Meadows, D. H. (1999). \textit{Leverage points: Places to intervene in a system}. The Sustainability Institute. https://donellameadows.org/archives/leverage-points-places-to-intervene-in-a-system/.",
        r"Wilkinson, M. D., et al. (2016). The FAIR guiding principles for scientific data management and stewardship. \textit{Scientific Data, 3}, 160018. https://doi.org/10.1038/sdata.2016.18.",
        r"National Academies of Sciences, Engineering, and Medicine. (2019). \textit{Reproducibility and replicability in science}. The National Academies Press. https://doi.org/10.17226/25303.",
        r"Jambor, H. K. (2025). A checklist for designing and improving the visualization of scientific data. \textit{Nature Cell Biology, 27}, 879--883. https://doi.org/10.1038/s41556-025-01684-z.",
        r"Lahdelma, R., \& Salminen, P. (2001). SMAA-2: Stochastic multicriteria acceptability analysis for group decision making. \textit{Operations Research, 49}(3), 444--454. https://doi.org/10.1287/opre.49.3.444.11220.",
        r"OSMnx developers. (2026). \textit{OSMnx documentation}. https://osmnx.readthedocs.io/.",
    ]
    if any('GEOFABRIK' in str(x).upper() for x in source_kinds):
        items.append(r"Geofabrik GmbH. (2026). \textit{OpenStreetMap regional extracts}. https://download.geofabrik.de/.")
        items.append(r"Pyrosm developers. (2026). \textit{Pyrosm documentation}. https://pyrosm.readthedocs.io/.")
    ai_citations = []
    for row in ai_rows:
        items.append(
            tex(row['provider']) + '. (' + tex(row['access_date'][:4]) + '). ' +
            r'\textit{' + tex(row['tool_name'] + ' (' + row['model_version'] + ')') +
            r'} [AI tool]. Used for ' + tex(row['used_for']) + '. ' + tex(row['citation_url']) + '.'
        )
        ai_citations.append(str(len(items)))
    for row in additional_refs:
        entry = tex(row['author_or_publisher']) + '. (' + tex(row['year']) + '). ' + r'\textit{' + tex(row['title']) + r'}.'
        if str(row.get('publication_or_dataset', '')).strip():
            entry += ' ' + tex(row['publication_or_dataset']) + '.'
        entry += ' [' + tex(row['source_type']) + ']. ' + r'\url{' + row['doi_or_url'].strip() + r'}.'
        if str(row.get('access_date', '')).strip():
            entry += ' Accessed ' + tex(row['access_date']) + '.'
        items.append(entry)
    return '\n'.join(r'\item ' + x for x in items), ','.join(ai_citations)


def build():
    qa = check()
    if qa['status'] != 'PASS':
        raise RuntimeError('REAL_GIS_PAPER_BLOCKED: source audit not passed')
    csvpath = OUT / 'FINAL_12_CITY_REAL_GIS_RANKING.csv'
    d = pd.read_csv(csvpath, dtype={'city_geoid': str}).sort_values('M1_rank')
    if len(d) != 12:
        raise ValueError('minimum 12 comparable cities required')
    systems_path = ROOT / 'results_v19/SYSTEMS_THEORY_EMPIRICAL_TESTS.csv'
    if not systems_path.is_file():
        raise FileNotFoundError('V19 actual systems mechanism tests missing')
    systems = pd.read_csv(systems_path)
    if len(systems) < 8:
        raise ValueError('SYSTEMS_EVIDENCE_ROWS_LT_8')
    scenario = OUT / 'scenario_receipt.json'
    if not scenario.exists():
        raise FileNotFoundError('27 actual GIS scenarios must run before paper')
    sce = json.loads(scenario.read_text())
    if sce.get('status') != 'SCENARIOS_ACTUALLY_RECOMPUTED' or sce.get('scenario_count') != 27:
        raise ValueError('scenario suite not executed')
    figs = ROOT / 'figures/v19_official_gis'
    need = ['F19_GIS_01_REAL_CITY_RANKING.pdf', 'F19_GIS_02_RANK_BUMP.pdf', 'F19_GIS_03_AUSTIN_REAL_WALK_MAP.pdf']
    for n in need:
        if not (figs / n).exists():
            raise FileNotFoundError('real data figure missing: ' + n)

    # The V19 manuscript is not an upgraded boilerplate: the claim section is
    # generated from actual same-source ablation, raw-network replay, IMLS and LP.
    from paper_claims import generate as generate_v19_claims
    v19_claims_tex = generate_v19_claims()
    from v19_algorithm_paper import generate as build_algorithm_analysis
    build_algorithm_analysis()  # requires twelve source-backed pilot checks
    from decision_release import validate as validate_v19_decision
    if validate_v19_decision().get('status')!='PASS_V19_DECISION_EVIDENCE_GATE':
        raise RuntimeError('V19_DECISION_EVIDENCE_NOT_AUDITED')
    from official_summary import acquire as acquire_official_summary
    acquire_official_summary()  # actual COMAP original bytes and publisher provenance
    supplements = _load_supplemental_manifest()
    ai_rows = _load_ai_ledger()
    additional_refs = _load_additional_references()
    first, last = d.iloc[0], d.iloc[-1]
    x = d.copy(); x['delta_rank'] = x.M0_rank - x.M1_rank
    change = x.iloc[x.delta_rank.abs().argmax()]
    worst = d.iloc[d.opportunity_weighted_Q10.argmin()]
    winners = {r['city']: r['is_winner'] for r in sce['winners']}
    top5 = ', '.join(f"{tex(r.city)} ({r.M1_real_walk_20m:.1f})" for r in list(d.itertuples())[:5])
    table = '\n'.join(
        f"{int(r.M1_rank)} & {tex(r.city)} & {r.M0_acs_citywide:.2f} & {r.M1_real_walk_20m:.2f} & {int(r.M0_rank)} & {int(r.M1_rank)} & {int(r.youth_city_acs_15_17):,} \\\\" 
        for r in d.itertuples())
    scenario_table = '\n'.join(
        f"{tex(city)} & {int(count)} / 27 \\\\" 
        for city, count in sorted(winners.items(), key=lambda x: (-x[1], x[0])))
    systems_table = _systems_rows(systems)
    source_kinds = []
    for geoid in d.city_geoid.astype(str):
        rec = ROOT / f'data/processed/v19_network/receipt_{geoid}.json'
        if rec.is_file():
            source_kinds.append(json.loads(rec.read_text()).get('source_kind', ''))
    references_tex, ai_citation_numbers = _reference_items(source_kinds, ai_rows, additional_refs)
    ai_statement = '; '.join(f"{r['provider']} {r['tool_name']} ({r['model_version']}): {r['used_for']}" for r in ai_rows)
    geofabrik_used = any('GEOFABRIK' in str(x).upper() for x in source_kinds)
    if geofabrik_used:
        network_source_note = r"The regional PBF fallback was supplied by Geofabrik and parsed with Pyrosm \src{14,15}."
    else:
        network_source_note = r"The walk-network acquisition used OSMnx and cached original Overpass responses \src{13}."
    cfg = json.loads((ROOT / 'config_v19/reference_model_v19.json').read_text())
    s = cfg['scoring']
    assumptions_table = _assumption_rows(cfg)
    conf = {
        'title': 'A Systems-Aware Comparison of Youth Opportunity Across Twelve U.S. Cities',
        'winner': tex(first.city), 'winner_score': f'{first.M1_real_walk_20m:.2f}',
        'runner_up': tex(d.iloc[1].city), 'runner_score': f'{d.iloc[1].M1_real_walk_20m:.2f}',
        'last': tex(last.city), 'lastscore': f'{last.M1_real_walk_20m:.2f}',
        'top5': top5, 'changed': tex(change.city), 'changedfrom': str(int(change.M0_rank)),
        'changedto': str(int(change.M1_rank)), 'worstq10': tex(worst.city),
        'worstq10value': f'{worst.opportunity_weighted_Q10:.3f}',
        'scenarios_won': str(winners.get(first.city, 0)), 'tablerows': table,
        'scenario_table_rows': scenario_table, 'systemrows': systems_table,
        'system_count': str(len(systems)), 'acs_hash': str(first.acs_B01001_sha256),
        'score_hash': digest(csvpath), 'assumptions_rows': assumptions_table,
        'walk_speed': f"{s['walking_speed_m_per_s']:.2f}",
        'walk_minutes': str(s['walk_threshold_minutes']),
        'tau': str(s['travel_decay_tau_minutes']),
        'w_acs': f"{s['citywide_population_weight']:.2f}",
        'w_opportunity': f"{s['opportunity_weight']:.2f}",
        'w_library': f"{s['amenity_weights']['library']:.2f}",
        'w_park': f"{s['amenity_weights']['park']:.2f}",
        'w_mean': f"{s['opportunity_mean_weight']:.2f}",
        'w_q10': f"{s['opportunity_low_decile_weight']:.2f}",
        'w_rent': f"{s['M0_weights']['rent']:.2f}",
        'w_poverty': f"{s['M0_weights']['poverty']:.2f}",
        'w_broadband': f"{s['M0_weights']['broadband']:.2f}",
        'rent_low': f"{s['M0_anchors']['rent_low']:.2f}",
        'rent_high': f"{s['M0_anchors']['rent_high']:.2f}",
        'poverty_high': f"{s['M0_anchors']['poverty_high']:.2f}",
        'broadband_low': f"{s['M0_anchors']['broadband_low']:.2f}",
        'snapshots': ', '.join(f"{tex(r.city)}: {str(r.network_graph_sha256)[:10]}" for r in list(d.itertuples())[:4]),
    }

    paper = ROOT / 'paper_v19_official_gis'
    paper.mkdir(exist_ok=True)
    supp_out = paper / 'supplemental_documents'
    supp_out.mkdir(exist_ok=True)
    news = r'''\textbf{A better city ranking starts with the streets between people and places.}

A city can advertise hundreds of parks, libraries and schools. But an inventory does not tell a teenager whether those places are reachable from the neighbourhood where they live. Nor does a citywide average show whether some neighbourhoods are left far behind. This research therefore asks a narrower and more testable question: under a clearly stated set of family-condition and public-opportunity priorities, how do twelve selected U.S. cities compare?

The study combines original U.S. Census Bureau data with 2024 municipal and census-tract boundaries and actual pedestrian street networks derived from OpenStreetMap. The team first calculated a transparent baseline from household rent burden, poverty and broadband measures. It then made a substantive revision: instead of counting amenities as if every resident could use them equally, it measured potential walking access from population-weighted census-tract origins to mapped libraries and parks. The model also examined the lower-opportunity tenth of the population distribution, so a strong citywide average could not completely hide poorly served areas.

Under the frozen reference assumptions, __WINNER__ ranked first with __WINNER_SCORE__ points out of 100; __RUNNER_UP__ followed with __RUNNER_SCORE__ points. The five highest-ranked cities were __TOP5__. The largest change between the baseline and revised model occurred in __CHANGED__, which moved from rank __CHANGED_FROM__ to rank __CHANGED_TO__. The first-place city led __SCENARIOS_WON__ of 27 deliberately specified sensitivity scenarios. These scenario counts describe only the chosen set of parameter combinations; they are not a poll of teenagers, a probability of happiness or a statistical confidence level.

The result should be read as a conditional comparison, not a universal instruction about where families should live. Census ages 15--17 are a proxy for the wider 14--18 target. A mapped park does not prove that its gate is open or that a particular route is safe after dark. A school point does not establish admission rights. Walking speed, household constraints and the relative value of libraries and parks differ across people.

The practical contribution is a more transparent way to ask the question. By linking original demographic data, actual street networks, neighbourhood-level opportunity and explicit assumptions, the model makes it possible to inspect not only which city leads, but why the ranking changes and where the evidence is weak. The next step is independent field validation of facility entrances, hours and access rules, followed by research with adolescents themselves. A city model can help structure that conversation; it cannot replace the lived experience of young people.'''
    news = (news.replace('__WINNER__', conf['winner']).replace('__WINNER_SCORE__', conf['winner_score'])
            .replace('__RUNNER_UP__', conf['runner_up']).replace('__RUNNER_SCORE__', conf['runner_score'])
            .replace('__TOP5__', conf['top5']).replace('__CHANGED__', conf['changed'])
            .replace('__CHANGED_FROM__', conf['changedfrom']).replace('__CHANGED_TO__', conf['changedto'])
            .replace('__SCENARIOS_WON__', conf['scenarios_won']))
    news_path = supp_out / 'nontechnical_news_article.tex'
    news_path.write_text(news, encoding='utf-8')
    for item in supplements:
        shutil.copy2(item['source'], supp_out / item['source'].name)

    extra_supplement_tex = []
    for item in supplements:
        extra_supplement_tex.append(
            r'\clearpage' + '\n' + r'\subsection*{' + tex(item['title']) + '}' + '\n' +
            r'\addcontentsline{toc}{subsection}{' + tex(item['title']) + '}' + '\n' +
            r'\input{supplemental_documents/' + item['source'].name + '}' + '\n')
    extra_supplement_tex = '\n'.join(extra_supplement_tex)
    supplemental_titles = ['Nontechnical News Article'] + [x['title'] for x in supplements]

    template = r'''\documentclass[12pt,letterpaper]{article}
\usepackage[margin=.78in]{geometry}
\usepackage[T1]{fontenc}
\usepackage{lmodern,microtype,booktabs,longtable,tabularx,amsmath,amssymb,graphicx,fancyhdr,xcolor,hyperref,array}
\usepackage{float}
\hypersetup{colorlinks=true,linkcolor=blue!55!black,urlcolor=blue!55!black}
\setlength{\parskip}{5pt}\setlength{\parindent}{0pt}\setlength{\headheight}{15pt}
\pagestyle{fancy}\fancyhf{}\fancyhead[L]{Independent research | Y--CITY / SYORA}\fancyhead[R]{2024 Census and observed OSM network}\fancyfoot[C]{\thepage}
\newcommand{\src}[1]{\textsuperscript{[#1]}}
\renewcommand{\contentsname}{Table of Contents}
\setcounter{secnumdepth}{2}
\begin{document}
\pagenumbering{arabic}
\thispagestyle{plain}
\begin{center}
{\Large\bfseries __TITLE__}\\[6pt]
{\large Real Pedestrian-Network Accessibility, Census Demography, and Conditional Ranking}\\[6pt]
{\small Independent research manuscript; not an official competition submission}
\end{center}
\section*{Summary Sheet}
\addcontentsline{toc}{section}{Summary Sheet}
\textbf{Problem.} Which of twelve selected U.S. cities offers the strongest measurable combination of household conditions and potentially reachable public learning and green-space opportunities for residents in the high-school age range, under explicit and reviewable assumptions?

\textbf{Approach.} We combine original 2024 ACS five-year tables, official 2024 TIGER/Line place and tract boundaries, and observed OpenStreetMap pedestrian networks. A transparent M0 household-condition baseline is substantively revised to M1, which measures population-weighted network access to libraries and parks and accounts for the lower-opportunity tenth of the population distribution.

\textbf{Actual results.} Under the frozen reference scenario, \textbf{__WINNER__ ranks first with __WINNER_SCORE__/100}; __RUNNER_UP__ ranks second with __RUNNER_SCORE__/100. The first five are __TOP5__. The largest M0-to-M1 rank change is __CHANGED__, moving from __CHANGED_FROM__ to __CHANGED_TO__. The leading city wins __SCENARIOS_WON__ of 27 declared sensitivity scenarios.

\textbf{Conclusion and limits.} The result is a conditional decision ranking for the selected sample, not a universal judgement or a causal measure of adolescent wellbeing. Ages 15--17 are a proxy for ages 14--18; mapped facilities do not prove entrance, opening-hour or eligibility conditions. The full paper reports the data hashes, GIS calculations, sensitivity analysis and limitations.
\clearpage
\tableofcontents
\clearpage

\section{Introduction and Restatement of the Problem}
\subsection{Introduction}
A city's resources cannot be evaluated independently of the movement constraints of its residents. A downtown library may appear in an inventory but be unreachable after school from the neighbourhoods where adolescents live. A municipal average can also hide uneven exposure to opportunity. A systems perspective therefore treats youth opportunity as an interaction among population distribution, public resources, networks, institutional boundaries and family constraints, rather than as a simple count of amenities \src{7,8}.

\begin{figure}[H]\centering
\includegraphics[width=.95\linewidth]{D19-01_systems_architecture.pdf}
\caption{Systems Architecture: source data, directed graph kernel, frozen city ranking and three independently audited interpretation branches. This Draw.io-defined schematic is a computational architecture, not a measured causal diagram.}
\end{figure}

\subsection{Restatement of the problem in our own words}
The research task is to compare at least ten U.S. cities and identify which performs best for high-school-age residents under a clearly defined, defensible interpretation of a good city to live in. The comparison must use evidence rather than reputation, explain its assumptions and mathematical model, demonstrate how the model is applied, test whether the answer changes when assumptions are altered, acknowledge strengths and limitations, and communicate the result in a concise nontechnical document. We operationalize this task for twelve preselected municipalities and distinguish potential access from guaranteed access or actual adolescent outcomes.

\subsection{Study population, city sample and scope}
The twelve municipalities are Austin, Boston, Chicago, Denver, Madison, Minneapolis, Pittsburgh, Portland, Raleigh, San Diego, Seattle and Atlanta. The sample is purposive, not a probability sample of all U.S. cities. ACS ages 15--17 are used as a consistent proxy for the broader 14--18 target; no individual residence, school enrolment or student preference is inferred.

\section{Assumptions with Justifications}
The following assumptions are declared before interpreting the ranking. They simplify a complex urban system while making the consequences and test conditions explicit.
\begin{longtable}{p{.055\textwidth}p{.20\textwidth}p{.36\textwidth}p{.30\textwidth}}
\toprule ID & Assumption & Justification & Consequence / test \\
\midrule
__ASSUMPTION_ROWS__
\bottomrule
\end{longtable}

\section{Presentation of Model and Solution}
\subsection{Data sources and geographic alignment}
The analysis uses the full original 2024 ACS five-year Table-Based Summary File tables B01001 (age), B25070 (gross rent as a share of income), B28002 (broadband) and B17001 (poverty), preserving estimate and margin-of-error fields. The original Census table bytes are SHA256-hashed before parsing. Official 2024 TIGER/Line PLACE and TRACT geometries provide city and neighbourhood boundaries; city and tract identifiers are joined by GEOID rather than name. Tract-to-city population is area-weighted, an explicit approximation rather than a claim about exact residential locations. \src{1,2}

For walking accessibility, actual OpenStreetMap pedestrian network responses or Geofabrik PBF originals are retained and hashed separately from derived GraphML. OSMnx constructs or projects the routable graph; the route calculation uses network distance, not straight-line distance. The graph extends beyond municipal boundaries so that cross-border facilities can contribute where the route is real. The OpenStreetMap data are licensed under ODbL and are attributed accordingly. \src{3,4,13}. __NETWORK_SOURCE_NOTE__

\subsection{M0: transparent household-condition baseline}
Let $c$ index cities. The baseline score combines rent burden, poverty and broadband with frozen anchors and weights:
\[
 u_{rent,c}=\mathrm{clip}\!\left(\frac{__RENT_HIGH__-r_c}{__RENT_HIGH__-__RENT_LOW__},0,1\right),\quad u_{poverty,c}=\mathrm{clip}\!\left(1-\frac{p_c}{__POVERTY_HIGH__},0,1\right),\quad u_{broadband,c}=\mathrm{clip}\!\left(\frac{b_c-__BROADBAND_LOW__}{1-__BROADBAND_LOW__},0,1\right),
\] 
\[ M_0(c)=100\left[__W_RENT__u_{rent,c}+__W_POVERTY__u_{poverty,c}+__W_BROADBAND__u_{broadband,c}\right]. \]
For each indicator, the transformation direction and clipping anchors are fixed in the configuration file before the ranking is interpreted. The composite-index design follows established guidance on normalization, weighting and transparent interpretation \src{6}.

\subsection{M1: substantive revision to real pedestrian-network opportunity}
Let $g$ index tract origins, $j$ facilities and $k$ facility type. For route length $\ell_{gj}$, reference walking speed $v=__WALK_SPEED__\,\mathrm{m/s}$, cutoff $T=__WALK_MINUTES__\,\mathrm{min}$ and decay constant $\tau=__TAU__\,\mathrm{min}$, define
\[
 K_{gjk}=\mathbf{1}\!\left\{\frac{\ell_{gj}}{60v}\leq T\right\}
 \exp\!\left(-\frac{\ell_{gj}}{60v\tau}\right).
\]
For each facility type, $A_{gk}=\sum_jK_{gjk}$ and $U_{gk}=1-\exp(-A_{gk}/2)$. The tract opportunity score is
\[
 a_g=__W_LIBRARY__U_{g,library}+__W_PARK__U_{g,park}.
\]
With tract youth proxy $n_g$, the population-weighted mean is $\bar a_c=\sum_gn_ga_g/\sum_gn_g$ and $Q_{0.1,w}(a_g)$ is its population-weighted lower decile. The equity-adjusted opportunity term is
\[
 V_c=__W_MEAN__\bar a_c+__W_Q10__Q_{0.1,w}(a_g),\qquad
 \boxed{M_1(c)=__W_ACS__M_0(c)+__W_OPPORTUNITY__\,(100V_c).}
\]
This is a normative model, not a fitted probability of participation. Network-based accessibility is grounded in spatial-accessibility literature and urban-network methods \src{4,5}.

\subsection{Application and observed twelve-city solution}
The baseline is structurally incomplete because it cannot distinguish a nearby resource from one separated by an inaccessible street network, and it ignores where young residents live. M1 introduces actual walk-network distance, population weighting and a lower-decile term. Composite indicators remain preference-dependent; this is why the assumptions and sensitivity results are reported explicitly \src{6,12}.

Table~\ref{tab:rank} reports the twelve actual audited model values, generated directly from the frozen result CSV. Under the reference assumptions, \textbf{__WINNER__ leads with __WINNER_SCORE__/100}; __RUNNER_UP__ is second with __RUNNER_SCORE__/100.
\begin{table}[H]\centering\normalsize
\caption{Reference scores from original ACS observations and observed OSM walk-network routes.}\label{tab:rank}
\begin{tabular}{r l r r r r r}\toprule
M1 rank & City & M0 & M1 & M0 rank & M1 rank & ACS youth count \\\midrule
__TABLE_ROWS__
\bottomrule\end{tabular}\end{table}
\begin{figure}[H]\centering\includegraphics[width=.96\linewidth]{F19_GIS_01_REAL_CITY_RANKING.pdf}
\caption{The twelve-city network-integrated reference scores, generated from the audited ranking file.}\end{figure}
\begin{figure}[H]\centering\includegraphics[width=.96\linewidth]{F19_GIS_02_RANK_BUMP.pdf}
\caption{M0-to-M1 rank movement for all twelve cities.}\end{figure}

\subsection{Spatial case study: Austin}
Austin is retained as the preselected engineering case, independent of its final rank. Its map uses the official TIGER PLACE boundary, tract population origins, observed OSM walk-permitted street edges and mapped candidate facilities. The city with the lowest population-weighted lower-decile opportunity in this sample is __WORST_Q10__ ($Q_{0.1}=__WORST_Q10_VALUE__$). The figure is an access model, not proof of actual gate access or personal safety.
\begin{figure}[H]\centering\includegraphics[width=.94\linewidth]{F19_GIS_03_AUSTIN_REAL_WALK_MAP.pdf}
\caption{Austin: observed pedestrian graph, tract origins and potential library access.}\end{figure}

\section{Analysis of Your Work}
\subsection{Why the model revision matters}
M0 measures citywide household conditions. M1 adds a different mechanism: the opportunity must be reachable through a real pedestrian network from where the age-proxy population lives. The revision is therefore structural, not merely a new weight vector. The largest absolute ranking movement is __CHANGED__, from M0 rank __CHANGED_FROM__ to M1 rank __CHANGED_TO__. Whether the revision is more predictive cannot be established without held-out adolescent outcomes; its demonstrated value is a more explicit and spatially grounded description of potential opportunity.

\subsection{Verification and empirical systems checks}
The independent source audit checks the 28 Census originals, TIGER geometry, all twelve OSM source/network receipts, route outputs, population denominators and complete rank permutation. The independent numerical replay recomputes the ranking through a separate calculation path. The systems evidence contains __SYSTEM_COUNT__ observed hypothesis rows. It measures stock-versus-access rank changes, tract-level hierarchy/equity, cross-boundary opportunity flows and additive-versus-bottleneck complementarity. Stability over time and endogenous self-organization are marked not identifiable without comparable multi-year networks or observed youth association data. These limits are consistent with reproducibility principles in the scientific literature \src{9,10}.
\begin{table}[H]\centering\normalsize
\caption{Empirical systems-theory tests generated from the actual GIS outputs.}
\begin{tabularx}{\textwidth}{p{.24\textwidth}p{.25\textwidth}X p{.15\textwidth}}\toprule
Hypothesis & Observed metric & Result & Status \\\midrule
__SYSTEM_ROWS__
\bottomrule\end{tabularx}\end{table}

\input{V19_ALGORITHM_MATRIX_AND_VALIDATION.tex}
\input{V19_EMPIRICAL_EVIDENCE_ADDITIONS.tex}
\input{V19_DECISION_EVIDENCE_ADDITIONS.tex}

\subsection{Sensitivity and robustness}
The model is recomputed over $3\times3\times3=27$ deterministic scenarios: walking cutoffs of 10, 20 and 30 minutes; citywide ACS weights of 0.50, 0.60 and 0.70; and lower-decile weights of 0, 0.25 and 0.50. In this finite declared set, __WINNER__ leads __SCENARIOS_WON__ of 27 scenarios. This is a scenario frequency, not a confidence level, a survey of public preferences or a posterior probability. Multicriteria acceptability analysis provides related decision-theory context, but this study does not claim to implement stochastic SMAA \src{12}.
\begin{table}[H]\centering\normalsize\caption{Number of wins across the 27 specified scenarios.}
\begin{tabular}{l r}\toprule City & Scenario wins \\\midrule
__SCENARIO_TABLE__
\bottomrule\end{tabular}\end{table}

\subsection{Strengths}
The principal strengths are original-source byte retention and hashing; explicit separation of ACS estimates from margins of error; stable GEOID-based geography; real pedestrian-network rather than Euclidean routing; population-weighted neighbourhood outcomes; a substantive and fully recomputed M0-to-M1 revision; independent numerical replay; and transparent scenario analysis. Data stewardship and reproducibility are treated as part of the research method, not an afterthought \src{9,10}.

\subsection{Limitations and validity ceiling}
The 15--17 age proxy omits ages 14 and 18. Tract-area interpolation is not residential dasymetric redistribution. ACS estimates are pooled over five years, while OSM is a snapshot at acquisition time. OSM feature completeness varies; mapped parks do not establish entrances, opening hours, accessibility or public use. School points do not establish admission eligibility. The fixed walking speed does not represent disability, weather, lighting or individual mobility. No held-out youth wellbeing outcome is available, so the model does not establish causality or actual realised benefits. Scientific figure choices follow evidence-first visualization principles; visual design cannot substitute for data validity \src{11}.

\subsection{Research transparency and AI-tool use}
AI assistance recorded in the project ledger: __AI_STATEMENT__. The AI tool citations appear in the Reference List \src{__AI_CITATIONS__}. Original Census and OSM bytes, numerical scores, GIS figures and rankings are produced by the documented programs; the independent replay and human scientific review remain separate checks. Any additional AI tool or material assistance used during the actual execution must be added to the project AI-use ledger and disclosed accurately. No AI system is represented as an independent human reviewer.

\section{Concluding Paragraph}
Under the frozen assumptions and the twelve-city sample, __WINNER__ ranks first with __WINNER_SCORE__/100, while the model's principal contribution is to show how real pedestrian networks and the spatial distribution of young residents can change a city comparison that would otherwise rely on municipal averages and amenity inventories. This conclusion is conditional on the chosen indicators, 15--17 age proxy, 20-minute walking reference, facility completeness and declared weights; it should guide further investigation rather than dictate family decisions. The next research step is field validation of park entrances, library hours and access conditions, followed by youth-centred data collection and multi-year comparisons that can test temporal stability and actual outcomes.

\section{Supplementary 1--2 Page Documents and Memos}
\subsection*{Nontechnical News Article}
\addcontentsline{toc}{subsection}{Nontechnical News Article}
\input{supplemental_documents/nontechnical_news_article.tex}
__EXTRA_SUPPLEMENTS__

\clearpage
\section{Reference List}
The following list includes the datasets, websites, scholarly methods, software and AI tools actually used in the manuscript. Newspaper or magazine sources are included only when they have genuinely informed the work; none is added merely to lengthen the bibliography.
\begin{enumerate}
__REFERENCES__
\end{enumerate}
\end{document}
'''

    replacements = {
        '__TITLE__': conf['title'], '__WINNER__': conf['winner'], '__WINNER_SCORE__': conf['winner_score'],
        '__RUNNER_UP__': conf['runner_up'], '__RUNNER_SCORE__': conf['runner_score'], '__TOP5__': conf['top5'],
        '__CHANGED__': conf['changed'], '__CHANGED_FROM__': conf['changedfrom'], '__CHANGED_TO__': conf['changedto'],
        '__WORST_Q10__': conf['worstq10'], '__WORST_Q10_VALUE__': conf['worstq10value'],
        '__SCENARIOS_WON__': conf['scenarios_won'], '__ASSUMPTION_ROWS__': conf['assumptions_rows'],
        '__WALK_SPEED__': conf['walk_speed'], '__WALK_MINUTES__': conf['walk_minutes'], '__TAU__': conf['tau'],
        '__W_LIBRARY__': conf['w_library'], '__W_PARK__': conf['w_park'], '__W_MEAN__': conf['w_mean'],
        '__W_Q10__': conf['w_q10'], '__W_ACS__': conf['w_acs'], '__W_OPPORTUNITY__': conf['w_opportunity'],
        '__W_RENT__': conf['w_rent'], '__W_POVERTY__': conf['w_poverty'], '__W_BROADBAND__': conf['w_broadband'],
        '__RENT_LOW__': conf['rent_low'], '__RENT_HIGH__': conf['rent_high'], '__POVERTY_HIGH__': conf['poverty_high'], '__BROADBAND_LOW__': conf['broadband_low'],
        '__TABLE_ROWS__': conf['tablerows'], '__SYSTEM_COUNT__': conf['system_count'],
        '__SYSTEM_ROWS__': conf['systemrows'], '__SCENARIO_TABLE__': conf['scenario_table_rows'],
        '__EXTRA_SUPPLEMENTS__': extra_supplement_tex, '__REFERENCES__': references_tex,
        '__AI_STATEMENT__': tex(ai_statement), '__AI_CITATIONS__': ai_citation_numbers,
        '__NETWORK_SOURCE_NOTE__': network_source_note,
    }
    for key, value in replacements.items():
        template = template.replace(key, value)

    # The source references are deliberately explicit and correspond to the
    # numbered citations embedded in the body. No unverified placeholders remain.
    if re.search(r'__[A-Z0-9_]+__', template):
        raise ValueError('UNRESOLVED_MANUSCRIPT_PLACEHOLDER')
    tex_qa = validate_tex_structure(template)
    if tex_qa['status'] != 'PASS':
        raise RuntimeError('OFFICIAL_OPTIONAL_LAYOUT_TEX_CONTRACT_FAILED:' + json.dumps(tex_qa, ensure_ascii=False))

    dest = paper / 'V19_EMPIRICAL_YOUTH_CITY_NETWORK_RESEARCH.tex'
    dest.write_text(template, encoding='utf-8')
    for name in need:
        shutil.copy2(figs / name, paper / name)
    diagram=ROOT/'drawio/exports/D19-01_systems_architecture.pdf'
    if not diagram.is_file():raise FileNotFoundError('EDITABLE_DRAWIO_ARCHITECTURE_MISSING')
    shutil.copy2(diagram,paper/diagram.name)
    cmd = ['latexmk', '-pdf', '-interaction=nonstopmode', '-halt-on-error', dest.name]
    run = subprocess.run(cmd, cwd=paper, text=True, capture_output=True)
    (paper / 'compile.log').write_text(run.stdout + '\n--- STDERR ---\n' + run.stderr, encoding='utf-8')
    if run.returncode:
        raise RuntimeError('LATEX_COMPILATION_FAILED: see compile.log\n' + run.stdout[-2200:] + run.stderr[-1200:])
    pdf = dest.with_suffix('.pdf')
    from official_summary import splice_pdf_first_page
    solution_only, official_receipt = splice_pdf_first_page(pdf, paper)
    layout = audit_pdf_layout(solution_only, supplemental_titles=supplemental_titles, max_pages=25)
    layout['tex_structure_audit'] = tex_qa
    write_audit(layout, paper / 'paper_layout_audit.json')
    if layout['status'] != 'PASS':
        raise RuntimeError('OFFICIAL_OPTIONAL_LAYOUT_PDF_AUDIT_FAILED:' + json.dumps(layout, ensure_ascii=False))

    # Explicit AI disclosure appendix after the 25-page *solution*; actual
    # prompt/use log has to be human-verified before the final combined file.
    from ai_report_appendix import generate as append_ai_report
    final_pdf, ai_receipt = append_ai_report(solution_only)
    report = {
        'status': 'EMPIRICAL_PDF_COMPILED_OFFICIAL_OPTIONAL_LAYOUT_PASS_HUMAN_SCIENCE_REVIEW_PENDING',
        'official_summary_receipt': official_receipt,
        'ai_appendix_receipt': ai_receipt,
        'pages': layout['total_pages'], 'bytes': pdf.stat().st_size, 'pdf_sha256': digest(pdf),
        'ranking_sha256': digest(csvpath), 'census_source_hash': conf['acs_hash'],
        'winning_city': first.city, 'score': float(first.M1_real_walk_20m), 'scenarios': 27,
        'paper_layout_audit': layout,
        'warnings': ['No school admission or actual teen outcomes are measured',
                     'No contest registration or official acceptance claimed',
                     'Not peer reviewed; human scientific review remains required'],
    }
    (paper / 'pdf_preflight.json').write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return pdf


if __name__ == '__main__':
    build()
