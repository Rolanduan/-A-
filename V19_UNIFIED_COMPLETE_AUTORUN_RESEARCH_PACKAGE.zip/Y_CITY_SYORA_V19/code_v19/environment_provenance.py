#!/usr/bin/env python3
"""Record ACTUAL execution dependency versions, not a pretend pre-locked environment."""
from __future__ import annotations
import datetime as dt,importlib.metadata as md,json,platform,subprocess,sys
from pathlib import Path
from acquire_osm_walk import ROOT,digest

def command(*args):
    try:r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=25);return {'returncode':r.returncode,'output':(r.stdout or r.stderr)[-1400:]}
    except Exception as exc:return {'error':repr(exc)}

def run():
    pkgs=['osmnx','pyrosm','geopandas','pandas','numpy','scipy','networkx','shapely','pyproj','pyogrio','pymupdf','matplotlib']
    versions={}
    for item in pkgs:
        try:versions[item]=md.version(item)
        except md.PackageNotFoundError:versions[item]='NOT_INSTALLED'
    record={'status':'OBSERVED_EXECUTION_ENVIRONMENT_NOT_A_PRIOR_VERIFIED_LOCK',
      'utc':dt.datetime.now(dt.timezone.utc).isoformat(),'platform':platform.platform(),
      'python':sys.version,'package_versions':versions,
      'latexmk':command('latexmk','-v'),'graphviz':command('dot','-V'),
      'git_commit':command('git','rev-parse','HEAD'),
      'pip_freeze':command(sys.executable,'-m','pip','freeze')}
    qa=ROOT/'qa_v19';qa.mkdir(parents=True,exist_ok=True)
    out=qa/'environment_observed.json';out.write_text(json.dumps(record,indent=2))
    print(record['status']);return record
if __name__=='__main__':run()
