#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-python3}"
"$PYTHON" -m pip install -r code_v19/requirements_v19.txt
"$PYTHON" code_v19/run_v19.py --stage all --network auto "$@"
