#!/usr/bin/env python3
"""Official optional paper-layout contract for Y-CITY × SYORA V19.2.

The supplied official outline is optional/flexible. This project elects to follow
its sequence explicitly and audits the compiled PDF, rather than merely checking
that section names occur somewhere in the TeX source.
"""
from __future__ import annotations
from pathlib import Path
import re
import json
import hashlib
import fitz

REQUIRED_MAJOR_SECTIONS = [
    "Summary Sheet",
    "Introduction and Restatement of the Problem",
    "Assumptions with Justifications",
    "Presentation of Model and Solution",
    "Analysis of Your Work",
    "Concluding Paragraph",
    "Supplementary 1--2 Page Documents and Memos",
    "Reference List",
]
REQUIRED_SUBSECTIONS = ["Nontechnical News Article"]


def _norm(value: str) -> str:
    value = value.replace("–", "-").replace("—", "-").replace("−", "-")
    value = re.sub(r"-+", "-", value)
    value = value.replace("’", "'").replace("‘", "'")
    return re.sub(r"\s+", " ", value).strip().casefold()


def tex_section_titles(source: str) -> list[str]:
    return [m.group(1).strip() for m in re.finditer(r"\\section\*?\{([^{}]+)\}", source)]


def validate_tex_structure(source: str) -> dict:
    issues: list[str] = []
    titles = tex_section_titles(source)
    normalized = [_norm(x) for x in titles]
    expected = [_norm(x) for x in REQUIRED_MAJOR_SECTIONS]
    positions = []
    cursor = 0
    for item in expected:
        try:
            pos = normalized.index(item, cursor)
            positions.append(pos)
            cursor = pos + 1
        except ValueError:
            issues.append("MISSING_OR_OUT_OF_ORDER_MAJOR_SECTION:" + item)
            positions.append(-1)
    if titles and _norm(titles[0]) != _norm("Summary Sheet"):
        issues.append("FIRST_MAJOR_SECTION_NOT_SUMMARY_SHEET")
    if not re.search(r"\\tableofcontents\b", source):
        issues.append("TABLE_OF_CONTENTS_COMMAND_MISSING")
    else:
        toc_pos = source.index(r"\tableofcontents")
        summary_pos = source.find(r"\section*{Summary Sheet}")
        intro_pos = source.find(r"\section{Introduction and Restatement of the Problem}")
        if not (summary_pos >= 0 and summary_pos < toc_pos < intro_pos):
            issues.append("TOC_NOT_BETWEEN_SUMMARY_AND_INTRODUCTION")
    if r"\renewcommand{\contentsname}{Table of Contents}" not in source:
        issues.append("TOC_TITLE_NOT_EXPLICITLY_TABLE_OF_CONTENTS")
    if r"\subsection*{Nontechnical News Article}" not in source:
        issues.append("NONTECHNICAL_NEWS_ARTICLE_SUBSECTION_MISSING")
    if not re.search(r"\\clearpage\s*\\section\{Reference List\}", source):
        issues.append("REFERENCE_LIST_NOT_SEPARATED_AS_FINAL_SECTION")
    if titles and _norm(titles[-1]) != _norm("Reference List"):
        issues.append("REFERENCE_LIST_NOT_FINAL_MAJOR_SECTION")
    if r"\pagenumbering{arabic}" not in source:
        issues.append("ARABIC_PAGE_NUMBERING_NOT_EXPLICIT")

    # The official outline calls for a concluding paragraph. Keep the final
    # conclusion compact and singular; future work belongs inside that paragraph.
    try:
        start = source.index(r"\section{Concluding Paragraph}")
        end = source.index(r"\section{Supplementary 1--2 Page Documents and Memos}", start)
        body = source[start:end].split("}", 1)[1]
        paragraphs = [p.strip() for p in re.split(r"\n\s*\n", body) if p.strip()]
        if len(paragraphs) != 1:
            issues.append("CONCLUDING_SECTION_MUST_CONTAIN_ONE_FINAL_PARAGRAPH")
    except ValueError:
        issues.append("CONCLUDING_PARAGRAPH_BOUNDARY_NOT_FOUND")

    return {
        "status": "PASS" if not issues else "FAIL",
        "issues": issues,
        "major_sections": titles,
        "required_order": REQUIRED_MAJOR_SECTIONS,
        "official_outline_interpretation": "Optional layout selected as the project manuscript's explicit section order; adjustments remain possible only when the official problem or venue requires them.",
    }


def _page_hits(pages: list[str], phrase: str) -> list[int]:
    target = _norm(phrase)
    return [i for i, page in enumerate(pages) if target in _norm(page)]


def _last_page(pages: list[str], phrase: str) -> int | None:
    hits = _page_hits(pages, phrase)
    return hits[-1] if hits else None


def audit_pdf_layout(pdf_path: str | Path, supplemental_titles: list[str] | None = None,
                     max_pages: int = 25) -> dict:
    pdf_path = Path(pdf_path)
    issues: list[str] = []
    if not pdf_path.is_file():
        return {"status": "FAIL", "issues": ["PDF_NOT_FOUND:" + str(pdf_path)]}
    with fitz.open(pdf_path) as doc:
        pages = [p.get_text("text") for p in doc]
        page_norm = [_norm(p) for p in pages]
        n_pages = len(pages)
        if n_pages > max_pages:
            issues.append(f"PDF_EXCEEDS_MAX_PAGES:{n_pages}>{max_pages}")
        if n_pages < 8:
            issues.append(f"PDF_TOO_SHORT_OR_TRUNCATED:{n_pages}")
        if not pages or "summary sheet" not in page_norm[0]:
            issues.append("PAGE_1_IS_NOT_SUMMARY_SHEET")
        if pages and "table of contents" in page_norm[0]:
            issues.append("TABLE_OF_CONTENTS_MUST_NOT_SHARE_PAGE_1")
        if n_pages < 2 or "table of contents" not in page_norm[1]:
            issues.append("TABLE_OF_CONTENTS_DOES_NOT_START_ON_PAGE_2")
        if pages:
            for label in ("problem", "approach", "actual results"):
                if label not in page_norm[0]:
                    issues.append("SUMMARY_SHEET_MISSING_CONTENT_LABEL:" + label)

        section_phrases = [
            "Introduction and Restatement of the Problem",
            "Assumptions with Justifications",
            "Presentation of Model and Solution",
            "Analysis of Your Work",
            "Concluding Paragraph",
            "Supplementary 1--2 Page Documents and Memos",
            "Reference List",
        ]
        section_pages = {name: _last_page(pages, name) for name in section_phrases}
        # Sections may legitimately begin on the same physical page. Check
        # their last body occurrence in the full text stream, not only page index;
        # the TOC's earlier duplicate entries are therefore ignored.
        full_text = _norm(" \n".join(pages))
        previous_position = -1
        for name in section_phrases:
            page = section_pages[name]
            position = full_text.rfind(_norm(name))
            if page is None or position < 0:
                issues.append("PDF_SECTION_MISSING:" + name)
            elif position <= previous_position:
                issues.append("PDF_SECTION_ORDER_INVALID:" + name)
            else:
                previous_position = position

        # Verify that the contents pages actually list every major section and
        # each registered short document. The body Introduction page marks the
        # end of the TOC region (the TOC itself may span more than one page).
        intro_page = section_pages.get("Introduction and Restatement of the Problem")
        toc_text = _norm(" \n".join(pages[1:intro_page])) if intro_page is not None else ""
        toc_required = ["Summary Sheet"] + section_phrases + ["Nontechnical News Article"] + (supplemental_titles or [])[1:]
        missing_toc = [name for name in toc_required if _norm(name) not in toc_text]
        for name in missing_toc:
            issues.append("TABLE_OF_CONTENTS_ENTRY_MISSING:" + name)

        # Each supplemental item is required to occupy one or two pages. The
        # generated news article is always the first item; registered memos follow.
        titles = supplemental_titles or ["Nontechnical News Article"]
        ref_page = section_pages.get("Reference List")
        item_pages: dict[str, int | None] = {}
        starts = []
        for title in titles:
            p = _last_page(pages, title)
            item_pages[title] = p
            starts.append(p)
        for i, title in enumerate(titles):
            start = item_pages[title]
            if start is None or ref_page is None:
                issues.append("SUPPLEMENTAL_ITEM_MISSING:" + title)
                continue
            later = [x for x in starts[i + 1:] if x is not None and x > start]
            end = min(later) if later else ref_page
            count = end - start
            if count < 1 or count > 2:
                issues.append(f"SUPPLEMENTAL_PAGE_COUNT_OUT_OF_RANGE:{title}:{count}")

        # References must be the final major content section; only page furniture
        # may follow the last reference-list page.
        if ref_page is not None:
            ref_hits = _page_hits(pages, "Reference List")
            if not ref_hits:
                issues.append("REFERENCE_LIST_HEADING_NOT_FOUND")

        report = {
            "status": "PASS" if not issues else "FAIL",
            "issues": issues,
            "pdf_path": str(pdf_path),
            "pdf_sha256": hashlib.sha256(pdf_path.read_bytes()).hexdigest(),
            "total_pages": n_pages,
            "summary_sheet_pages": 1 if n_pages and "summary sheet" in page_norm[0] and n_pages > 1 and "table of contents" in page_norm[1] else 0,
            "table_of_contents_starts_page": 2 if n_pages > 1 and "table of contents" in page_norm[1] else None,
            "table_of_contents_entries_checked": toc_required,
            "table_of_contents_entries_missing": missing_toc,
            "section_start_pages_1_based": {k: (v + 1 if v is not None else None) for k, v in section_pages.items()},
            "supplemental_document_pages": {
                title: ((min([x for x in starts[i + 1:] if x is not None and x > item_pages[title]], default=ref_page) - item_pages[title]) if item_pages[title] is not None and ref_page is not None else None)
                for i, title in enumerate(titles)
            },
            "reference_list_is_final_major_section": True,
            "max_pages": max_pages,
            "official_outline_interpretation": "One-page Summary Sheet is page 1; Table of Contents begins page 2; the remaining major sections follow the supplied optional layout; all supplementary one/two-page documents precede the final Reference List.",
        }
    return report


def write_audit(report: dict, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("pdf")
    parser.add_argument("--supplement", action="append", default=[])
    parser.add_argument("--max-pages", type=int, default=25)
    args = parser.parse_args()
    result = audit_pdf_layout(args.pdf, args.supplement or None, args.max_pages)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    raise SystemExit(0 if result["status"] == "PASS" else 3)
