#!/usr/bin/env python3
"""Check 12 OSM city acquisitions have visible, bounded, comparable snapshot dates.

No assertion that a latest-2026 snapshot is actually a 2024 street network.
"""
import datetime as dt,json
from pathlib import Path
from acquire_osm_walk import ROOT,CITY,digest

def parse_time(value):
    return dt.datetime.fromisoformat(str(value).replace('Z','+00:00')).astimezone(dt.timezone.utc)

def check(records,max_span_hours=168):
    if len(records)!=12:raise ValueError('NEED_ALL_12_CITY_RECEIPTS')
    times=[];bad=[];source_kinds=set()
    for x in records:
        if x.get('status')!='REAL_OSM_NETWORK_ACQUIRED_AND_GRAPH_ROUTED':bad.append('UNFINISHED_'+x.get('city','?'))
        if not x.get('completed_utc'):bad.append('MISSING_TIME_'+x.get('city','?'));continue
        times.append(parse_time(x['completed_utc']))
        source_kinds.add(x.get('source_kind','RAW_OVERPASS_CACHED_JSON'))
    if len(times)!=12 or bad:raise ValueError('CANNOT_FREEZE_OSM_SNAPSHOTS:'+str(bad))
    hours=(max(times)-min(times)).total_seconds()/3600
    if hours>max_span_hours:raise ValueError('OSM_CITY_EXTRACTION_SPAN_TOO_LONG:'+str(hours))
    return {'status':'PASS_OSM_12_CITY_TIME_WINDOW_CHECK','snapshot_first_utc':min(times).isoformat(),
            'snapshot_last_utc':max(times).isoformat(),'span_hours':hours,
            'source_kinds':sorted(source_kinds),'not_same_historical_vintage_as_acs':True,
            'warning':'Geofabrik latest extracts can each contain asynchronous upstream edits; a short download span does not prove a single immutable OSM snapshot.'}

def run():
    entries=[]
    for gid in CITY:
        p=ROOT/f'data/processed/v19_network/receipt_{gid}.json'
        if not p.is_file():raise FileNotFoundError('OSM_RECEIPT_MISSING_'+gid)
        entries.append(json.loads(p.read_text()))
    result=check(entries)
    out=ROOT/'qa_v19/osm_temporal_comparability.json';out.parent.mkdir(exist_ok=True,parents=True)
    out.write_text(json.dumps(result,indent=2));print(result);return result
if __name__=='__main__':run()
