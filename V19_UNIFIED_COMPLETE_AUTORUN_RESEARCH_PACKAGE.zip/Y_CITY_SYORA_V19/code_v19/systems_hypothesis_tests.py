#!/usr/bin/env python3
"""Make general systems theory falsifiable with actual Census+OSM evidence.
No time series -> stability & self-organization are NOT_IDENTIFIABLE, never falsely 'confirmed'.
"""
from __future__ import annotations
import csv,gzip,json,math
from pathlib import Path
import geopandas as gpd
import pandas as pd
from shapely.geometry import Point
from scipy.stats import kendalltau,spearmanr
from audit_full_gis import check
from score_official_gis import ROOT,OUT,CITY
from acquire_osm_walk import weighted_quantile,digest

RESULTS=ROOT/'results_v19'

def test_system():
    if check()['status']!='PASS':raise RuntimeError('SYSTEMS_TESTS_REQUIRE_REAL_GIS_AUDIT')
    RESULTS.mkdir(parents=True,exist_ok=True)
    d=pd.read_csv(OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv',dtype={'city_geoid':str})
    H=[];geographic=[];complement=[]
    tau=kendalltau(d.M0_rank,d.M1_rank).statistic
    rho=spearmanr(d.M0_rank,d.M1_rank).statistic
    change=int((d.M0_rank!=d.M1_rank).sum())
    H.append(dict(hypothesis='H1_STOCK_VS_FEASIBLE_ACCESS',observed_metric='kendall_tau;changed_city_count',
                  value=f'{tau:.6f};{change}',falsifiable_interpretation='M0 vs M1 ranking revision measured, not guaranteed improvement',status='TESTED'))
    for r in d.itertuples():
        geoid=r.city_geoid
        city_file=ROOT/f'data/raw_official/v19/tl_2024_{geoid[:2]}_place.zip'
        pp=gpd.read_file('zip://'+str(city_file))
        shape=pp.loc[pp.PLACEFP.astype(str)==geoid[2:]].to_crs('EPSG:5070')
        if len(shape)!=1:raise ValueError('CITY_POLYGON_NOT_UNIQUE '+geoid)
        boundary=shape.geometry.iloc[0]
        poi=pd.read_csv(ROOT/f'data/processed/v19_network/poi_osm_{geoid}.csv',dtype={'osm_id':str})
        pts=gpd.GeoDataFrame(poi,geometry=gpd.points_from_xy(poi.lon,poi.lat),crs='EPSG:4326').to_crs('EPSG:5070')
        pts['outside_city']=~pts.geometry.covered_by(boundary)
        raw=ROOT/f'data/processed/v19_network/walk_pairs_{geoid}.csv.gz'
        if not raw.is_file():raise FileNotFoundError('OD_PAIRS_MISSING '+geoid)
        lookup={str(x.osm_id):bool(x.outside_city) for x in pts.itertuples()}
        total=0.;external=0.;count=0
        with gzip.open(raw,'rt',newline='') as f:
            for pair in csv.DictReader(f):
                minutes=(float(pair['route_dist_m'])+float(pair['approach_dist_m'])+
                         float(pair['facility_snap_m']))/float(pair['speed_mps'])/60
                if minutes>20:continue
                val=math.exp(-minutes/12)
                total+=val;external+=val if lookup.get(pair['facility_osm_id'],False) else 0
                count+=1
        spill=external/total if total>0 else 0
        geographic.append(dict(city_geoid=geoid,city=r.city,facility_features=len(pts),
                       outside_city_feature_share=float(pts.outside_city.mean()),
                       decay_weighted_cross_border_route_pair_share=spill,route_facility_pairs=count))
        a=pd.read_csv(ROOT/f'data/processed/v19_network/city_origins_access_{geoid}.csv')
        weight=a.youth_15_17.astype(float).to_numpy()
        lib=1-np_exp_neg(a.library_access_20m.astype(float).to_numpy()/2)
        park=1-np_exp_neg(a.park_access_20m.astype(float).to_numpy()/2)
        additive=.55*lib+.45*park
        bottleneck=(lib*park)**.5
        complement.append(dict(city_geoid=geoid,city=r.city,
             complementary_geom_mean=float((bottleneck*weight).sum()/weight.sum()),
             additive_reference_mean=float((additive*weight).sum()/weight.sum()),
             network_opportunity_Q10=float(weighted_quantile(additive,weight,.1)),
             citywide_mean=float((additive*weight).sum()/weight.sum())))
    G=pd.DataFrame(geographic);G.to_csv(RESULTS/'H3_CROSS_BOUNDARY_SERVICE_FLOW.csv',index=False)
    C=pd.DataFrame(complement);C.to_csv(RESULTS/'H4_COMPLEMENTARITY_BOTTLENECK.csv',index=False)
    H.append(dict(hypothesis='H2_HIERARCHICAL_FAIRNESS',observed_metric='Q10_vs_mean_gap',
         value=f'{(C.citywide_mean-C.network_opportunity_Q10).mean():.6f}',
         falsifiable_interpretation='Nonnegative population-weighted mean minus lower decile in sample (except degenerate weighting)',status='TESTED'))
    H.append(dict(hypothesis='H3_OPEN_SYSTEM_CROSS_BOUNDARY',observed_metric='cross_boundary_share_median',
         value=f'{G.decay_weighted_cross_border_route_pair_share.median():.6f}',
         falsifiable_interpretation='Share of modeled reachable facility contributions outside city polygon; facilities not entrance-verified',status='TESTED'))
    H.append(dict(hypothesis='H4_HOLISM_BOTTLENECK',observed_metric='additive_minus_geometric_mean',
         value=f'{(C.additive_reference_mean-C.complementary_geom_mean).mean():.6f}',
         falsifiable_interpretation='Geometric mean flags simultaneous access constraints; not a causal mechanism',status='TESTED'))
    H.append(dict(hypothesis='H5_STABILITY_TIME_SERIES',observed_metric='n_years_with_comparable_network',
         value='0',falsifiable_interpretation='Requires multi-year consistent OSM plus ACS panels',status='NOT_IDENTIFIABLE'))
    H.append(dict(hypothesis='H6_ENDOGENOUS_SELF_ORGANIZATION',observed_metric='repeated_youth_association_networks',
         value='0',falsifiable_interpretation='No observed youth participation/repeated ties; cannot infer endogenous emergence',status='NOT_IDENTIFIABLE'))
    H.append(dict(hypothesis='H7_TRANSPORT_ACCESS_THRESHOLD',observed_metric='tested_10_20_30_minutes',
         value='10,20,30',falsifiable_interpretation='Observed graph access declines at stricter travel limits',status='TESTED'))
    H.append(dict(hypothesis='H8_PURPOSEFULNESS_AGE_CONSTRUCT',observed_metric='Census_age_proxy',
         value='ages_15_17_not_14_18',falsifiable_interpretation='Proxy choice explicitly visible, not falsely exact target population',status='PARTIALLY_OPERATIONALIZED'))
    hpath=RESULTS/'SYSTEMS_THEORY_EMPIRICAL_TESTS.csv'
    pd.DataFrame(H).to_csv(hpath,index=False)
    receipt={'status':'SYSTEMS_MECHANISMS_TESTED_WITH_REAL_GIS_DATA','observed_hypotheses':sum(r['status']=='TESTED' for r in H),
             'not_identifiable':sum(r['status']=='NOT_IDENTIFIABLE' for r in H),
             'source_ranking_sha256':digest(OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv'),
             'systems_csv_sha256':digest(hpath),'mean_kendall_tau':float(tau),'spearman_rho':float(rho)}
    (RESULTS/'systems_tests_receipt.json').write_text(json.dumps(receipt,indent=2))
    print(receipt);return receipt

def np_exp_neg(x):
    import numpy as np
    return np.exp(-x)

if __name__=='__main__':test_system()
