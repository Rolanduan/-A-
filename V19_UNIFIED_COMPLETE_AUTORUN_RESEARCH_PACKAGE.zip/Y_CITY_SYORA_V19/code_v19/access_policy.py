"""V19 conservative OSM *candidate* access classification.

OSM contributors' tags are evidence, NOT a municipal entitlement certificate.
Tag absent/unusual => UNKNOWN; we never turn UNKNOWN into confirmed public.
A park polygon boundary point is never a validated entrance.
"""
from __future__ import annotations
import math

RESTRICTED={'no','private','customers','permit','delivery','military','agricultural','forestry'}
OSM_OPEN={'yes','public','permissive','designated'}


def normalize_tag(v):
    if v is None:return 'unknown'
    text=str(v).strip().lower()
    if not text or text in {'nan','none','null','unspecified','unknown'}:return 'unknown'
    return text


def classify_access(access, *, entrance_confirmed=False, opening_hours=None, fee=None):
    tag=normalize_tag(access)
    if tag in RESTRICTED:status='RESTRICTED'
    elif tag in OSM_OPEN:status='OSM_TAGGED_PUBLIC'
    else:status='UNKNOWN'
    hours=normalize_tag(opening_hours)
    pricing=normalize_tag(fee)
    return {
        'access_status':status,
        'access_tag':tag,
        'opening_hours_tag':hours,
        'fee_tag':pricing,
        'entrance_confirmed':bool(entrance_confirmed),
        'observed_eligibility':'NOT_VERIFIED',
        'caveat':'OSM tags are observed metadata, not proof of age eligibility, open hours, entry rights or physical entrance.'
    }


def bounds(status):
    if status=='RESTRICTED':return 0,0
    if status=='OSM_TAGGED_PUBLIC':return 1,1
    if status=='UNKNOWN':return 0,1
    raise ValueError('invalid access status; unsupported tags cannot pass silently')


def opportunity_at_distance(distance_m, speed_mps=1.25, cutoff_minutes=20, tau_minutes=12):
    vals=(distance_m,speed_mps,cutoff_minutes,tau_minutes)
    if not all(math.isfinite(float(x)) for x in vals) or distance_m<0 or speed_mps<=0 or cutoff_minutes<=0 or tau_minutes<=0:
        raise ValueError('invalid physical input')
    minutes=distance_m/(60*speed_mps)
    return math.exp(-minutes/tau_minutes) if minutes <=cutoff_minutes else 0.


def aggregate_pair_bounds(pairs, speed_mps=1.25, minutes=20, tau_minutes=12):
    result={'library':{'tagged':0.,'upper':0.},'park':{'tagged':0.,'upper':0.}}
    for r in pairs:
        if r['kind'] not in result:continue
        status=r.get('access_status','UNKNOWN')
        lo,hi=bounds(status)
        d=float(r['route_dist_m'])+float(r['approach_dist_m'])+float(r['facility_snap_m'])
        v=opportunity_at_distance(d,speed_mps,minutes,tau_minutes)
        result[r['kind']]['tagged']+=lo*v
        result[r['kind']]['upper']+=hi*v
    return result
