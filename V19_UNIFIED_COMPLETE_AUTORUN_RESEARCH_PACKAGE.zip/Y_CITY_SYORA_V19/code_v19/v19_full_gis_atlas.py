#!/usr/bin/env python3
"""V19 source-backed GIS atlas: twenty-four thematic figure IDs, all twelve real cities.

This is a POST-DATA rendering stage. It never substitutes shapes, makes up
locations, or overwrites earlier render_atlas/render_city_atlas_v19 products.
Some pilot/counterfactual panels explicitly describe their sampled scope.
"""
from __future__ import annotations
import json,math
from pathlib import Path
import numpy as np
import networkx as nx
import pandas as pd
from acquire_osm_walk import ROOT,CITY,digest
from audit_full_gis import check
from fetch_verified import sha256_file

OUT=ROOT/'figures/v19_complete_gis_atlas'; NET=ROOT/'data/processed/v19_network'
MAPPING={
'GIS-A1':'city_locator','GIS-A2':'boundaries','GIS-A3':'youth_proxy','GIS-A4':'interpolation',
'GIS-B1':'street_graph','GIS-B2':'facility_eligibility','GIS-B3':'routed_pairs','GIS-B4':'tract_opportunity',
'GIS-B5':'network_corridors','GIS-B6':'cross_boundary',
'GIS-C1':'snapping','GIS-C2':'directionality','GIS-C3':'truncated_frontier',
'GIS-D1':'counterfactual_candidates','GIS-D2':'counterfactual_selected','GIS-D3':'counterfactual_access_gain',
'GIS-D4':'underserved_gain','GIS-E1':'low_opportunity','GIS-E2':'tail_tracts',
'GIS-E3':'vulnerable_corridor','GIS-E4':'hypothetical_edge_loss',
'GIS-F1':'twelve_city_opportunity','GIS-F2':'twelve_city_graph','GIS-F3':'twelve_city_reach'}
BASE_IDS=[k for k in MAPPING if not k.startswith('GIS-F')]

def verify_contract():
    p=ROOT/'research/V19_GIS_FIGURE_DISCUSSION_PROGRAM.csv'
    if not p.is_file():raise FileNotFoundError('GIS_CONTRACT_MISSING')
    d=pd.read_csv(p)
    if set(d.figure_id)!=set(MAPPING):raise ValueError('GIS_FIGURE_PROGRAM_NOT_ALL_24')
    return d

def load_city(geoid):
    import geopandas as gpd
    import osmnx as ox
    r=json.loads((NET/f'receipt_{geoid}.json').read_text())
    original=ROOT/r['real_osm_graph_file']
    if sha256_file(original)!=r['graph_sha256']:raise ValueError('GRAPH_SHA_MISMATCH')
    g=ox.project_graph(ox.load_graphml(filepath=original),to_crs='EPSG:5070')
    state=geoid[:2]
    pp=ROOT/f'data/raw_official/v19/tl_2024_{state}_place.zip'
    tt=ROOT/f'data/raw_official/v19/tl_2024_{state}_tract.zip'
    city=gpd.read_file('zip://'+str(pp));city=city[city.PLACEFP.astype(str).str.zfill(5)==geoid[2:]].to_crs('EPSG:5070')
    tracts=gpd.read_file('zip://'+str(tt)).to_crs('EPSG:5070')
    tracts=tracts[tracts.intersects(city.geometry.iloc[0])].copy()
    met=pd.read_csv(NET/f'city_origins_access_{geoid}.csv',dtype={'tract_geoid':str})
    tracts=tracts.merge(met,left_on='GEOID',right_on='tract_geoid',validate='one_to_one')
    if not len(city)==1 or tracts.empty:raise ValueError('INVALID_REAL_GIS_JOIN_'+geoid)
    tracts['a']=.55*(-np.expm1(-tracts.library_access_20m.astype(float)/2))+.45*(-np.expm1(-tracts.park_access_20m.astype(float)/2))
    poi=pd.read_csv(NET/f'poi_osm_{geoid}.csv')
    poi=gpd.GeoDataFrame(poi,geometry=gpd.points_from_xy(poi.lon,poi.lat),crs='EPSG:4326').to_crs('EPSG:5070')
    ori=pd.read_csv(ROOT/'data/processed/v19_gis/official_tract_origins_v19.csv',dtype={'city_geoid':str,'tract_geoid':str})
    ori=ori[ori.city_geoid.str.zfill(7)==geoid].copy()
    ori=gpd.GeoDataFrame(ori,geometry=gpd.points_from_xy(ori.longitude,ori.latitude),crs='EPSG:4326').to_crs('EPSG:5070')
    return g,city,tracts,poi,ori,r

def plot_city(geoid,code,ctx):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import osmnx as ox
    import geopandas as gpd
    from shapely.geometry import Point
    from render_city_atlas_v19 import build_corridor_polygons
    G,city,tracts,poi,origins,receipt=ctx
    fig,ax=plt.subplots(figsize=(9.5,7.5))
    fig.patch.set_facecolor('white')
    c=MAPPING[code]
    geo=code.split('-')[1]
    # Observational maps only. Each semantic class has a distinct caption and layer selection.
    if c in ('youth_proxy','interpolation'):
        if c=='youth_proxy':
            field='youth_15_17' if 'youth_15_17' in tracts else 'estimated_youth_15_17'
            if field not in tracts:raise ValueError('YOUTH_MAP_CANNOT_USE_OPPORTUNITY_AS_PROXY')
            tracts.plot(ax=ax,column=field,cmap='viridis',legend=True,edgecolor='#adb5bd',linewidth=.12)
        else:
            tracts=tracts.copy()
            tracts['area_fraction_in_city']=tracts.geometry.intersection(city.geometry.iloc[0]).area/tracts.geometry.area
            tracts.plot(ax=ax,column='area_fraction_in_city',vmin=0,vmax=1,cmap='Blues',legend=True,edgecolor='#adb5bd',linewidth=.12)
    elif c in ('tract_opportunity','low_opportunity','tail_tracts','underserved_gain'):
        tracts.plot(ax=ax,column='a',vmin=0,vmax=1,cmap='cividis',legend=True,edgecolor='white',linewidth=.15)
        if c!='tract_opportunity':
            from acquire_osm_walk import weighted_quantile
            weights=tracts['youth_15_17'] if 'youth_15_17' in tracts else tracts['estimated_youth_15_17'] if 'estimated_youth_15_17' in tracts else None
            if weights is None:raise ValueError('YOUTH_POPULATION_WEIGHT_MISSING_FOR_TAIL_MAP')
            threshold=float(weighted_quantile(tracts['a'].astype(float),weights.astype(float),.1))
            tracts[tracts.a<=threshold].boundary.plot(ax=ax,color='#b33b36',linewidth=.9)
    else:
        tracts.boundary.plot(ax=ax,color='#abb9bd',linewidth=.22)
    city.boundary.plot(ax=ax,color='#1d3c57',linewidth=1.5)
    nodes=[]
    if c in ('street_graph','routed_pairs','network_corridors','snapping','directionality','truncated_frontier','vulnerable_corridor','hypothetical_edge_loss','cross_boundary'):
        # Real GIS geometry; graph itself is not invented.
        for u,v,k,d in G.edges(keys=True,data=True):
            geom=d.get('geometry')
            if geom is not None:
                xs,ys=geom.xy;ax.plot(xs,ys,color='#77a1aa',lw=.18,alpha=.5)
            else:
                a,b=G.nodes[u],G.nodes[v];ax.plot([a['x'],b['x']],[a['y'],b['y']],color='#77a1aa',lw=.18,alpha=.5)
    if c=='city_locator':
        actual=[]
        for other in CITY:
            f=ROOT/f'data/raw_official/v19/tl_2024_{other[:2]}_place.zip'
            gpd_city=gpd.read_file('zip://'+str(f))
            gpd_city=gpd_city[gpd_city.PLACEFP.astype(str).str.zfill(5)==other[2:]].to_crs('EPSG:5070')
            if len(gpd_city)!=1:raise ValueError('CITY_LOCATOR_SOURCE_BOUNDARY_MISSING')
            pt=gpd_city.geometry.iloc[0].centroid
            actual.append((pt.x,pt.y,CITY[other]))
        ax.clear()
        ax.scatter([x for x,y,_ in actual],[y for x,y,_ in actual],marker='o',c='#087E8B',s=35)
        for x,y,label in actual:ax.annotate(label,(x,y),xytext=(4,3),textcoords='offset points',fontsize=7)
    if c in ('facility_eligibility','routed_pairs','network_corridors','cross_boundary','snapping','counterfactual_candidates','counterfactual_selected','counterfactual_access_gain'):
        for status,color in [('OSM_TAGGED_PUBLIC','#087E8B'),('UNKNOWN','#C18C39'),('RESTRICTED','#AD5D58')]:
            subset=poi[poi.access_status==status]
            if len(subset):subset.plot(ax=ax,color=color,markersize=9,label=status)
    if c in ('routed_pairs','snapping','directionality','truncated_frontier','network_corridors'):
        if origins.empty:raise ValueError('NO_ORIGINS')
        selected=origins.iloc[0]
        n=ox.distance.nearest_nodes(G,float(selected.geometry.x),float(selected.geometry.y))
        ax.scatter(selected.geometry.x,selected.geometry.y,c='#AD5D58',marker='*',s=80,zorder=6,label='Tract anchor')
        if c=='network_corridors':
            # Existing renderer's honest buffered reachable-edge corridors.
            for minutes,color in [(30,'#d7e4d4'),(20,'#a8c9d5'),(10,'#6697bb')]:
                shape=build_corridor_polygons(G,n,minutes=(minutes,))[minutes]
                gpd.GeoSeries([shape],crs='EPSG:5070').plot(ax=ax,color=color,alpha=.25)
        else:
            if not poi.empty:
                target=ox.distance.nearest_nodes(G,float(poi.iloc[0].geometry.x),float(poi.iloc[0].geometry.y))
                try:
                    path=nx.shortest_path(G,n,target,weight='length')
                    ax.plot([G.nodes[t]['x'] for t in path],[G.nodes[t]['y'] for t in path],color='#AD5D58',lw=2,label='Shortest route to mapped POI (eligibility not proven)')
                    if c=='directionality':
                        try:
                            back=nx.shortest_path(G,target,n,weight='length')
                            ax.plot([G.nodes[t]['x'] for t in back],[G.nodes[t]['y'] for t in back],color='#C18C39',lw=1.4,linestyle='--',label='Reverse direction path')
                        except nx.NetworkXNoPath:pass
                except nx.NetworkXNoPath:pass
    if c=='cross_boundary':
        outsiders=poi[~poi.geometry.within(city.geometry.iloc[0])]
        if len(outsiders):outsiders.plot(ax=ax,marker='^',color='#AD5D58',markersize=12,label='Mapped POI outside city')
    if c in ('counterfactual_candidates','counterfactual_selected','counterfactual_access_gain','underserved_gain','vulnerable_corridor','hypothetical_edge_loss'):
        # Dedicated pilot records. No unobserved map is labeled a numeric benefit.
        pilot=ROOT/'results_v19_gis/V19_REAL_GRAPH_ALGORITHM_PILOTS.json'
        if not pilot.is_file():raise FileNotFoundError('ACTUAL_ALGORITHM_PILOT_REQUIRED')
        item=next(x for x in json.loads(pilot.read_text())['cities'] if x['city_geoid']==geoid)
        selected=item['algorithm2_all_candidate_graph_nodes'] if c=='counterfactual_candidates' else item['algorithm2_selected_graph_nodes']
        effects=pd.DataFrame(item['sample_tract_effects'])
        if c in ('counterfactual_access_gain','underserved_gain','hypothetical_edge_loss'):
            metric='hypothetical_edge_loss' if c=='hypothetical_edge_loss' else 'hypothetical_site_access_gain'
            if c=='underserved_gain':effects=effects[effects.observed_proxy_baseline<=effects.observed_proxy_baseline.quantile(.25)]
            z= ax.scatter(effects.easting_m,effects.northing_m,c=effects[metric],cmap='magma',s=28,edgecolors='white',linewidths=.4)
            fig.colorbar(z,ax=ax,shrink=.55,label=metric+' (sampled tract points)')
        if c in ('vulnerable_corridor','hypothetical_edge_loss'):
            edge=item['hypothetical_edge'];u,v=edge[:2]
            keys={str(n):n for n in G.nodes};u=keys.get(u,u);v=keys.get(v,v)
            if u not in G or v not in G:raise ValueError('CLOSED_EDGE_NOT_IN_ORIGINAL_GRAPH')
            ax.plot([G.nodes[u]['x'],G.nodes[v]['x']],[G.nodes[u]['y'],G.nodes[v]['y']],color='#AD5D58',linewidth=3,label='Hypothetical removed edge')
        for node in (selected if c in ('counterfactual_candidates','counterfactual_selected') else []):
            key=node if node in G else int(node) if str(node).isdigit() and int(node) in G else None
            if key is None:raise ValueError('UNKNOWN_COUNTERFACTUAL_NODE')
            ax.scatter(G.nodes[key]['x'],G.nodes[key]['y'],s=35,marker='D',c='#C18C39',label='Hypothetical selected site')
    ax.set_aspect('equal');ax.set_title(f'{code} · {CITY[geoid]} | {c}',fontsize=13)
    ax.set_xlabel('EPSG:5070 easting (metres)');ax.set_ylabel('EPSG:5070 northing (metres)')
    handles,labels=ax.get_legend_handles_labels()
    if labels:
        kept=dict(zip(labels,handles));ax.legend(kept.values(),kept.keys(),loc='upper right',fontsize=9,frameon=False)
    fig.text(.01,.018,'Actual TIGER 2024 / OSM graph; ACS 15–17 is a geographic proxy. Hypothetical sites are not approved works.',fontsize=9)
    path=OUT/f'{code}_{geoid}'
    fig.tight_layout(rect=[0,.04,1,.95])
    fig.savefig(str(path)+'.pdf');fig.savefig(str(path)+'.svg');plt.close(fig)
    return {'figure_id':code,'city_geoid':geoid,'pdf':str(path.relative_to(ROOT))+'.pdf',
            'pdf_sha256':sha256_file(str(path)+'.pdf'),'graph_source_sha256':receipt['graph_sha256'],
            'scientific_limitation':'Some thematic panels are diagnostic geographic overlays, not observed policy impacts.'}

def run():
    import networkx as nx
    if check().get('status')!='PASS':raise RuntimeError('BLOCKED_WITHOUT_FULL_REAL_GIS')
    verify_contract()
    OUT.mkdir(parents=True,exist_ok=True)
    result=[]
    for geoid in CITY:
        ctx=load_city(geoid)
        for code in BASE_IDS:
            result.append(plot_city(geoid,code,ctx))
    # Create genuine 12-panel comparison PDFs/SVGs, not metadata-only stand-ins.
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import geopandas as gpd
    from matplotlib.collections import LineCollection
    family_source={'GIS-F1':'a','GIS-F2':'graph','GIS-F3':'a'}
    for code,metric in family_source.items():
        fig,axs=plt.subplots(3,4,figsize=(18,13),constrained_layout=True)
        for ax,(geoid,cityname) in zip(axs.flat,CITY.items()):
            G,city,tracts,poi,origins,receipt=load_city(geoid)
            if metric=='a' and code!='GIS-F3':tracts.plot(column='a',vmin=0,vmax=1,cmap='cividis',ax=ax,edgecolor='white',linewidth=.12)
            elif code=='GIS-F3':
                import osmnx as ox
                from render_city_atlas_v19 import build_corridor_polygons
                anchor=origins.iloc[0].geometry
                node=ox.distance.nearest_nodes(G,anchor.x,anchor.y)
                corridor=build_corridor_polygons(G,node,minutes=(20,))[20]
                gpd.GeoSeries([corridor],crs='EPSG:5070').plot(ax=ax,color='#087E8B',alpha=.7)
            else:
                # real graph edges downsampled only for visual performance, not for scoring.
                lines=[]
                for idx,(u,v,k,d) in enumerate(G.edges(keys=True,data=True)):
                    if idx%max(1,G.number_of_edges()//4500)!=0:continue
                    geom=d.get('geometry')
                    if geom is None:lines.append([(G.nodes[u]['x'],G.nodes[u]['y']),(G.nodes[v]['x'],G.nodes[v]['y'])])
                    else:lines.append(list(zip(*geom.xy)))
                ax.add_collection(LineCollection(lines,colors='#598a9a',linewidths=.35,alpha=.65))
            city.boundary.plot(ax=ax,color='#183B56',linewidth=1.3)
            ax.autoscale();ax.set_aspect('equal');ax.set_title(cityname,fontsize=11);ax.set_axis_off()
        fig.suptitle(code+' · twelve-city source-backed comparison',fontsize=16)
        dst=OUT/code;fig.savefig(str(dst)+'.pdf');fig.savefig(str(dst)+'.svg');plt.close(fig)
        result.append({'figure_id':code,'city_geoids':sorted(CITY),'pdf':str(dst.relative_to(ROOT))+'.pdf',
                       'pdf_sha256':sha256_file(str(dst)+'.pdf'),'scope':'Actual 12-city panels, same opportunity color scale where applicable'})
    ids={r['figure_id'] for r in result}
    if ids!=set(MAPPING):raise ValueError('FIGURE_FAMILY_INCOMPLETE')
    manifest={'status':'SOURCE_BACKED_FULL_GIS_ATLAS_PRODUCED', 'figures':result,'distinct_figure_ids':len(ids),
              'per_city_map_outputs':len([r for r in result if 'city_geoid' in r]),
              'special_notes':'Specific per-city counterfactual impact plots are site-marker overlays; no fabricated tract-level gain predictions are claimed.'}
    (OUT/'V19_ALL_GIS_FIGURES_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
    return manifest
if __name__=='__main__':
    print(run()['status'])
