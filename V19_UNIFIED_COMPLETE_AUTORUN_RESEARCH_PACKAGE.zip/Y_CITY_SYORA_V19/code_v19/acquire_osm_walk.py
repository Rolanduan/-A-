#!/usr/bin/env python3
"""Actual OSM pedestrian street network acquisition (NO mock network accepted).
Requires live Overpass access, osmnx>=2 and the 2024 Census TIGER+ACS pipeline.
Raw responses cached by OSMnx, original cache SHA256 logged; derived graphml hashed.
On any absent network, raises and never writes a city PASS. This is a live-data
production program, not evidence that downloads have already occurred.
"""
from __future__ import annotations
from pathlib import Path
from collections import defaultdict
from datetime import datetime,timezone
import argparse, csv, gzip, hashlib, json, math, sys, time
import geopandas as gpd
from shapely.geometry import Point
import networkx as nx
from access_policy import classify_access, bounds
ROOT=Path(__file__).resolve().parents[1]
CITY={ '4805000':'Austin', '2507000':'Boston', '1714000':'Chicago', '0820000':'Denver', '5548000':'Madison', '2743000':'Minneapolis', '4261000':'Pittsburgh', '4159000':'Portland', '3755000':'Raleigh', '0666000':'San Diego', '5363000':'Seattle', '1304000':'Atlanta'}

def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()

def weighted_quantile(values, weights, q):
 items=sorted(zip(map(float,values),map(float,weights)))
 den=sum(w for _,w in items)
 if not items or den<=0 or any(not math.isfinite(a) or not math.isfinite(b) or b<0 for a,b in items):raise ValueError('invalid weighted quantile')
 cum=0
 for v,w in items:
  cum+=w
  if cum>=q*den:return v
 return items[-1][0]

def load_origins(geoid):
 p=ROOT/'data/processed/v19_gis/official_tract_origins_v19.csv'
 if not p.exists():raise FileNotFoundError('Census tract origin file missing: run prepare_tiger_acs_origins.py')
 with p.open(newline='') as f:rows=[r for r in csv.DictReader(f) if r['city_geoid']==geoid]
 if not rows:raise ValueError('no official tract origins for '+geoid)
 for r in rows:
  if float(r['estimated_youth_15_17'])<0:raise ValueError('negative youth population')
 return rows

def sample_points(features,kind):
    """Keep tagged public, unknown and restricted rows; never collapse unknown to allowed."""
    output=[]
    for ix,f in features.iterrows():
        if kind=='library' and str(f.get('amenity',''))!='library':continue
        if kind=='park' and str(f.get('leisure',''))!='park':continue
        geo=f.geometry
        if geo is None or geo.is_empty:continue
        # A boundary location is only a network SNAP PROXY (not a validated entrance).
        if geo.geom_type in ('Polygon','MultiPolygon'):
            try:point=geo.boundary.representative_point()
            except Exception:continue
            quality='PARK_BOUNDARY_PROXY' if kind=='park' else 'BUILDING_BOUNDARY_PROXY'
        elif geo.geom_type=='Point':point=geo;quality='OSM_POINT_NOT_DOOR_VERIFIED'
        else:point=geo.representative_point();quality='NONPOINT_PROXY'
        a=classify_access(f.get('access'),opening_hours=f.get('opening_hours'),fee=f.get('fee'))
        output.append({'osm_id':str(ix),'kind':kind,'lat':float(point.y),'lon':float(point.x),
                       'access_tag':a['access_tag'],'access_status':a['access_status'],
                       'opening_hours_tag':a['opening_hours_tag'],'fee_tag':a['fee_tag'],
                       'entrance_confirmed':False,'observed_eligibility':'NOT_VERIFIED',
                       'snap_quality':quality})
    return output


def run_city(geoid, *, max_dist_m=2700, speed_mps=1.25, force=False):
 import osmnx as ox
 city=CITY[geoid];st=geoid[:2];place=geoid[2:]
 pp=ROOT/f'data/raw_official/v19/tl_2024_{st}_place.zip'
 if not pp.is_file():raise FileNotFoundError(f'official Census TIGER PLACE original unavailable: {pp}')
 sample=load_origins(geoid)
 citygeo=gpd.read_file('zip://'+str(pp))
 selected=citygeo[citygeo.PLACEFP.astype(str)==place]
 if len(selected)!=1:raise ValueError(f'official TIGER PLACEFP does not uniquely match {geoid}')
 geom=gpd.GeoSeries(selected.geometry,crs=citygeo.crs).to_crs('EPSG:5070').iloc[0]
 if geom.area<=0:raise ValueError('empty official polygon')
 # Beyond administrative city boundary so nearby external facilities are eligible.
 buffer=gpd.GeoSeries([geom.buffer(max_dist_m)],crs='EPSG:5070').to_crs('EPSG:4326').iloc[0]
 area=gpd.GeoSeries([geom],crs='EPSG:5070').to_crs('EPSG:4326').iloc[0]
 folder=ROOT/'data/raw_osm/v19';cache=folder/'cache'/geoid;graphs=folder/'graphml';derived=ROOT/'data/processed/v19_network'
 for d in [cache,graphs,derived]:d.mkdir(parents=True,exist_ok=True)
 ox.settings.use_cache=True;ox.settings.cache_folder=str(cache)
 ox.settings.log_console=True
 ox.settings.timeout=240
 t0=datetime.now(timezone.utc).isoformat()
 print(f'ACQUIRE {city}: real OSMnx walk network, Overpass raw JSON cache',flush=True)
 G=ox.graph_from_polygon(buffer,network_type='walk',simplify=True,retain_all=True,truncate_by_edge=True)
 if G.number_of_nodes()<100 or G.number_of_edges()<100:raise ValueError('implausibly small real street network')
 graphpath=graphs/f'{geoid}_{city}_walk.graphml';ox.io.save_graphml(G,filepath=graphpath)
 # Extract real observed OSM facilities, not fabricated point patterns.
 fs=ox.features.features_from_polygon(buffer,tags={'amenity':'library','leisure':'park'})
 points=sample_points(fs,'library')+sample_points(fs,'park')
 points=list({(r['osm_id'],r['kind']):r for r in points}.values())
 if not any(x['kind']=='library' for x in points) or not any(x['kind']=='park' for x in points):raise ValueError('missing actual OSM library or park feature')
 # Project for point-node snapping; auto-derived edge lengths from OSMnx are meters.
 H=ox.projection.project_graph(G,to_crs='EPSG:5070')
 origin_gdf=gpd.GeoDataFrame(sample,geometry=[Point(float(r['longitude']),float(r['latitude'])) for r in sample],crs='EPSG:4326').to_crs('EPSG:5070')
 pois_gdf=gpd.GeoDataFrame(points,geometry=[Point(r['lon'],r['lat']) for r in points],crs='EPSG:4326').to_crs('EPSG:5070')
 onodes=ox.distance.nearest_nodes(H,origin_gdf.geometry.x.to_numpy(),origin_gdf.geometry.y.to_numpy())
 pnodes=ox.distance.nearest_nodes(H,pois_gdf.geometry.x.to_numpy(),pois_gdf.geometry.y.to_numpy())
 onodes=list(onodes) if not isinstance(onodes,(int,str)) else [onodes]
 pnodes=list(pnodes) if not isinstance(pnodes,(int,str)) else [pnodes]
 xs=nx.get_node_attributes(H,'x');ys=nx.get_node_attributes(H,'y')
 snap_origin=[math.hypot(xs[n]-p.x,ys[n]-p.y) for n,p in zip(onodes,origin_gdf.geometry)]
 snap_poi=[math.hypot(xs[n]-p.x,ys[n]-p.y) for n,p in zip(pnodes,pois_gdf.geometry)]
 if max(snap_origin)>800 or max(snap_poi)>1200:raise ValueError('excessive node snap error; coverage invalid')
 # Edge length is route distance, never Euclidean. Weight is travel distance in meters.
 for a,b,k,d in H.edges(keys=True,data=True):
  length=float(d.get('length',-1))
  if length<0 or not math.isfinite(length):raise ValueError('invalid measured edge length')
 facility_at_node=defaultdict(list)
 for p,node,snap in zip(points,pnodes,snap_poi):facility_at_node[node].append((p['kind'],p['osm_id'],snap,p['access_status']))
 origin_outputs=[];pairs_path=derived/f'walk_pairs_{geoid}.csv.gz'
 with gzip.open(pairs_path,'wt',encoding='utf-8',newline='') as out:
  w=csv.writer(out);w.writerow(['city_geoid','tract_geoid','facility_osm_id','kind','route_dist_m','approach_dist_m','facility_snap_m','speed_mps','source_graph_sha256','access_status','origin_node_id','facility_node_id'])
  gp_hash=digest(graphpath)
  for i,(row,node,snap) in enumerate(zip(sample,onodes,snap_origin)):
   # Max speed scenario 1.50m/s and 30min -> 2700m; subtract access snap in interpretation.
   dist=nx.single_source_dijkstra_path_length(H,node,cutoff=max_dist_m,weight='length')
   sums={('library',t):0. for t in (10,20,30)}|{('park',t):0. for t in (10,20,30)}
   sums_upper=dict(sums)
   counts={'library':0,'park':0}
   for reachable,ds in dist.items():
    for kind,osm_id,psnap,status in facility_at_node.get(reachable,[]):
     meters=ds+snap+psnap
     if meters>max_dist_m:continue
     w.writerow([geoid,row['tract_geoid'],osm_id,kind,round(ds,2),round(snap,2),round(psnap,2),speed_mps,gp_hash,status,str(node),str(reachable)]);counts[kind]+=1
     sec=meters/speed_mps
     for minutes in (10,20,30):
      if sec<=minutes*60:
       lo,hi=bounds(status)
       val=math.exp(-sec/(12*60))
       sums[(kind,minutes)]+=lo*val
       sums_upper[(kind,minutes)]+=hi*val
   origin_outputs.append(dict(city_geoid=geoid,city=city,tract_geoid=row['tract_geoid'],youth_15_17=float(row['estimated_youth_15_17']),snap_m=round(snap,2),**{f'{cat}_access_{mins}m':round(sums[(cat,mins)],8) for cat in ('library','park') for mins in (10,20,30)},**{f'{cat}_access_upper_{mins}m':round(sums_upper[(cat,mins)],8) for cat in ('library','park') for mins in (10,20,30)}))
   if i%100==0:print(city,'tract',i+1,'/',len(sample),flush=True)
 pois_path=derived/f'poi_osm_{geoid}.csv'
 with pois_path.open('w',newline='',encoding='utf-8') as f:
  wp=csv.DictWriter(f,fieldnames=list(points[0]));wp.writeheader();wp.writerows(points)
 metric_path=derived/f'city_origins_access_{geoid}.csv'
 with metric_path.open('w',newline='',encoding='utf-8') as f:
  writer=csv.DictWriter(f,fieldnames=list(origin_outputs[0]));writer.writeheader();writer.writerows(origin_outputs)
 cache_list=[dict(path=str(p.relative_to(ROOT)),sha256=digest(p),bytes=p.stat().st_size) for p in cache.rglob('*') if p.is_file()]
 if not cache_list:raise ValueError('OSMnx HTTP original response cache missing: cannot authenticate source')
 receipt={'city':city,'city_geoid':geoid,'started_utc':t0,'completed_utc':datetime.now(timezone.utc).isoformat(),'network_type':'walk','official_tiger_sha256':digest(pp),'source_kind':'RAW_OVERPASS_CACHED_JSON','original_overpass_cached_response_files':cache_list,'real_osm_graph_file':str(graphpath.relative_to(ROOT)),'graph_sha256':gp_hash,'graph_node_count':G.number_of_nodes(),'graph_edge_count':G.number_of_edges(),'library_osm_poi':sum(p['kind']=='library' for p in points),'park_osm_poi':sum(p['kind']=='park' for p in points),'tract_origins':len(origin_outputs),'origin_snap_max_m':max(snap_origin),'poi_snap_max_m':max(snap_poi),'processed_csv_sha256':digest(metric_path),'osm_poi_csv_sha256':digest(pois_path),'od_pairs_sha256':digest(pairs_path),'access_policy':'V19: only OSM_TAGGED_PUBLIC in reference, UNKNOWN only upper bound; real legal eligibility unverified','status':'REAL_OSM_NETWORK_ACQUIRED_AND_GRAPH_ROUTED','limit':'Potential spatial proximity not verified school eligibility, actual park entry, or causal youth welfare'}
 (derived/f'receipt_{geoid}.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False))
 print(city,'PASS real network, orig raw cached, graph SHA',gp_hash,'origin N',len(origin_outputs),flush=True)
 return receipt

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--city',required=True,choices=list(CITY));ap.add_argument('--max-dist-m',type=int,default=2700);args=ap.parse_args()
 run_city(args.city,max_dist_m=args.max_dist_m)
