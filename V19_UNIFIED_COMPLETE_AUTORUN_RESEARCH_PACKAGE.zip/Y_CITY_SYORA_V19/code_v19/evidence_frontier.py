#!/usr/bin/env python3
"""V19: source-dependent evidence horizon, not an imputed city-ranking model.

The reference ranking is immutable. This module separates marginal ACS MOE
stress from OSM unknown-access assumptions, constructs an OUTER score envelope,
and identifies which follow-up observations could most affect exclusion claims.
The outer rectangle can contain combinations that are not jointly feasible.
"""
from __future__ import annotations
import json,math
from pathlib import Path
import numpy as np
import pandas as pd
from acquire_osm_walk import ROOT,digest,CITY
from audit_full_gis import check
OUT=ROOT/'results_v19_gis'


def build_evidence_horizon(rank:pd.DataFrame,moe:pd.DataFrame,ablation:pd.DataFrame,city_weight=0.6,tolerance=1e-4):
    required_rank={'city_geoid','city','M0_acs_citywide','M1_real_walk_20m'}
    required_moe={'city_geoid','acs_m0_low_moe_stress','acs_m0_high_moe_stress'}
    required_abl={'city_geoid','M_network_Q10_reference','M_network_unknown_upper'}
    for df,columns,label in ((rank,required_rank,'RANK'),(moe,required_moe,'MOE'),(ablation,required_abl,'ABLATION')):
        if not columns<=set(df.columns):raise ValueError('MISSING_'+label+'_COLUMNS:'+str(columns-set(df.columns)))
        if df.city_geoid.astype(str).duplicated().any():raise ValueError('DUPLICATE_CITY_IDS_'+label)
    a=rank.copy();b=moe.copy();c=ablation.copy()
    for x in (a,b,c):x['city_geoid']=x.city_geoid.astype(str).str.zfill(7)
    if set(a.city_geoid)!=set(b.city_geoid) or set(a.city_geoid)!=set(c.city_geoid):
        raise ValueError('HETEROGENEOUS_CITY_SET')
    d=a.merge(b[['city_geoid','acs_m0_low_moe_stress','acs_m0_high_moe_stress']],on='city_geoid',validate='one_to_one')
    d=d.merge(c[['city_geoid','M_network_Q10_reference','M_network_unknown_upper']],on='city_geoid',validate='one_to_one')
    vals=d[['M0_acs_citywide','M1_real_walk_20m','acs_m0_low_moe_stress','acs_m0_high_moe_stress','M_network_Q10_reference','M_network_unknown_upper']].to_numpy(float)
    if not np.isfinite(vals).all() or not (0<city_weight<1):raise ValueError('INVALID_SOURCE_NUMBER_OR_NORMATIVE_WEIGHT')
    if (vals<-tolerance).any() or (vals>100+tolerance).any():raise ValueError('SCORE_NOT_0_TO_100')
    if not np.allclose(d.M1_real_walk_20m,d.M_network_Q10_reference,atol=tolerance,rtol=0):
        raise ValueError('ABLATION_NOT_SAME_FROZEN_REFERENCE')
    if (d.acs_m0_low_moe_stress>d.M0_acs_citywide+tolerance).any() or (d.M0_acs_citywide>d.acs_m0_high_moe_stress+tolerance).any():
        raise ValueError('ACS_MOE_STRESS_DOES_NOT_CONTAIN_REFERENCE')
    if (d.M_network_unknown_upper<d.M1_real_walk_20m-tolerance).any():raise ValueError('UNKNOWN_ACCESS_UPPER_BELOW_REFERENCE')
    d['citywide_normative_weight']=city_weight
    d['score_outer_lower']=city_weight*d.acs_m0_low_moe_stress+(d.M1_real_walk_20m-city_weight*d.M0_acs_citywide)
    d['score_outer_upper']=city_weight*d.acs_m0_high_moe_stress+(d.M_network_unknown_upper-city_weight*d.M0_acs_citywide)
    d['acs_contribution_width']=city_weight*(d.acs_m0_high_moe_stress-d.acs_m0_low_moe_stress)
    d['access_contribution_width']=d.M_network_unknown_upper-d.M1_real_walk_20m
    d['outer_width']=d.score_outer_upper-d.score_outer_lower
    if (d.score_outer_upper>100+tolerance).any() or (d.score_outer_lower<-tolerance).any() or (d.outer_width<-tolerance).any():
        raise ValueError('INCONSISTENT_SCORE_ENVELOPE')
    if (d.score_outer_lower>d.M1_real_walk_20m+tolerance).any() or (d.score_outer_upper<d.M1_real_walk_20m-tolerance).any():
        raise ValueError('OUTER_ENVELOPE_EXCLUDES_REFERENCE')
    others_lower=[];others_upper=[]
    for i in range(len(d)):
        others=d.loc[d.index!=d.index[i]]
        others_lower.append(float(others.score_outer_lower.max()))
        others_upper.append(float(others.score_outer_upper.max()))
    d['rivals_best_lower']=others_lower
    d['rivals_best_upper']=others_upper
    d['eliminated_by_verified_outer_bound']=d.score_outer_upper<d.rivals_best_lower-tolerance
    d['certified_best_if_outer_bounds_valid']=d.score_outer_lower>d.rivals_best_upper+tolerance
    d['not_excluded_by_outer_bound']=~d.eliminated_by_verified_outer_bound
    d['exclusion_margin']=d.rivals_best_lower-d.score_outer_upper
    d['source_model']='ACS_2024_marginal_MOE_stress + OSM_unknown_access_outer_product'
    d['semantic_scope']='OUTER_ENVELOPE_NOT_JOINT_PROBABILITY_NOT_CAUSAL'
    return d


def verification_queue(horizon:pd.DataFrame,tol=1e-8):
    required={'city_geoid','city','M0_acs_citywide','M1_real_walk_20m','score_outer_lower','score_outer_upper',
              'rivals_best_lower','acs_contribution_width','access_contribution_width','acs_m0_high_moe_stress'}
    if not required<=set(horizon.columns):raise ValueError('INCOMPLETE_FRONTIER')
    rows=[]
    for r in horizon.itertuples():
        for kind in ('verify_2024_ACS_estimate_MOE_universe','verify_public_facility_access_and_entrances'):
            if kind.startswith('verify_2024'):
                reduction=r.citywide_normative_weight*(r.acs_m0_high_moe_stress-r.M0_acs_citywide)
                action='Audit numerator/denominator and obtain a stronger documented estimate; no claim of guaranteed precision improvement.'
            else:
                reduction=r.access_contribution_width
                action='Confirm sampled access/entrance/opening hours with municipal or facility records; unknown is not public.'
            if reduction<-tol:raise ValueError('INCONSISTENT_POTENTIAL_REDUCTION')
            upper_after=r.score_outer_upper-max(0.,float(reduction))
            rows.append(dict(city_geoid=r.city_geoid,city=r.city,verification_kind=kind,
                reference_score=r.M1_real_walk_20m,
                upper_before=r.score_outer_upper,
                hypothetical_upper_if_resolved_at_reference=upper_after,
                rivals_best_lower=r.rivals_best_lower,
                potential_upper_bound_reduction=max(0.,float(reduction)),
                candidate_at_frontier=bool(r.score_outer_upper>=r.rivals_best_lower-tol),
                would_exclude_if_resolved_to_reference=bool(upper_after<r.rivals_best_lower-tol),
                remaining_nonexclusion_margin=upper_after-r.rivals_best_lower,
                human_validation_action=action,
                interpretation='Ex ante prioritization without assumed resolution outcome, success probability, or travel cost'))
    result=pd.DataFrame(rows)
    return result.sort_values(['candidate_at_frontier','would_exclude_if_resolved_to_reference',
                               'potential_upper_bound_reduction','city'],ascending=[False,False,False,True]).reset_index(drop=True)


def run():
    if check()['status']!='PASS':raise RuntimeError('V19_REAL_CENSUS_AND_GIS_QA_REQUIRED')
    paths={'rank':OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv',
           'moe':OUT/'V19_ACS_MOE_STRESS_ENVELOPES.csv',
           'ablation':OUT/'V19_CONTROLLED_ABLATION.csv'}
    for label,path in paths.items():
        if not path.is_file():raise FileNotFoundError('SOURCE_REQUIRED_'+label+':'+str(path))
    rank=pd.read_csv(paths['rank'],dtype={'city_geoid':str})
    moe=pd.read_csv(paths['moe'],dtype={'city_geoid':str})
    ablation=pd.read_csv(paths['ablation'],dtype={'city_geoid':str})
    if len(rank)!=12 or set(rank.city_geoid.str.zfill(7))!=set(CITY):raise ValueError('NOT_TWELVE_REGISTERED_CITIES')
    config=ROOT/'config_v19/reference_model_v19.json'
    ref_city_weight=float(json.loads(config.read_text())['scoring']['citywide_population_weight'])
    front=build_evidence_horizon(rank,moe,ablation,city_weight=ref_city_weight)
    queue=verification_queue(front)
    f=OUT/'V19_EVIDENCE_HORIZON.csv';q=OUT/'V19_TARGETED_EVIDENCE_QUEUE.csv';OUT.mkdir(exist_ok=True)
    front.to_csv(f,index=False);queue.to_csv(q,index=False)
    receipt={'status':'V19_EMPIRICAL_OUTER_ENVELOPE_COMPUTED','cities':len(front),
             'not_excluded':int(front.not_excluded_by_outer_bound.sum()),
             'certified_best':int(front.certified_best_if_outer_bounds_valid.sum()),
             'source_sha256':{k:digest(v) for k,v in paths.items()},
             'frontier_sha256':digest(f),'queue_sha256':digest(q),'config_sha256':digest(config),
             'interpretation':'Outer bound from ACS marginal MOE endpoint stress and OSM eligibility unknown; deliberately not a statistical joint CI or a probability. Minimax and actual best depend on fixed model, not observed student preferences.'}
    (OUT/'V19_EVIDENCE_HORIZON_RECEIPT.json').write_text(json.dumps(receipt,indent=2))
    print(json.dumps(receipt,indent=2));return front

if __name__=='__main__':run()
