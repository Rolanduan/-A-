#!/usr/bin/env python3
"""V19 real-data-only high-resolution scientific atlas, minimum 7 figures.
No placeholder or synthetic GIS data are permitted in publication outputs.
Figures are all bound to frozen CSV + source hashes.
"""
from pathlib import Path
import json,math,subprocess,shutil
import pandas as pd,geopandas as gpd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from score_official_gis import ROOT,OUT,CITY,digest
from audit_full_gis import check

FIG=ROOT/'figures/v19_real_gis_atlas'

def save(fig,name,paths):
    FIG.mkdir(parents=True,exist_ok=True)
    for ext in ('pdf','svg','png'):
        fig.savefig(FIG/f'{name}.{ext}',dpi=250,bbox_inches='tight',facecolor='white')
    plt.close(fig)
    paths.append({'name':name,'pdf_path':str((FIG/f'{name}.pdf').relative_to(ROOT)),
                  'sha256':digest(FIG/f'{name}.pdf')})

def plot_all():
    if check()['status']!='PASS':raise RuntimeError('REAL_GIS_SOURCE_AUDIT_FAIL')
    if not (OUT/'scenario_receipt.json').is_file():raise RuntimeError('27_REAL_SCENARIOS_REQUIRED')
    if not (OUT/'V19_ACS_MOE_STRESS_ENVELOPES.csv').is_file():raise RuntimeError('REAL_MOE_STRESS_REQUIRED')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'svg.fonttype':'none',
       'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':140})
    d=pd.read_csv(OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv',dtype={'city_geoid':str}).sort_values('M1_rank')
    sens=pd.read_csv(OUT/'REAL_GIS_27_SCENARIOS.csv')
    moe=pd.read_csv(OUT/'V19_ACS_MOE_STRESS_ENVELOPES.csv')
    paths=[]
    # F1: exact ranked vector plot.
    fig,ax=plt.subplots(figsize=(10,7));y=np.arange(len(d));ax.barh(y,d.M1_real_walk_20m,color='#174c66',height=.68)
    ax.set_yticks(y,d.city);ax.invert_yaxis();ax.set_xlim(0,105);ax.set_xlabel('Conditional score (0–100)')
    for i,v in enumerate(d.M1_real_walk_20m):ax.text(v+1,i,f'{v:.2f}',va='center',fontsize=8)
    ax.set_title('Twelve-city reference ranking | ACS household conditions + actual OSM walk network',loc='left')
    fig.text(.02,.01,'Observed: ACS 2024, TIGER 2024, OSM acquisition vintage. Rankings depend on fixed preferences and potential POI access.',fontsize=7)
    save(fig,'F18_01_REFERENCE_12CITY_RANK',paths)
    # F2 M0->M1 slopegraph.
    fig,ax=plt.subplots(figsize=(10,7));x=np.array([0,1]);
    for row in d.itertuples():
        ax.plot(x,[row.M0_rank,row.M1_rank],lw=1.5,marker='o',label=row.city)
        ax.text(1.02,row.M1_rank,row.city,fontsize=7,va='center')
    ax.set_xlim(-.15,1.33);ax.set_ylim(12.6,.4);ax.set_xticks(x,['M0: ACS conditions','M1: ACS + network']);ax.set_ylabel('Rank (1 = highest)')
    ax.grid(axis='y',alpha=.2);ax.set_title('Significant revision: actual city rank movements',loc='left')
    save(fig,'F18_02_M0_TO_M1_RANK_MOVEMENTS',paths)
    # F3 ACS published MOE endpoint-stress envelope (NOT CI)
    merged=d[['city','M1_real_walk_20m']].merge(moe,on='city',validate='1:1')
    fig,ax=plt.subplots(figsize=(10,7));y=np.arange(len(merged))
    ax.errorbar(merged.reference_m1,y,
      xerr=[merged.reference_m1-merged.m1_low_acs_moe_stress,merged.m1_high_acs_moe_stress-merged.reference_m1],
      fmt='o',color='#16455e',ecolor='#cc823c',capsize=3)
    ax.set_yticks(y,merged.city);ax.invert_yaxis();ax.set_xlabel('Model score (0–100)')
    ax.set_title('ACS MOE endpoint sensitivity, NOT simultaneous confidence intervals',loc='left')
    fig.text(.02,.01,'Derived from actual ACS 2024 marginal 90% MOEs, worst-case endpoint stress. GIS/POI uncertainty not included.',fontsize=7)
    save(fig,'F18_03_ACS_MOE_STRESS',paths)
    # F4 scenario rank acceptability heatmap (counts are scenario frequencies, not probabilities).
    sc=sens.copy();sc['scenario_key']=sc.apply(lambda r:f"T{int(r.minutes)}-W{r.w_citywide_acs:.2f}-R{r.equity_rho:.2f}",axis=1)
    sc['rank']=sc.groupby('scenario_key')['score'].rank(ascending=False,method='first').astype(int)
    matrix=sc.pivot(index='city',columns='scenario_key',values='rank').loc[d.city]
    fig,ax=plt.subplots(figsize=(15,6.5));im=ax.imshow(matrix.values,cmap='cividis_r',vmin=1,vmax=12,aspect='auto')
    ax.set_yticks(range(len(d)),d.city);ax.set_xticks(range(len(matrix.columns)),[s.replace('-','\n',1) for s in matrix.columns],fontsize=6,rotation=90)
    cb=fig.colorbar(im,ax=ax,fraction=.025,pad=.02);cb.set_label('Rank (1 highest)')
    ax.set_title('27 normative structural scenarios: actual recomputed rank matrix',loc='left')
    save(fig,'F18_04_27_SCENARIO_RANK_HEATMAP',paths)
    # F5 component comparison from real computed opportunities.
    fig,ax=plt.subplots(figsize=(10,7));y=np.arange(len(d));ax.barh(y,d.library_mean_normalized,label='Potential library accessibility',color='#1d6684',height=.4)
    ax.barh(y+.4,d.park_mean_normalized,label='Potential park accessibility',color='#ad8350',height=.4)
    ax.set_yticks(y+.2,d.city);ax.invert_yaxis();ax.set_xlabel('Population-weighted bounded network opportunity (0–1)')
    ax.legend(loc='lower right');ax.set_title('Complementarity and resource bottlenecks across cities',loc='left')
    save(fig,'F18_05_LIBRARY_PARK_ACCESS_COMPARISON',paths)
    # F6 spatial inequity: compare mean against population-weighted tract Q10.
    fig,ax=plt.subplots(figsize=(10,7));yy=np.arange(len(d))
    ax.hlines(yy,d.opportunity_weighted_Q10,d.opportunity_mean,color='#b6b6b6',lw=3)
    ax.scatter(d.opportunity_weighted_Q10,yy,label='Youth-weighted tract Q10',marker='s',color='#ae6b3b',s=43)
    ax.scatter(d.opportunity_mean,yy,label='Youth-weighted mean',marker='o',color='#1d607c',s=43)
    ax.set_yticks(yy,d.city);ax.invert_yaxis();ax.set_xlabel('Potential walk opportunity (0–1)')
    ax.legend();ax.set_title('Hierarchy and inequality: citywide mean hides low-access tracts',loc='left')
    save(fig,'F18_06_MEAN_VS_LOWEST_DECILE',paths)
    # F7 real TIGER + graph + origins + OSM facilities, selected case.
    import osmnx as ox
    geoid='4805000';state=geoid[:2]
    original=gpd.read_file('zip://'+str(ROOT/f'data/raw_official/v19/tl_2024_{state}_place.zip'))
    city=original.loc[original.PLACEFP.astype(str)==geoid[2:]].to_crs('EPSG:5070')
    graph=ox.io.load_graphml(ROOT/f'data/raw_osm/v19/graphml/{geoid}_Austin_walk.graphml')
    edge=ox.convert.graph_to_gdfs(graph,nodes=False).to_crs('EPSG:5070')
    origins=pd.read_csv(ROOT/'data/processed/v19_gis/official_tract_origins_v19.csv',dtype={'city_geoid':str,'tract_geoid':str})
    origins=origins.loc[origins.city_geoid==geoid]
    access=pd.read_csv(ROOT/f'data/processed/v19_network/city_origins_access_{geoid}.csv',dtype={'tract_geoid':str})
    origins=origins.merge(access[['tract_geoid','library_access_20m']],on='tract_geoid',validate='1:1')
    points=gpd.GeoDataFrame(origins,geometry=gpd.points_from_xy(origins.longitude,origins.latitude),crs='EPSG:4326').to_crs('EPSG:5070')
    pois=pd.read_csv(ROOT/f'data/processed/v19_network/poi_osm_{geoid}.csv')
    ps=gpd.GeoDataFrame(pois,geometry=gpd.points_from_xy(pois.lon,pois.lat),crs='EPSG:4326').to_crs('EPSG:5070')
    fig,ax=plt.subplots(figsize=(9,9));edge.plot(ax=ax,color='#a9b4ba',linewidth=.16,zorder=1)
    city.boundary.plot(ax=ax,color='#184a69',linewidth=1,zorder=3)
    points.plot(ax=ax,column='library_access_20m',cmap='viridis',legend=True,markersize=11,zorder=4,
       legend_kwds={'label':'Observed graph-decayed facility count'})
    ps[ps.kind=='library'].plot(ax=ax,marker='s',color='#b65d2b',markersize=13,zorder=5)
    ax.set_axis_off();ax.set_title('Austin: actual Census tract origins, OSM streets and library locations',loc='left')
    fig.text(.02,.015,'TIGER PLACE 2024; ACS 2024 ages 15–17 area-weighted proxy; OSM PBF/Overpass dated graph. Symbols are not verified entrances.',fontsize=7)
    save(fig,'F18_07_AUSTIN_REAL_GIS_NETWORK',paths)
    # F8 independent source traceability: static dot generated by actual receipts and hashed graph count.
    receipt=json.loads((OUT/'REAL_GIS_COMPUTATION_RECEIPT.json').read_text())
    dot=FIG/'F18_08_RESEARCH_SYSTEM_TRACEABILITY.dot'
    lines=['digraph provenance { rankdir=LR; graph [fontname="Helvetica",bgcolor="white"]; node [shape=box,style="rounded",fontname="Helvetica",fontsize=11];']
    lines+=['acs [label="Census 2024 ACS\\n4 original DAT + SHA256"];',
      'tiger [label="Census TIGER 2024\\n24 ZIP + SHA256"];','osm [label="OSM raw\\n12 walk graphs + hash"];',
      'geo [label="Tract-to-city population\\nreal GIS intersection"];',
      'routes [label="Actual graph routes\\n10/20/30 min"];',
      'm0 [label="M0 household conditions"];','m1 [label="M1 opportunity + equity"];',
      'audit [label="12-city source audit"];','stress [label="ACS MOE + 27 scenarios"];',
      'paper [label="Evidence-locked manuscript"];',
      'acs -> geo; tiger -> geo; osm -> routes; geo -> routes; acs -> m0; m0 -> m1; routes -> m1; m1 -> audit; audit -> stress; stress -> paper; audit -> paper;']
    lines.append('}')
    dot.write_text('\n'.join(lines))
    subprocess.run(['dot','-Tpdf',str(dot),'-o',str(FIG/'F18_08_RESEARCH_SYSTEM_TRACEABILITY.pdf')],check=True)
    subprocess.run(['dot','-Tsvg',str(dot),'-o',str(FIG/'F18_08_RESEARCH_SYSTEM_TRACEABILITY.svg')],check=True)
    paths.append({'name':'F18_08_RESEARCH_SYSTEM_TRACEABILITY','pdf_path':str((FIG/'F18_08_RESEARCH_SYSTEM_TRACEABILITY.pdf').relative_to(ROOT)),'sha256':digest(FIG/'F18_08_RESEARCH_SYSTEM_TRACEABILITY.pdf')})
    # F9: observed cross-city-borders flow mechanism; NOT weighted by population.
    spill=pd.read_csv(ROOT/'results_v19/H3_CROSS_BOUNDARY_SERVICE_FLOW.csv')
    spill=spill.sort_values('decay_weighted_cross_border_route_pair_share',ascending=True)
    fig,ax=plt.subplots(figsize=(10,7))
    ax.barh(spill.city,spill.decay_weighted_cross_border_route_pair_share*100,color='#315a71')
    ax.set_xlim(0,100);ax.set_xlabel('Share of route-pair contributions beyond municipal boundary (%)')
    ax.set_title('Open systems: feasible opportunities can cross city borders',loc='left')
    fig.text(.02,.01,'From Census city polygons, OSM POI points and network-routed pairs. Decay-weighted, NOT youth-population-weighted.',fontsize=7)
    save(fig,'F18_09_CROSS_BOUNDARY_SERVICE_EXPOSURE',paths)
    # F10: holism/complementarity model comparison grounded in same observed components.
    c=pd.read_csv(ROOT/'results_v19/H4_COMPLEMENTARITY_BOTTLENECK.csv')
    fig,ax=plt.subplots(figsize=(9,7))
    ax.scatter(c.additive_reference_mean,c.complementary_geom_mean,s=54,color='#376b87')
    for r in c.itertuples():ax.annotate(r.city,(r.additive_reference_mean,r.complementary_geom_mean),xytext=(5,3),textcoords='offset points',fontsize=7)
    ax.set_xlabel('Additive library + park utility (mean)')
    ax.set_ylabel('Geometric complementarity utility (mean)')
    ax.set_title('Holism stress test: both opportunity channels versus one strong channel',loc='left')
    ax.grid(alpha=.15)
    save(fig,'F18_10_NONCOMPENSATORY_OPPORTUNITY_TEST',paths)
    qa={'status':'TEN_GENUINE_SOURCE_BACKED_FIGURES_READY','source_ranking_sha256':digest(OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv'),
        'num_figures':len(paths),'figures':paths,'city_count':len(d)}
    (FIG/'figure_manifest.json').write_text(json.dumps(qa,indent=2));print(json.dumps(qa,indent=2));return qa

if __name__=='__main__':plot_all()
