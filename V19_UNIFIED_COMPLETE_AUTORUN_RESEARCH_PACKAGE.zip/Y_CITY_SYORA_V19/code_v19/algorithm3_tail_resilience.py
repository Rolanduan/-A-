"""V19 Algorithm III: population-weighted lowest-alpha opportunity and exact edge-removal re-routing."""
from __future__ import annotations
import numpy as np
import networkx as nx
from algorithm1_adaptive_routing import compute_kernel

def weighted_lower_tail(values,weights,alpha=.1):
    v=np.asarray(values,dtype=float);w=np.asarray(weights,dtype=float)
    if v.ndim!=1 or w.shape!=v.shape or len(v)==0 or not 0<alpha<=1:
        raise ValueError('BAD_TAIL_INPUT')
    if np.any(~np.isfinite(v)) or np.any(~np.isfinite(w)) or np.any(w<0) or w.sum()<=0:raise ValueError('INVALID_VALUES_OR_WEIGHTS')
    order=np.argsort(v,kind='stable');v=v[order];w=w[order]
    cap=float(w.sum())*alpha;left=cap;total=0.
    for val,weight in zip(v,w):
        take=min(float(weight),left);total+=take*float(val);left-=take
        if left<=1e-12:break
    return total/cap

def edge_removal_loss(G,edge,origins,facilities,population,cutoff_seconds=1200,tau_seconds=720,weight='walking_seconds'):
    if len(origins)!=len(population):raise ValueError('WEIGHT_LENGTH_MISMATCH')
    baseline=compute_kernel(G,origins,facilities,cutoff_seconds,tau_seconds,weight)
    H=G.copy()
    try:
        if H.is_multigraph():H.remove_edge(*edge)
        else:H.remove_edge(edge[0],edge[1])
    except (nx.NetworkXError,KeyError) as e:raise ValueError('EDGE_NOT_PRESENT') from e
    after=compute_kernel(H,origins,facilities,cutoff_seconds,tau_seconds,weight)
    before=np.array([sum(baseline['kernel'][(o,f)] for f in facilities) for o in origins]);aft=np.array([sum(after['kernel'][(o,f)] for f in facilities) for o in origins]);w=np.asarray(population,dtype=float)
    if (aft>before+1e-10).any():raise AssertionError('EDGE_REMOVAL_INCREASED_OPPORTUNITY')
    return {'mean_loss':float(np.dot(w,before-aft)/w.sum()),'tail_loss':weighted_lower_tail(before,w)-weighted_lower_tail(aft,w),
            'origin_losses':(before-aft).tolist(),'baseline_tail':weighted_lower_tail(before,w),'closed_tail':weighted_lower_tail(aft,w)}
