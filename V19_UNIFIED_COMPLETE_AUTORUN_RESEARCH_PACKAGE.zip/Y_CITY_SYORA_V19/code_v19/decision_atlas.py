#!/usr/bin/env python3
"""V19: two inspectable research figures from verified evidence horizons and paths."""
from __future__ import annotations
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from acquire_osm_walk import ROOT,digest
from audit_full_gis import check
OUT=ROOT/'results_v19_gis';FIG=ROOT/'figures/v19_decision_evidence'

def generate():
    if check()['status']!='PASS':raise RuntimeError('ORIGINAL_SOURCE_GIS_REQUIRED')
    horizon=OUT/'V19_EVIDENCE_HORIZON.csv';pref=OUT/'V19_DECLARED_PREFERENCE_FAMILIES.csv';path=OUT/'V19_EXACT_LEADER_TRANSITIONS.csv'
    for p in (horizon,pref,path):
        if not p.is_file():raise FileNotFoundError('V19_DECISION_ATLAS_INPUT_MISSING:'+str(p))
    d=pd.read_csv(horizon).sort_values('M1_real_walk_20m',ascending=True)
    a=pd.read_csv(pref);b=pd.read_csv(path)
    if len(d)!=12 or len(a)!=48:raise ValueError('CROSS_CITY_PLOT_WITHOUT_FULL_RESULTS')
    FIG.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'pdf.fonttype':42,'svg.fonttype':'none',
            'axes.spines.top':False,'axes.spines.right':False})
    records=[]
    fig,ax=plt.subplots(figsize=(11,7.2))
    y=np.arange(len(d))
    ax.hlines(y,d.score_outer_lower,d.score_outer_upper,color='#a7b6c2',lw=5,alpha=.75,label='Outer evidence envelope')
    ax.scatter(d.M1_real_walk_20m,y,marker='o',color='#153c59',s=50,zorder=3,label='Frozen reference M1')
    for i,r in enumerate(d.itertuples()):
        if r.eliminated_by_verified_outer_bound:ax.plot(r.score_outer_upper,i,marker='x',color='#bc6038',ms=9)
    ax.set_yticks(y,d.city);ax.set_xlabel('Model score (0–100)')
    ax.set_xlim(0,100);ax.grid(axis='x',alpha=.18)
    ax.set_title('Evidence horizon: ACS sampling stress × unverified facility access',loc='left')
    ax.legend(loc='lower right',frameon=False)
    fig.text(.01,.01,'Outer, possibly overconservative bounds; NOT joint confidence intervals, city probabilities or survey preferences.\nSource: actual Census MOEs and OSM access tags from frozen 12-city audit.',fontsize=9)
    records.extend(save(fig,'F19_DECISION_01_EVIDENCE_HORIZON',{'horizon':digest(horizon)}))
    scenarios=['reference','household_continuity','nearby_public_opportunity','lower_access_safeguard']
    mat=a.pivot(index='city',columns='preference_id',values='rank').reindex(index=d.city.iloc[::-1].tolist(),columns=scenarios)
    if mat.isna().any().any():raise ValueError('INCOMPLETE_PREFERENCE_MATRIX')
    fig,ax=plt.subplots(figsize=(10,7.5))
    im=ax.imshow(mat.values,cmap='cividis_r',vmin=1,vmax=12,aspect='auto')
    ax.set_yticks(range(len(mat)),mat.index)
    ax.set_xticks(range(4),['Original\nreference','Household\ncontinuity','Nearby public\nopportunity','Lower-access\nsafeguard'])
    for i in range(len(mat)):
        for j in range(4):ax.text(j,i,str(int(mat.iloc[i,j])),ha='center',va='center',fontsize=10,color='white' if mat.iloc[i,j]>6 else '#182b39')
    bar=fig.colorbar(im,ax=ax,shrink=.85);bar.set_label('Rank (1 = highest)')
    ax.set_title('Declared household priorities: ranking differences are not a preference survey',loc='left')
    fig.text(.01,.01,'All rank values recomputed from the SAME Census/OSM six-component utility vector; primary M1 remains fixed.',fontsize=9)
    records.extend(save(fig,'F19_DECISION_02_PREFERENCE_FAMILIES',{'preference':digest(pref),'paths':digest(path)}))
    manifest={'status':'TWO_REAL_SOURCE_BACKED_V19_DECISION_FIGURES','figures':records,
       'source_files_sha256':{'horizon':digest(horizon),'scenarios':digest(pref),'transitions':digest(path)},
       'warning':'No figures generated without actual real GIS and decision data.'}
    (FIG/'V19_DECISION_FIGURES_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
    return manifest

def save(fig,stem,inputs):
    fig.tight_layout(rect=[0,.05,1,.96]);dest=[]
    for ext in ('pdf','svg','png'):
        p=FIG/(stem+'.'+ext);fig.savefig(p,dpi=220,bbox_inches='tight')
        dest.append(dict(name=stem,kind=ext,path=str(p.relative_to(ROOT)),sha256=digest(p),inputs=inputs))
    plt.close(fig);return dest
if __name__=='__main__':print(json.dumps(generate(),indent=2))
