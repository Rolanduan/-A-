#!/usr/bin/env python3
"""V19 controlled mechanism decomposition: same 12 cities, same POIs, same weights.

Five distinct objects: household baseline (NOT an inventory model), inventory,
Euclidean-distance proxy, true directed-walk network, spatial-equity network.
An eligibility upper-bound uses UNKNOWN OSM facilities; reference only OSM-tagged public.
Do not present changed ranks as validation of youth wellbeing or proof of causation.
"""
from __future__ import annotations
import json,math
from pathlib import Path
import numpy as np
import pandas as pd
from pyproj import Transformer
from access_policy import opportunity_at_distance
from acquire_osm_walk import weighted_quantile,digest,CITY,ROOT

NET=ROOT/'data/processed/v19_network'
OUT=ROOT/'results_v19_gis'
T=Transformer.from_crs('EPSG:4326','EPSG:5070',always_xy=True)


def utility(raw):
    v=float(raw)
    if not math.isfinite(v) or v<0:raise ValueError('negative or nonfinite access')
    return 1-math.exp(-v/2)


def combine_domains(lib,park):return .55*utility(lib)+.45*utility(park)


def score_model(base, opportunities, weights, rho=0.0):
    w=np.array(weights,float);x=np.array(opportunities,float)
    if len(w)!=len(x) or min(w)<0 or sum(w)<=0 or max(x)>1+1e-9 or min(x)<-1e-9:raise ValueError('invalid numeric domain')
    mean=float(np.dot(w,x)/sum(w));lower=float(weighted_quantile(x,w,.1))
    return .6*float(base)+40*((1-rho)*mean+rho*lower),mean,lower


def inventory_and_euclid(origins,poi,speed_mps=1.25,cutoff_min=20):
    """Uses same OSM_TAGGED_PUBLIC POIs as actual walk; straight line is only comparator."""
    tagged=poi[poi.access_status=='OSM_TAGGED_PUBLIC'].copy()
    tagged=tagged[tagged.kind.isin(['library','park'])]
    if tagged.empty:raise ValueError('NO_TAGGED_PUBLIC_POIS_FOR_CONTROLLED_EXPERIMENT')
    # City facility inventory counts exactly the same candidate set used for network access.
    counts=tagged.kind.value_counts().to_dict()
    inventory=combine_domains(counts.get('library',0),counts.get('park',0))
    ox,oy=T.transform(origins.longitude.to_numpy(float),origins.latitude.to_numpy(float))
    dx,dy=T.transform(tagged.lon.to_numpy(float),tagged.lat.to_numpy(float))
    kinds=tagged.kind.to_numpy()
    # Chunking origins keeps memory bounded for city-wide GIS comparisons.
    straight=[]
    for x,y in zip(ox,oy):
        dist=np.hypot(dx-x,dy-y)
        score={kind:float(sum(opportunity_at_distance(float(d),speed_mps,cutoff_min) for d in dist[kinds==kind])) for kind in ('library','park')}
        straight.append(combine_domains(score['library'],score['park']))
    return inventory,np.array(straight,dtype=float),counts


def create_city_comparison(ref,origins,pois):
    """Pure dataframe interface supports separately verified fixtures and 12-city pipeline."""
    base=float(ref['M0_acs_citywide'])
    p=origins.copy().sort_values('tract_geoid').reset_index(drop=True)
    w=p.youth_15_17.to_numpy(dtype=float)
    if not np.isfinite(w).all() or (w<0).any() or w.sum()<=0:raise ValueError('INVALID_YOUTH_WEIGHTS')
    count,euclid,inv_by_type=inventory_and_euclid(p,pois)
    network=np.array([combine_domains(a,b) for a,b in zip(p.library_access_20m,p.park_access_20m)])
    unknown_upper=np.array([combine_domains(a,b) for a,b in zip(p.library_access_upper_20m,p.park_access_upper_20m)])
    inv_score,_,_=score_model(base,[count]*len(p),w)
    euclid_score,_,_=score_model(base,euclid,w)
    network_score,network_mean,q10=score_model(base,network,w)
    m1,_,_=score_model(base,network,w,rho=.25)
    upper,_,_=score_model(base,unknown_upper,w,rho=.25)
    no_pop=score_model(base,network,np.ones(len(w)),rho=.25)[0]
    if abs(m1-float(ref['M1_real_walk_20m']))>1e-4:
        raise ValueError('PRIMARY_RANKING_DISAGREES_WITH_SAME_SOURCE_ABLATION')
    if upper+1e-9<m1:raise ValueError('UNKNOWN_UPPER_BELOW_REFERENCE')
    return dict(city_geoid=str(ref['city_geoid']).zfill(7),city=ref['city'],
        M0_household_only=base,M_inventory_same_POIs=inv_score,M_euclidean_same_POIs=euclid_score,
        M_network_mean_same_POIs=network_score,M_network_Q10_reference=m1,
        M_network_unknown_upper=upper,M_network_no_population_weights=no_pop,
        network_youth_mean=network_mean,network_youth_Q10=q10,
        n_tagged_public_lib=inv_by_type.get('library',0),n_tagged_public_park=inv_by_type.get('park',0),
        n_unknown=int((pois.access_status=='UNKNOWN').sum()),
        spatial_mechanism_change=network_score-euclid_score,
        fairness_change=m1-network_score,
        inventory_to_network_change=network_score-inv_score,
        unknown_access_span=upper-m1)


def run():
    from audit_full_gis import check
    if check()['status']!='PASS':raise RuntimeError('V19_ORIGINAL_DATA_AND_GIS_AUDIT_REQUIRED')
    path=OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv'
    df=pd.read_csv(path,dtype={'city_geoid':str});df.city_geoid=df.city_geoid.str.zfill(7)
    rows=[]
    origin_file=ROOT/'data/processed/v19_gis/official_tract_origins_v19.csv'
    all_origins=pd.read_csv(origin_file,dtype={'city_geoid':str,'tract_geoid':str});all_origins.city_geoid=all_origins.city_geoid.str.zfill(7)
    for _,ref in df.iterrows():
        geoid=ref.city_geoid
        p=NET/f'poi_osm_{geoid}.csv';origin=NET/f'city_origins_access_{geoid}.csv'
        pois=pd.read_csv(p,dtype={'osm_id':str});tracts=pd.read_csv(origin,dtype={'tract_geoid':str})
        locations=all_origins[all_origins.city_geoid==geoid][['tract_geoid','longitude','latitude']]
        origins=tracts.merge(locations,on='tract_geoid',validate='one_to_one')
        if len(origins)!=len(tracts):raise ValueError('MISSING_TRACT_LOCATION_'+geoid)
        rows.append(create_city_comparison(ref,origins,pois))
    result=pd.DataFrame(rows)
    for col in ('M0_household_only','M_inventory_same_POIs','M_euclidean_same_POIs','M_network_mean_same_POIs','M_network_Q10_reference','M_network_unknown_upper'):
        order=result.sort_values([col,'city'],ascending=[False,True]).city.to_list()
        result['rank_'+col]=result.city.map({c:i+1 for i,c in enumerate(order)})
    OUT.mkdir(exist_ok=True)
    target=OUT/'V19_CONTROLLED_ABLATION.csv';result.to_csv(target,index=False)
    # Distinguish model domain addition from replacement of distance by network.
    audit={'status':'ACTUAL_SAME_FACILITY_MODEL_ABLATIONS_PASSED','rows':len(result),'sha256':digest(target),
           'same_poi_set':True,'reference_access':'OSM_TAGGED_PUBLIC_ONLY',
           'unknown':'scenario upper only, not assumed public',
           'scope':'Changing the citywide->inventory model adds a domain; Euclidean->network comparison isolates road geometry with identical facilities; independent validation still required.'}
    (OUT/'V19_CONTROLLED_ABLATION_RECEIPT.json').write_text(json.dumps(audit,indent=2))
    print(audit);return result

if __name__=='__main__':run()
