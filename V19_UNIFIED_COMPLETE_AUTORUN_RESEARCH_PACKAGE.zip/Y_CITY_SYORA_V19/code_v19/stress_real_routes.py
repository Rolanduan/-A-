#!/usr/bin/env python3
"""Network-route/eligibility/source-missingness stress from actual OD records.

Missing-POI scenarios are *hypothetical dropouts on observed identifiers*,
not measured omission rates. Speed reuses actual measured OSM route metres.
"""
from __future__ import annotations
import csv,gzip,hashlib,json,math
from collections import defaultdict
from pathlib import Path
import pandas as pd
from acquire_osm_walk import ROOT,CITY,weighted_quantile,digest
from access_policy import aggregate_pair_bounds

NET=ROOT/'data/processed/v19_network';OUT=ROOT/'results_v19_gis'


def identity_dropout(osm_id,fraction):
    if not 0<=fraction<=1:raise ValueError('fraction outside 0..1')
    n=int.from_bytes(hashlib.sha256(str(osm_id).encode('utf-8')).digest()[:8],'big')
    return n/(2**64)<fraction


def group_pairs(rows):
    data=defaultdict(list)
    for r in rows:data[str(r['tract_geoid'])].append(r)
    return data


def city_counterfactual(base,tracts,pairs,speed,missing_fraction,unknown_as_open):
    by_tract=group_pairs(pairs)
    aa=[];weight=[]
    for _,r in tracts.iterrows():
        members=by_tract.get(str(r['tract_geoid']),[])
        members=[v for v in members if not identity_dropout(v['facility_osm_id'],missing_fraction)]
        x=aggregate_pair_bounds(members,speed_mps=speed,minutes=20)
        field='upper' if unknown_as_open else 'tagged'
        L=1-math.exp(-x['library'][field]/2);P=1-math.exp(-x['park'][field]/2)
        aa.append(.55*L+.45*P)
        weight.append(float(r['youth_15_17']))
    if not weight or sum(weight)<=0:raise ValueError('NO_TRACT_WEIGHTS')
    avg=sum(a*w for a,w in zip(aa,weight))/sum(weight)
    q10=weighted_quantile(aa,weight,.1)
    return .6*base+40*(.75*avg+.25*q10)


def run():
    from audit_full_gis import check
    if check()['status']!='PASS':raise RuntimeError('GEO_SOURCE_AUDIT_REQUIRED')
    r=OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv'
    main=pd.read_csv(r,dtype={'city_geoid':str});main.city_geoid=main.city_geoid.str.zfill(7)
    datasets={}
    for geoid in CITY:
        rec=json.loads((NET/f'receipt_{geoid}.json').read_text())
        p=NET/f'walk_pairs_{geoid}.csv.gz'
        if digest(p)!=rec['od_pairs_sha256']:raise ValueError('RAW_OD_CHANGED_'+geoid)
        with gzip.open(p,'rt',newline='',encoding='utf-8') as f:pairs=list(csv.DictReader(f))
        if not pairs or 'access_status' not in pairs[0]:raise ValueError('NOT_V19_ACCESS_AWARE_OD_FORMAT')
        tracts=pd.read_csv(NET/f'city_origins_access_{geoid}.csv',dtype={'tract_geoid':str})
        datasets[geoid]=(tracts,pairs)
    results=[]
    for speed in (0.9,1.25,1.5):
        for missing in (0,.1,.25):
            for upper in (False,True):
                scenario=f'walk_v{speed:g}_missing{int(missing*100)}_unknown_{int(upper)}'
                cityscores=[]
                for row in main.itertuples():
                    tracts,pairs=datasets[row.city_geoid]
                    score=city_counterfactual(float(row.M0_acs_citywide),tracts,pairs,speed,missing,upper)
                    cityscores.append((row.city,score,row.city_geoid))
                ranking=sorted(cityscores,key=lambda c:(-c[1],c[0]))
                for rank,(city,value,geoid) in enumerate(ranking,1):
                    results.append(dict(scenario=scenario,walk_speed_mps=speed,
                         hypothetical_poi_missing_fraction=missing,unknown_access_upper_scenario=upper,
                         city=city,city_geoid=geoid,score=round(value,8),rank=rank,
                         interpretation='Finite, deliberately chosen hypothetical stress, NOT confidence probability'))
    out=OUT/'V19_REAL_OD_ACCESS_SPEED_MISSINGNESS_STRESS.csv'
    pd.DataFrame(results).to_csv(out,index=False)
    report={'status':'ACTUAL_OD_RECOMPUTATION_STRESS_PASSED','scenarios':18,'rows':len(results),
            'raw_rank_sha256':digest(r),'output_sha256':digest(out),
            'warning':'Missingness fraction is an imposed scenario; unknown upper bound is NOT verified access.'}
    (OUT/'V19_REAL_OD_STRESS_RECEIPT.json').write_text(json.dumps(report,indent=2))
    print(report);return report
if __name__=='__main__':run()
