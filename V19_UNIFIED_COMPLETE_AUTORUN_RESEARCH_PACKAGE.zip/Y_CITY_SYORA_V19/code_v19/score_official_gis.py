#!/usr/bin/env python3
"""Compute the twelve-city official-ACS + actual OSM-walking rank; never release on partial data.
Normative scoring anchors and revision weights frozen before results; see V19_MASTER.
No outcome is written if any city lacks original-source receipts or verified route metrics.
"""
from pathlib import Path
import csv,hashlib,json,math,sys
import pandas as pd
from acquire_osm_walk import CITY,weighted_quantile,digest,ROOT
RAW=ROOT/'data/raw_official/v19';NET=ROOT/'data/processed/v19_network';OUT=ROOT/'results_v19_gis'
TABLES=('B01001','B25070','B28002','B17001')
def get_table(table):
 raw=RAW/f'acs_2024_5y_{table}.dat'
 if not raw.exists():raise FileNotFoundError(f'OFFICIAL ACS ORIGINAL {table} missing')
 # The parsed 12-row file must have been produced from original by the official downloader.
 p=ROOT/f'data/processed/v19_official_acs/ACS_{table}_12_cities.psv'
 if not p.exists():raise FileNotFoundError('subset missing for '+table)
 with p.open(encoding='utf-8-sig',newline='') as f:
  r=list(csv.DictReader(f,delimiter='|'))
 if len(r)!=12:raise ValueError(f'{table} does not cover all 12 cities')
 manifest=json.loads((ROOT/'qa_v19/census_original_manifest.json').read_text())
 match=[row for row in manifest['sources'] if row['source_id']=='ACS_'+table]
 if len(match)!=1:raise ValueError('MISSING_OR_DUPLICATE_CENSUS_ACS_MANIFEST:'+table)
 if digest(raw)!=match[0].get('sha256'):raise ValueError('OFFICIAL_ORIGINAL_CHANGED:'+table)
 if digest(p)!=match[0].get('derived_city_subset',{}).get('derived_sha256'):raise ValueError('12_CITY_SUBSET_CHANGED:'+table)
 return {str(d['GEO_ID'])[9:]:d for d in r},digest(raw)
def cell(row,table,num):
 key=f'{table}_E{num:03d}'
 s=row.get(key)
 if s is None:raise ValueError('field not present '+key)
 v=float(s)
 if not math.isfinite(v) or v<0 or v>=9e8:raise ValueError('bad government value '+key+'='+s)
 return v
def clamp(x):return max(0.,min(1.,x))
def u_acscity(t):
 br=t['B25070'];pov=t['B17001'];web=t['B28002']
 rent_den=cell(br,'B25070',1)-cell(br,'B25070',11)
 if rent_den<=0:raise ValueError('no ACS rent burden denominator')
 rent=sum(cell(br,'B25070',i) for i in (7,8,9,10))/rent_den
 poverty=cell(pov,'B17001',2)/cell(pov,'B17001',1)
 internet=cell(web,'B28002',4)/cell(web,'B28002',1) # E004 broadband of any type, not E002 any Internet subscription
 # Normative scales fixed a priori; not fit to known city ranks.
 util={'rent_burden':clamp((.80-rent)/.60),'poverty':clamp((.35-poverty)/.35),'broadband':clamp((internet-.60)/.40)}
 score=100*(.35*util['rent_burden']+.35*util['poverty']+.30*util['broadband'])
 return score,dict(rent_burden_share=rent,poverty_share=poverty,broadband_share=internet,**util)
def run():
 config=json.loads((ROOT/'config_v19/reference_model_v19.json').read_text())
 expected={'rent':0.35,'poverty':0.35,'broadband':0.30}
 if config['scoring']['M0_weights']!=expected or config['scoring']['broadband_fraction']!='B28002_E004/B28002_E001':
  raise ValueError('MODEL_CONTRACT_V19_SOURCE_CODE_MISMATCH')
 if config['scoring']['citywide_population_weight']!=.6 or config['scoring']['walk_threshold_minutes']!=20:
  raise ValueError('MODEL_WEIGHT_OR_THRESHOLD_CHANGED_WITHOUT_REVIEW')
 alltable={};allsha={}
 from pathlib import Path as _Path
 manifest=ROOT/'qa_v19/census_original_manifest.json'
 if not manifest.exists():raise FileNotFoundError('Missing V19 original Census manifest')
 m=json.loads(manifest.read_text())
 if not m.get('all_pass'):raise ValueError('Census 28 raw files must pass before V19 score')
 for tab in TABLES:
  t,h=get_table(tab);alltable[tab]=t;allsha[tab]=h
 receipts={};origin_files={}
 for g in CITY:
  receipt=NET/f'receipt_{g}.json';orig=NET/f'city_origins_access_{g}.csv'
  if not receipt.exists() or not orig.exists():raise FileNotFoundError(f'OFFICIAL OSM WALK NETWORK NOT COMPUTED for city {g}')
  r=json.loads(receipt.read_text());
  if r['status']!='REAL_OSM_NETWORK_ACQUIRED_AND_GRAPH_ROUTED' or digest(orig)!=r['processed_csv_sha256']:raise ValueError('network receipt missing or tampered '+g)
  if r.get('source_kind')=='RAW_GEOFABRIK_PBF':
   pbf=ROOT/r['source_pbf_path'] if not __import__('pathlib').Path(r['source_pbf_path']).is_absolute() else __import__('pathlib').Path(r['source_pbf_path'])
   if not pbf.exists() or digest(pbf)!=r.get('source_pbf_sha256'):raise ValueError('raw original PBF SHA mismatch '+g)
  elif not r.get('original_overpass_cached_response_files'):
   raise ValueError('Neither genuine original Overpass cache nor raw Geofabrik PBF present '+g)
  for cache in r.get('original_overpass_cached_response_files',[]):
   fp=ROOT/cache['path']
   if not fp.exists() or digest(fp)!=cache['sha256']:raise ValueError('original OSM cached raw response missing or modified')
  if digest(ROOT/r['real_osm_graph_file'])!=r['graph_sha256']:raise ValueError('graph HASH mismatch')
  receipts[g]=r;origin_files[g]=orig
 ranked=[]
 for g,city in CITY.items():
  t={k:alltable[k][g] for k in TABLES}
  m0,components=u_acscity(t)
  youth=int(cell(t['B01001'],'B01001',6)+cell(t['B01001'],'B01001',30))
  d=pd.read_csv(origin_files[g]);w=d.youth_15_17.astype(float)
  for kind in ('library','park'):
   if f'{kind}_access_upper_20m' not in d:
    raise ValueError('V19_UNKNOWN_ACCESS_BOUNDS_REQUIRED_'+g)
   if (d[f'{kind}_access_upper_20m']<d[f'{kind}_access_20m']-1e-8).any():
    raise ValueError('UNKNOWN_ACCESS_UPPER_NOT_MONOTONE_'+g)
  if w.sum()<=0:raise ValueError('no youth weight')
  # This is an area-weighted population proxy; the tabulation totals may differ.
  if not (.6<=w.sum()/youth<=1.4):raise ValueError('tract youth demographic coverage implausible for '+city)
  li=d.library_access_20m.apply(lambda x:1-math.exp(-float(x)/2))
  pa=d.park_access_20m.apply(lambda x:1-math.exp(-float(x)/2))
  a=.55*li+.45*pa
  a_mean=float((a*w).sum()/w.sum());q10=weighted_quantile(a,w,.1)
  a_equity=.75*a_mean+.25*q10
  m1=100*(.60*m0/100+.40*a_equity)
  ranked.append(dict(city_geoid=g,city=city,M0_acs_citywide=round(m0,8),M1_real_walk_20m=round(m1,8),youth_city_acs_15_17=youth,youth_tract_area_weighted=round(w.sum(),3),library_mean_normalized=round(float((li*w).sum()/w.sum()),8),park_mean_normalized=round(float((pa*w).sum()/w.sum()),8),opportunity_mean=round(a_mean,8),opportunity_weighted_Q10=round(q10,8),network_graph_sha256=receipts[g]['graph_sha256'],acs_B01001_sha256=allsha['B01001'],status='ACTUAL_OFFICIAL_ACS_AND_REAL_OSM_ROUTING',**components))
 d=pd.DataFrame(ranked).sort_values(['M1_real_walk_20m','city'],ascending=[False,True]);d['M1_rank']=range(1,len(d)+1)
 prior=d.sort_values(['M0_acs_citywide','city'],ascending=[False,True]);rank0={r.city:i+1 for i,r in enumerate(prior.itertuples())};d['M0_rank']=d.city.map(rank0)
 assert len(d)==12 and set(d.M1_rank)==set(range(1,13))
 OUT.mkdir(exist_ok=True);csvpath=OUT/'FINAL_12_CITY_REAL_GIS_RANKING.csv';d.to_csv(csvpath,index=False)
 release={'status':'V19_FULL_GIS_RANKING_COMPUTED_NOT_YET_INDEPENDENTLY_AUDITED','n_cities':12,'winner':d.iloc[0].city,'winner_score':float(d.iloc[0].M1_real_walk_20m),'ranking_sha256':digest(csvpath),'source_sha256':allsha,'city_graph_sha256':{CITY[g]:receipts[g]['graph_sha256'] for g in CITY},'model_weights':{'citywide_acs':.60,'network_opportunity':.40,'library_in_network':.55,'park_in_network':.45,'spatial_fairness_weight':.25},'uncertainty':'Population area interpolation and OSM POI eligibility are modeled proxies'}
 (OUT/'REAL_GIS_COMPUTATION_RECEIPT.json').write_text(json.dumps(release,indent=2))
 print(json.dumps(release,indent=2));return d
if __name__=='__main__':run()
