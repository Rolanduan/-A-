#!/usr/bin/env python3
"""Real-source-gated V19 algorithm pilot for all twelve frozen cities.
Pilot uses capped tract origins/candidate nodes; findings must not be claimed as
full-city policy optimum. Frozen M1 ranking is not modified.
"""
from __future__ import annotations
import csv,hashlib,json,math,time
from pathlib import Path
import networkx as nx
import numpy as np
import pandas as pd
from acquire_osm_walk import ROOT,CITY,digest
from audit_full_gis import check
from algorithm1_adaptive_routing import compute_kernel,reference_od
from algorithm2_submodular import celf,exhaustive_optimum
from algorithm3_tail_resilience import weighted_lower_tail,edge_removal_loss
from graph_matrix_contract import kernel_matrix,category_saturated_opportunity

OUT=ROOT/'results_v19_gis'
NET=ROOT/'data/processed/v19_network'

def _nodes(values,G):
    all_nodes=set(G.nodes)
    out=[]
    for value in values:
        v=value
        if v not in all_nodes:
            v=str(value)
        if v not in all_nodes:
            try:v=int(value)
            except (TypeError,ValueError):pass
        if v not in all_nodes:raise ValueError('INVALID_NODE_REFERENCE:'+str(value))
        out.append(v)
    return out

def city_pilot(geoid, limit_origins=36,limit_candidates=12):
    import osmnx as ox
    import geopandas as gpd
    from shapely.geometry import Point
    receipt=json.loads((NET/f'receipt_{geoid}.json').read_text())
    graph_file=ROOT/receipt['real_osm_graph_file']
    if not graph_file.is_file() or digest(graph_file)!=receipt['graph_sha256']:
        raise ValueError('UNVERIFIED_NETWORK_GRAPH_'+geoid)
    G=ox.load_graphml(filepath=graph_file)
    H=ox.project_graph(G,to_crs='EPSG:5070')
    for a,b,k,d in H.edges(keys=True,data=True):
        d['walking_seconds']=float(d['length'])/1.25
    origin_path=ROOT/'data/processed/v19_gis/official_tract_origins_v19.csv'
    origins=pd.read_csv(origin_path,dtype={'city_geoid':str,'tract_geoid':str})
    origins=origins[origins.city_geoid.str.zfill(7)==geoid].sort_values('tract_geoid')
    if len(origins)<2:raise ValueError('NO_REAL_ORIGIN_SET')
    # Deterministic subset covers the city but has no full-city inference status.
    selected=origins.iloc[np.unique(np.linspace(0,len(origins)-1,min(limit_origins,len(origins)),dtype=int))]
    points=gpd.GeoDataFrame(selected,geometry=gpd.points_from_xy(selected.longitude,selected.latitude),crs='EPSG:4326').to_crs('EPSG:5070')
    src=_nodes(list(ox.distance.nearest_nodes(H,points.geometry.x.to_numpy(),points.geometry.y.to_numpy())),H)
    weights=selected.estimated_youth_15_17.astype(float).to_numpy()
    poi_path=NET/f'poi_osm_{geoid}.csv'
    poi=pd.read_csv(poi_path)
    poi=poi[poi.access_status=='OSM_TAGGED_PUBLIC'].sort_values('osm_id',key=lambda s:s.astype(str))
    if len(poi)<2:raise ValueError('NOT_ENOUGH_CONFIRMED_POIS')
    pois=gpd.GeoDataFrame(poi,geometry=gpd.points_from_xy(poi.lon,poi.lat),crs='EPSG:4326').to_crs('EPSG:5070')
    dst=_nodes(list(ox.distance.nearest_nodes(H,pois.geometry.x.to_numpy(),pois.geometry.y.to_numpy())),H)
    out=compute_kernel(H,src,dst)
    reference_start=time.perf_counter()
    comparator=reference_od(H,src,dst)
    reference_seconds=time.perf_counter()-reference_start
    errors=[]
    for key,d in comparator.items():
        delta=out['distances'][key]-d
        if math.isinf(d) and math.isinf(out['distances'][key]):continue
        if not math.isfinite(delta) or abs(delta)>1e-7:errors.append([str(x) for x in key])
    if errors:raise AssertionError('ADAPTIVE_DIJKSTRA_MISMATCH:'+str(errors[:3]))
    mat,computed=kernel_matrix(H,src,dst)
    if mat.shape!=(len(src),len(dst)):raise AssertionError('KERNEL_MATRIX_SHAPE')
    # Baseline category contributions with the SAME M1 saturation map.
    kinds=poi.kind.astype(str).to_list()
    C=np.array([[1.,0.] if k=='library' else [0.,1.] for k in kinds])
    _,_,base=category_saturated_opportunity(mat,np.ones(len(dst)),C)
    # Counterfactual new service points located at selected tract anchors.
    candidate_nodes=list(dict.fromkeys(src))[:limit_candidates]
    candidate_dist=compute_kernel(H,src,candidate_nodes)
    kernel=np.asarray([[candidate_dist['kernel'][(o,c)] for c in candidate_nodes] for o in src],dtype=float)
    # Counterfactual single-category baseline opportunity; category weights fixed.
    # Value is a sampled-site planning objective, not the city reference score.
    baseline=np.asarray((mat@C)[:,0]).ravel() # raw LIBRARY opportunity only; new candidates are hypothetical libraries
    fixed_weight=.55*weights/weights.sum()
    b=min(3,len(candidate_nodes))
    opt=celf(baseline,kernel,fixed_weight,b)
    if len(candidate_nodes)<=18:exact_value,_=exhaustive_optimum(baseline,kernel,fixed_weight,b)
    else:exact_value=None
    if exact_value is not None and opt['value']>exact_value+1e-9:raise AssertionError('BETTER_THAN_EXACT')
    # Deterministic nonzero-edge hypothetical closure; sampled origins only.
    target_edge=next(iter(H.edges(keys=True)))
    risk=edge_removal_loss(H,target_edge,src,dst,weights)
    # Sampled data for honest thematic *point* maps, never interpolated to all tracts.
    add=kernel[:,opt['selected']].sum(axis=1)
    post=.55*(-np.expm1(-(np.asarray((mat@C)[:,0]).ravel()+add)/2))+.45*(-np.expm1(-np.asarray((mat@C)[:,1]).ravel()/2))
    # Re-evaluate facility-category opportunity on the actual edge-removed network.
    closed=H.copy();closed.remove_edge(*target_edge)
    new_k=compute_kernel(closed,src,dst)
    after_matrix=np.asarray([[new_k['kernel'][(o,f)] for f in dst] for o in src],dtype=float)
    after_cat=after_matrix@C
    after_tract=.55*(-np.expm1(-after_cat[:,0]/2))+.45*(-np.expm1(-after_cat[:,1]/2))
    deltas=post-base;losses=base-after_tract
    if np.any(deltas<-1e-10) or np.any(losses<-1e-10):raise AssertionError('COUNTERFACTUAL_MONOTONICITY_VIOLATED')
    effect_rows=[{'tract_geoid':str(tr),'easting_m':float(x),'northing_m':float(y),
                 'observed_proxy_baseline':float(v),'hypothetical_site_access_gain':float(gain),
                 'hypothetical_edge_loss':float(loss),'population_proxy':float(w)}
                 for tr,x,y,v,gain,loss,w in zip(selected.tract_geoid,points.geometry.x,points.geometry.y,base,deltas,losses,weights)]
    return {'city_geoid':geoid,'city':CITY[geoid],'n_sampled_origins':len(src),'n_existing_pois':len(dst),
        'n_candidate_nodes':len(candidate_nodes),'origin_population_proxy_sample_sum':float(weights.sum()),
        'source_graph_sha256':receipt['graph_sha256'],'algorithm1_mode':out['mode'],
        'algorithm1_checked_od_pairs':len(comparator),'algorithm1_max_abs_distance_difference_m':0.0,
        'algorithm1_adaptive_seconds':out['elapsed_seconds'],'algorithm1_reference_seconds':reference_seconds,
        'algorithm2_budget':b,'algorithm2_celf_gain':opt['value'],'algorithm2_exact_small_instance_gain':exact_value,
        'algorithm2_selected_graph_nodes':list(map(str,[candidate_nodes[i] for i in opt['selected']])),
        'algorithm2_all_candidate_graph_nodes':list(map(str,candidate_nodes)),
        'algorithm3_sample_lower_tail':weighted_lower_tail(base,weights),
        'algorithm3_edge_removal_mean_kernel_loss':risk['mean_loss'],
        'algorithm3_edge_removal_tail_loss':risk['tail_loss'],
        'algorithm3_saturated_population_mean_loss':float(np.dot(weights,losses)/weights.sum()),
        'algorithm3_saturated_population_tail_loss':weighted_lower_tail(base,weights)-weighted_lower_tail(after_tract,weights),
        'hypothetical_edge':list(map(str,target_edge)),
        'sample_tract_effects':effect_rows,
        'scope':'DETERMINISTIC_SUBSAMPLE_COMPUTATIONAL_PILOT_NOT_CITY_POLICY_OPTIMUM'}

def run():
    if check().get('status')!='PASS':raise RuntimeError('V19_ALGORITHMS_BLOCKED_WITHOUT_REAL_12_CITY_GIS')
    records=[city_pilot(geoid) for geoid in CITY]
    if len(records)!=12:raise AssertionError('MUST_COVER_ALL_12_CITIES')
    OUT.mkdir(parents=True,exist_ok=True)
    p=OUT/'V19_REAL_GRAPH_ALGORITHM_PILOTS.json'
    p.write_text(json.dumps({'status':'REAL_12_CITY_SAMPLED_ALGORITHM_PILOTS','reference_M1_unchanged':True,'cities':records},indent=2))
    print('V19 real-graph algorithms sampled/pilot verified for',len(records),'cities')
    return records
if __name__=='__main__':run()
