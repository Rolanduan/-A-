#!/usr/bin/env python3
"""Source-linked discussion chapters for ALL 24 thematic GIS figure IDs.
Never invent findings: describe observed layer, mathematical interpretation,
source SHA and limits. Final science review must fill specific numeric findings.
"""
from pathlib import Path
import csv,json,collections
from acquire_osm_walk import ROOT,CITY
from fetch_verified import sha256_file
BASE=ROOT/'research/V19_GIS_FIGURE_DISCUSSION_PROGRAM.csv'
OUT=ROOT/'figures/v19_complete_gis_atlas'

def inventory(require_real=True):
    if not BASE.is_file():raise FileNotFoundError('V19_GIS_DISCUSSION_PROGRAM_MISSING')
    with BASE.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
    ids={r['figure_id'] for r in rows}
    if {r['figure_family'] for r in rows}!={'A','B','C','D','E','F'} or len(ids)!=24 or len(rows)!=24:
        raise ValueError('GIS_FAMILY_COVERAGE_INCOMPLETE')
    source=ROOT/'figures/v19_multicity_gis/V19_12_CITY_MAP_EVIDENCE_MANIFEST.json'
    if not require_real:return rows,[],[]
    if not source.is_file():raise FileNotFoundError('REAL_12_CITY_MAP_MANIFEST_REQUIRED')
    cities=json.loads(source.read_text()).get('cities',[])
    if len(cities)!=12 or {str(z['city_geoid']) for z in cities}!=set(CITY):raise ValueError('GIS_CITY_MANIFEST_INCOMPLETE')
    for c in cities:
        p=ROOT/c['pdf']
        if not p.is_file() or sha256_file(p)!=c['pdf_sha256']:raise ValueError('GIS_CITY_PDF_SHA_MISMATCH')
    f=OUT/'V19_ALL_GIS_FIGURES_MANIFEST.json'
    if not f.is_file():raise FileNotFoundError('FULL_24_GIS_FIGURE_ATLAS_MISSING')
    d=json.loads(f.read_text());figures=d.get('figures',[])
    if d.get('status')!='SOURCE_BACKED_FULL_GIS_ATLAS_PRODUCED' or {x['figure_id'] for x in figures}!=ids:
        raise ValueError('FULL_GIS_FIGURE_ATLAS_INVALID')
    counts=collections.Counter(x['figure_id'] for x in figures)
    for ID in ids:
        if counts[ID]!=(1 if ID.startswith('GIS-F') else 12):raise ValueError('GIS_ATLAS_NOT_12_CITY:'+ID)
    for x in figures:
        p=ROOT/x['pdf']
        if not p.is_file() or sha256_file(p)!=x['pdf_sha256']:raise ValueError('GIS_ATLAS_PDF_SHA_MISMATCH:'+str(p))
    return rows,cities,figures

def run():
    rows,cities,figures=inventory(require_real=True)
    OUT.mkdir(parents=True,exist_ok=True)
    indexed=collections.defaultdict(list)
    for f in figures:indexed[f['figure_id']].append(f)
    notes=['# V19 complete GIS atlas — figure-specific scientific discussions','',
           'Discussion status: source-linked methods and limitations are documented. Quantitative interpretation of each city map requires manual scientific review of the rendered plots and accompanying data; no invented city-specific pattern is inserted.','']
    for row in rows:
        ID=row['figure_id'];figs=indexed[ID]
        notes.extend(['## '+ID+' — '+row['title'],'',
            '**Research question:** '+row['discussion_focus'],'',
            '**Interpretation supported by these source-linked layers:** '+row['claim_supported'],'',
            '**Mathematical linkage:** '+row['linked_equations']+'; manuscript '+row['linked_sections'], '',
            '**What must not be claimed:** '+row['required_cautions'],'',
            '**Actual produced GIS PDFs, geographic coverage and SHA256:**'])
        for f in figs:
            label=f.get('city_geoid','ALL_12_CITIES')
            notes.append('- `'+label+'`: `'+f['pdf']+'` — SHA256 `'+f['pdf_sha256']+'`'+
                ('; OSM graph SHA256 `'+f['graph_source_sha256']+'`' if 'graph_source_sha256' in f else ''))
        notes.extend(['','**Scientific discussion contract:** Compare the mapped spatial pattern against the reference city aggregate and the actual route/eligibility assumptions. Report any disconnected components, out-of-boundary sources, representative-origin biases or low-population visual artifacts; quantify the effect using the published tract and OD tables rather than interpreting colors alone. Counterfactual marks are hypothetical and never become observed city improvements.',''])
    target=OUT/'V19_GIS_FIGURE_DISCUSSIONS.md';target.write_text('\n'.join(notes),encoding='utf-8')
    manifest={'status':'SOURCE_LINKED_GIS_DISCUSSIONS_FOR_ALL_24_FIGURE_IDS','city_geoids':sorted(CITY),
        'registered_map_discussions':len(rows),'source_map_pdf_count':len(figures),
        'discussion_sha256':sha256_file(target),
        'full_atlas_manifest_sha256':sha256_file(OUT/'V19_ALL_GIS_FIGURES_MANIFEST.json'),
        'city_map_manifest_sha256':sha256_file(ROOT/'figures/v19_multicity_gis/V19_12_CITY_MAP_EVIDENCE_MANIFEST.json'),
        'limitations':'Source-linked narrative; manual scientific interpretation of each map remains necessary.'}
    (OUT/'V19_GIS_ATLAS_DISCUSSION_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
    return manifest
if __name__=='__main__':print(run())
