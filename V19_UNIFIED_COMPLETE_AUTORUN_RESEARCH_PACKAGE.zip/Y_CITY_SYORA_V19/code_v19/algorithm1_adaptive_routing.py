"""V19 Algorithm I: exact adaptive directed truncated Dijkstra.
Select between forward origin searches and reverse facility searches without
changing the ordered origin->facility OD distances. No dense APSP is formed.
"""
from __future__ import annotations
import math,time
import networkx as nx


def _pair_distance(G, sources, targets, cutoff, weight):
    """Return ordered distances with math.inf for unreachable pairs."""
    for n in set(sources)|set(targets):
        if n not in G: raise ValueError('NODE_NOT_IN_GRAPH')
    if not sources or not targets: raise ValueError('EMPTY_OD_SET')
    if cutoff<=0: raise ValueError('INVALID_CUTOFF')
    if any(not math.isfinite(float(d.get(weight,float('nan')))) or float(d[weight])<0
           for *_,d in G.edges(data=True)):
        raise ValueError('NONFINITE_OR_NEGATIVE_EDGE_COST')
    if len(set(sources))<=len(set(targets)):
        mode='forward'; network=G; seeds=set(sources)
    else:
        mode='reverse';network=G.reverse(copy=False) if G.is_directed() else G;seeds=set(targets)
    lookups={s:nx.single_source_dijkstra_path_length(network,s,cutoff=cutoff,weight=weight) for s in seeds}
    distances={(o,f): (lookups[o].get(f,math.inf) if mode=='forward' else lookups[f].get(o,math.inf))
               for o in sources for f in targets}
    return mode,distances

def compute_kernel(G,origin_nodes,facility_nodes,cutoff_seconds=1200.,tau_seconds=720.,weight='walking_seconds'):
    if tau_seconds<=0:raise ValueError('INVALID_DECAY')
    start=time.perf_counter()
    mode,dist=_pair_distance(G,origin_nodes,facility_nodes,cutoff_seconds,weight)
    K={(o,f):(math.exp(-d/tau_seconds) if d<=cutoff_seconds else 0.) for (o,f),d in dist.items()}
    return {'mode':mode,'distances':dist,'kernel':K,'elapsed_seconds':time.perf_counter()-start,
            'n_sources':len(set(origin_nodes)) if mode=='forward' else len(set(facility_nodes))}

def reference_od(G,origins,facilities,cutoff_seconds=1200.,weight='walking_seconds'):
    cache={o:nx.single_source_dijkstra_path_length(G,o,cutoff=cutoff_seconds,weight=weight) for o in set(origins)}
    return {(o,f):cache[o].get(f,math.inf) for o in origins for f in facilities}

if __name__=='__main__':
    raise SystemExit('Library module; run code_v19/run_v19.py instead')
