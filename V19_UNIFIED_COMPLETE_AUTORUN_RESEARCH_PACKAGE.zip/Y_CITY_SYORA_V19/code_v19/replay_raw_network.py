#!/usr/bin/env python3
"""Independent network-level audit from *raw OSM original bytes*.

Overpass mode parses raw OSM node/way JSON without using OSMnx's parser.
Geofabrik mode re-parses the original PBF with Pyrosm, rather than loading GraphML.
Compares independently rebuilt OSM node-to-node shortest paths to actual OD records.
Passing this audit does not validate park entrances or teen access rights.
"""
from __future__ import annotations
import argparse,csv,gzip,hashlib,json,math,statistics
from pathlib import Path
import networkx as nx
from acquire_osm_walk import ROOT,CITY,digest

WALK_HIGHWAYS={'footway','pedestrian','path','steps','living_street','residential','service',
    'tertiary','secondary','primary','unclassified','track','cycleway','road','trunk_link',
    'secondary_link','tertiary_link','primary_link'}
BLOCKED={'no','private','military','customers','permit'}


def haversine_m(lat1,lon1,lat2,lon2):
    a,b,c,d=map(math.radians,(lat1,lon1,lat2,lon2))
    h=math.sin((a-c)/2)**2+math.cos(a)*math.cos(c)*math.sin((b-d)/2)**2
    return 12742000*math.asin(min(1,math.sqrt(h)))


def walk_allowed(tags):
    foot=str(tags.get('foot','')).lower();access=str(tags.get('access','')).lower()
    highway=str(tags.get('highway','')).lower()
    if foot in BLOCKED:return False
    if access in BLOCKED and foot not in {'yes','designated','permissive'}:return False
    if foot in {'yes','designated','permissive'}:return True
    return highway in WALK_HIGHWAYS and highway not in {'construction','proposed','motorway','trunk'}


def parse_overpass_original(raw_json_bytes):
    try:d=json.loads(raw_json_bytes)
    except Exception as exc:raise ValueError('RAW_OVERPASS_JSON_INVALID') from exc
    if not isinstance(d,dict) or not isinstance(d.get('elements'),list):raise ValueError('NOT_OSM_ELEMENTS_JSON')
    return d['elements']


def independent_graph_from_overpass_files(paths):
    nodes={};ways={}
    for p in paths:
        data=Path(p).read_bytes()
        for e in parse_overpass_original(data):
            kind=e.get('type')
            if kind=='node' and 'lat' in e and 'lon' in e:
                nodes[int(e['id'])]=(float(e['lat']),float(e['lon']))
            elif kind=='way' and walk_allowed(e.get('tags') or {}):
                ways[int(e['id'])]=e
    if len(nodes)<100 or len(ways)<30:raise ValueError('RAW_OVERPASS_NETWORK_TOO_SMALL_OR_CACHE_MISSING')
    g=nx.DiGraph()
    for way in ways.values():
        tags=way.get('tags') or {};sequence=way.get('nodes') or []
        mode=str(tags.get('oneway:foot',tags.get('oneway',''))).lower()
        if str(tags.get('foot','')).lower() in ('yes','designated','permissive') and 'oneway:foot' not in tags:mode='no'
        for a,b in zip(sequence,sequence[1:]):
            a,b=int(a),int(b)
            if a not in nodes or b not in nodes or a==b:continue
            la,lo=nodes[a];lb,lblo=nodes[b]
            length=haversine_m(la,lo,lb,lblo)
            if not math.isfinite(length) or length<=0:continue
            for u,v in ((a,b),) if mode in ('yes','true','1') else (((b,a),) if mode in ('-1',) else ((a,b),(b,a))):
                old=g.get_edge_data(u,v,{}).get('length',float('inf'))
                if length<old:g.add_edge(u,v,length=length)
    if g.number_of_edges()<100:raise ValueError('INDEPENDENT_RAW_GRAPH_NO_USABLE_ROUTES')
    return g


def read_od_pairs(path,cap=20000):
    with gzip.open(path,'rt',newline='',encoding='utf-8') as f:
        rows=list(csv.DictReader(f))
    if not rows:raise ValueError('NO_TRUE_OD_PAIRS')
    # Deterministic spread across data; avoid choosing only easy first tracts.
    k=max(1,len(rows)//min(len(rows),cap))
    return rows[::k][:cap]


def check_node_to_node(graph,pairs,max_pairs=60):
    rows=[r for r in pairs if 'origin_node_id' in r and 'facility_node_id' in r]
    if len(rows)<max_pairs:raise ValueError('INSUFFICIENT_ORIGIN_DESTINATION_NODE_IDENTIFIERS')
    step=max(1,len(rows)//max_pairs)
    errors=[];missing=[];tested=0
    for r in rows[::step][:max_pairs]:
        a,b=int(r['origin_node_id']),int(r['facility_node_id'])
        if a not in graph or b not in graph:
            missing.append((a,b));continue
        try: actual=nx.shortest_path_length(graph,a,b,weight='length')
        except nx.NetworkXNoPath:missing.append((a,b));continue
        claimed=float(r['route_dist_m'])
        errors.append(abs(actual-claimed)/max(100,claimed));tested+=1
    if tested<max(10,int(max_pairs*.6)):raise ValueError('RAW_GRAPH_REPLAY_INSUFFICIENT_NODE_COVERAGE')
    relative_q90=sorted(errors)[int(.9*(len(errors)-1))]
    # Independent raw OSM parser and OSMnx differ in some pedestrian restriction handling.
    if relative_q90>.20:raise ValueError('RAW_GRAPH_VERSUS_PRIMARY_NETWORK_DISAGREEMENT_90P='+str(relative_q90))
    return {'tested':tested,'node_missing_or_disconnected':len(missing),'relative_q90':relative_q90,
            'relative_median':statistics.median(errors),'status':'PASS_RAW_OSM_BYTES_REBUILT_TO_ROUTES'}


def run_city(geoid):
    rpath=ROOT/f'data/processed/v19_network/receipt_{geoid}.json'
    if not rpath.is_file():raise FileNotFoundError('NO_REAL_NETWORK_RECEIPT_'+geoid)
    receipt=json.loads(rpath.read_text())
    pairfile=ROOT/f'data/processed/v19_network/walk_pairs_{geoid}.csv.gz'
    if digest(pairfile)!=receipt['od_pairs_sha256']:raise ValueError('OD_SHA_CHANGED')
    pairs=read_od_pairs(pairfile)
    if receipt.get('source_kind')=='RAW_GEOFABRIK_PBF':
        p=Path(receipt['source_pbf_path']);
        if not p.is_absolute():p=ROOT/p
        if not p.exists() or digest(p)!=receipt['source_pbf_sha256']:raise ValueError('RAW_PBF_SHA_MISMATCH')
        from pyrosm import OSM
        from network_geofabrik import STATES
        import geopandas as gpd
        place=ROOT/f'data/raw_official/v19/tl_2024_{geoid[:2]}_place.zip'
        polygons=gpd.read_file('zip://'+str(place))
        geom=polygons[polygons.PLACEFP.astype(str)==geoid[2:]].to_crs('EPSG:5070').geometry.iloc[0]
        bbox=gpd.GeoSeries([geom.buffer(4000)],crs='EPSG:5070').to_crs('EPSG:4326').iloc[0].bounds
        pbf=OSM(str(p),bounding_box=list(bbox),keep_metadata=False)
        nodes,edges=pbf.get_network(network_type='walking',nodes=True)
        graph=pbf.to_graph(nodes,edges,graph_type='networkx',simplify=False)
        if isinstance(graph,nx.MultiGraph):graph=nx.DiGraph(graph)
        elif not graph.is_directed():graph=graph.to_directed()
    else:
        entries=receipt.get('original_overpass_cached_response_files',[])
        paths=[]
        for e in entries:
            path=ROOT/e['path']
            if not path.is_file() or digest(path)!=e['sha256']:raise ValueError('RAW_OVERPASS_SHA_MISMATCH')
            # OSMnx cache may also include geocoding/features, which are skipped only after validation.
            try:
                elements=parse_overpass_original(path.read_bytes())
                if any(item.get('type')=='way' and 'highway' in (item.get('tags') or {}) for item in elements):paths.append(path)
            except ValueError:continue
        if not paths:raise ValueError('NO_REUSABLE_ORIGINAL_OVERPASS_WALK_ELEMENTS')
        graph=independent_graph_from_overpass_files(paths)
    result=check_node_to_node(graph,pairs)
    result.update(city_geoid=geoid,raw_source_kind=receipt.get('source_kind','RAW_OVERPASS_CACHED_JSON'),
                  raw_graph_nodes=graph.number_of_nodes(),raw_graph_edges=graph.number_of_edges(),
                  graph_sha256=receipt['graph_sha256'],od_sha256=receipt['od_pairs_sha256'])
    return result


def run():
    output={}
    for geoid in CITY:output[geoid]=run_city(geoid)
    result={'status':'PASS_12_CITIES_RAW_SOURCE_NETWORK_REPLAY','cities':output,'verified_count':len(output)}
    target=ROOT/'qa_v19/independent_raw_osm_replay.json';target.parent.mkdir(exist_ok=True,parents=True)
    target.write_text(json.dumps(result,indent=2))
    print(result['status']);return result

if __name__=='__main__':run()
