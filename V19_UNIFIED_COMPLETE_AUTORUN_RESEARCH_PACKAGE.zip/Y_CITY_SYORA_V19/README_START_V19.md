# V19 unified executable engineering package

**One master:** `V19_MASTER.md` (all scientific spine, algorithms, figures, GIS discussion and Draw.io contracts).

**One entry:** `python code_v19/run_v19.py --stage all --network auto`.

Run from extracted `Y_CITY_SYORA_V19` directory. Install `code_v19/requirements_v19.txt` and a compatible Python/GDAL/PROJ/OSMnx/TeX environment. Dry run: `python code_v19/run_v19.py --dry-run`. Offline regression: `PYTHONPATH=code_v19 python -m pytest -q tests_v19`. On Windows PowerShell set `$env:PYTHONPATH='code_v19'` for tests; the main entry handles PYTHONPATH internally.

**V19 components:** all V18 scientific engine scripts migrated into V19 namespace; Algorithm I adaptive directed truncated Dijkstra; Algorithm II monotone submodular CELF sampled counterfactual; Algorithm III lower-tail weighted mean and edge-removal rerouting; matrix consistency contract; 8 editable Draw.io diagrams with PDF/SVG exports; GIS atlas discussion engine; source-backed publication gates. Algorithm II/III do not change the 12-city reference M1 ranking.

**Data status:** This source archive has NO actual 28 original Census files or 12 original OSM networks; it does not include real city rankings, derived GIS atlases or complete empirical PDF. Missing data fail closed. GIS thematic maps and detailed interpretations are generated only after real source QA. The Draw.io files are conceptual architecture diagrams and are genuinely editable, not fabricated maps.

**Legal/scientific warning:** The paper styling contract does not imply COMAP registration. Human scientific review is required. Existing source-derived OSM maps need correct OpenStreetMap attribution and uncertainty statements.
