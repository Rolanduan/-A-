"""Reference registry tests; rows are metadata fixtures, not research sources."""
from pathlib import Path
import sys
import pandas as pd
import pytest
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'code_v19'))
import build_empirical_gis_paper as builder


def test_empty_additional_reference_registry_is_valid(tmp_path, monkeypatch):
    (tmp_path / 'sources').mkdir()
    pd.DataFrame(columns=['author_or_publisher','title','year','source_type','publication_or_dataset','doi_or_url','used_in_manuscript','access_date','cited_in_sections']).to_csv(tmp_path / 'sources/additional_references.csv', index=False)
    monkeypatch.setattr(builder, 'ROOT', tmp_path)
    assert builder._load_additional_references() == []


def test_unused_reference_row_is_not_added(tmp_path, monkeypatch):
    (tmp_path / 'sources').mkdir()
    pd.DataFrame([{'author_or_publisher':'','title':'not actually used','year':'','source_type':'newspaper_or_magazine','doi_or_url':'','used_in_manuscript':'false'}]).to_csv(tmp_path / 'sources/additional_references.csv', index=False)
    monkeypatch.setattr(builder, 'ROOT', tmp_path)
    assert builder._load_additional_references() == []


def test_used_reference_requires_complete_provenance(tmp_path, monkeypatch):
    (tmp_path / 'sources').mkdir()
    pd.DataFrame([{'author_or_publisher':'Example publisher','title':'','year':'2026','source_type':'newspaper_or_magazine','doi_or_url':'https://example.org/article','used_in_manuscript':'true'}]).to_csv(tmp_path / 'sources/additional_references.csv', index=False)
    monkeypatch.setattr(builder, 'ROOT', tmp_path)
    with pytest.raises(ValueError, match='USED_REFERENCE_HAS_BLANK_FIELD:title'):
        builder._load_additional_references()


def test_used_reference_accepts_complete_record(tmp_path, monkeypatch):
    (tmp_path / 'sources').mkdir()
    pd.DataFrame([{'author_or_publisher':'Example publisher','title':'A real source title','year':'2026','source_type':'newspaper_or_magazine','publication_or_dataset':'Example Magazine','doi_or_url':'https://example.org/article','used_in_manuscript':'true','access_date':'2026-11-07','cited_in_sections':'Analysis'}]).to_csv(tmp_path / 'sources/additional_references.csv', index=False)
    monkeypatch.setattr(builder, 'ROOT', tmp_path)
    rows = builder._load_additional_references()
    assert len(rows) == 1
    refs, _ = builder._reference_items([], [], rows)
    assert 'Example publisher' in refs and 'Example Magazine' in refs and 'https://example.org/article' in refs
