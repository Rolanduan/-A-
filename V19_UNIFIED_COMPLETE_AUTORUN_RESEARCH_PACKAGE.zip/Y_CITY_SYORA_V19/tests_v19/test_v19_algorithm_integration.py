"""Numerical invariants and run wiring. In-memory graphs are TEST FIXTURES, not empirical city observations."""
from pathlib import Path
import sys,math,json
import numpy as np
import networkx as nx
import pytest
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'code_v19'))
from algorithm1_adaptive_routing import compute_kernel,reference_od
from algorithm2_submodular import objective,celf,exhaustive_optimum
from algorithm3_tail_resilience import weighted_lower_tail,edge_removal_loss
from graph_matrix_contract import incidence_matrix,kernel_matrix,category_saturated_opportunity

def graph():
    G=nx.DiGraph()
    for u,v,d in [('a','b',10),('b','c',20),('c','d',30),('a','d',150),('b','a',100),('d','a',1000)]:
        G.add_edge(u,v,walking_seconds=d,length=d)
    return G

def test_adaptive_forward_directed():
    g=graph();r=compute_kernel(g,['a'],['b','c','d'],cutoff_seconds=100)
    assert r['mode']=='forward';assert r['distances'][('a','d')]==60
    assert r['distances']==reference_od(g,['a'],['b','c','d'],100)

def test_adaptive_reverse_directed():
    g=graph();r=compute_kernel(g,['a','b','c'],['d'],cutoff_seconds=100)
    assert r['mode']=='reverse';assert r['distances'][('b','d')]==50
    assert r['distances']==reference_od(g,['a','b','c'],['d'],100)

def test_backward_edge_not_symmetric():
    g=graph();r=compute_kernel(g,['a','d'],['a','d'],cutoff_seconds=100)
    assert r['distances'][('a','d')]==60
    assert math.isinf(r['distances'][('d','a')])

def test_cutoff_zero_kernel():
    g=graph();r=compute_kernel(g,['a'],['d'],cutoff_seconds=30)
    assert r['kernel'][('a','d')]==0

def test_strict_edge_nonnegative():
    g=graph();g['a']['b']['walking_seconds']=-1
    with pytest.raises(ValueError):compute_kernel(g,['a'],['d'])

def test_invalid_node_blocked():
    with pytest.raises(ValueError):compute_kernel(graph(),['no'],['d'])

def test_incidence_signed_and_shape():
    b,vs,es=incidence_matrix(graph());assert b.shape==(4,6)
    assert np.allclose(b.sum(axis=0),0)

def test_kernel_matrix_matches_reference():
    g=graph();m,r=kernel_matrix(g,['a','b'],['c','d'],cutoff_seconds=80)
    assert m.shape==(2,2)
    assert abs(m[0,0]-math.exp(-30/720))<1e-12

def test_category_saturation_exact_m1():
    from scipy.sparse import csr_matrix
    K=csr_matrix([[.3,.2],[.1,.6]])
    a,u,v=category_saturated_opportunity(K,[1,1],[[1,0],[0,1]])
    assert v[0]==pytest.approx(.55*(1-math.exp(-.3/2))+.45*(1-math.exp(-.2/2)))
    assert not np.allclose(v,K@np.array([.55,.45]))

def test_eligibility_zero_excludes_unknown():
    from scipy.sparse import csr_matrix
    K=csr_matrix([[.8,.4]])
    a,u,v=category_saturated_opportunity(K,[1,0],[[1,0],[0,1]])
    assert a[0,1]==0

def test_wrong_matrix_mask():
    from scipy.sparse import csr_matrix
    with pytest.raises(ValueError):category_saturated_opportunity(csr_matrix([[1.]]),[1,0],[[1,0],[0,1]])

def test_empty_selection_zero():
    assert objective([],np.array([.2,.4]),np.ones((2,3)),np.array([.5,.5]))==0

def test_monotonic_greedy():
    base=np.array([0.,.1,.2]);k=np.array([[.5,.1,.6],[.2,.4,.1],[.3,.2,.3]])
    w=np.array([.2,.5,.3]);s=celf(base,k,w,3)
    assert len(s['selected'])==3
    assert all(z['marginal_gain']>=-1e-11 for z in s['history'])
    assert s['value']==pytest.approx(objective([0,1,2],base,k,w))

def test_celf_equals_exact_single():
    b=[0.,.5];k=np.array([[.5,.1,.9],[.1,.6,.4]])
    v=celf(b,k,[1.,1.],1)['value'];opt,_=exhaustive_optimum(b,k,[1.,1.],1)
    assert v==pytest.approx(opt)

def test_celf_approximation_bound():
    b=[0.,.3,.2];k=np.array([[.5,.1,.9,.4],[.1,.6,.4,.3],[.2,.1,.2,.8]])
    s=celf(b,k,[1.,1.,1.],2)
    opt,_=exhaustive_optimum(b,k,[1.,1.,1.],2)
    assert s['value']>=(1-1/math.e)*opt-1e-12

def test_diminishing_returns():
    b=[0.];k=np.array([[1.,1.]])
    assert objective([0],b,k,[1.])>=objective([0,1],b,k,[1.])-objective([1],b,k,[1.])

def test_negative_contrib_rejected():
    with pytest.raises(ValueError):objective([0],[0],np.array([[-1.]]),[1])

def test_budget_rejected():
    with pytest.raises(ValueError):celf([0],np.array([[.5]]),[1],2)

def test_tail_fractional_boundary():
    assert weighted_lower_tail([0.,.5,1.],[2,2,6],.3)==pytest.approx(1/6)

def test_tail_uniform():
    assert weighted_lower_tail([.5,.5],[1,100],.1)==pytest.approx(.5)

def test_invalid_tail_fraction():
    with pytest.raises(ValueError):weighted_lower_tail([0],[1],0)

def test_edge_removal_requires_reroute():
    G=graph();res=edge_removal_loss(G,('b','c'),['a'],['d'],[1.],cutoff_seconds=200)
    assert res['mean_loss']>0
    assert res['tail_loss']>0

def test_edge_removal_nonexist():
    with pytest.raises(ValueError):edge_removal_loss(graph(),('none','c'),['a'],['d'],[1])

def test_no_fictional_real_gis_outputs():
    assert not (R/'results_v19_gis/FINAL_12_CITY_REAL_GIS_RANKING.csv').exists()
    assert not (R/'data/raw_official/v19/acs_2024_5y_B01001.dat').exists()

def test_master_only_v19_and_existing_all_maps():
    assert (R/'V19_MASTER.md').is_file()
    assert (R/'code_v19/render_city_atlas_v19.py').is_file()
    assert (R/'code_v19/render_atlas.py').is_file()
    assert (R/'code_v19/render_real_gis_figures.py').is_file()
    assert not (R/'V18_MASTER.md').exists()

def test_runner_contains_new_phases():
    import run_v19
    phases=run_v19.STAGES
    assert phases.index('score')<phases.index('algorithm_pilots')<phases.index('paper')
    assert phases.index('multicity_maps')<phases.index('gis_discussions')<phases.index('release')
    assert phases.index('drawio_gate')<phases.index('release')

def test_drawio_sources_and_exports():
    from v19_drawio_gate import check
    assert check()==8

def test_legacy_source_count_preserved():
    source=R/'code_v19'
    assert len(list(source.glob('*.py')))>=len(list((R/'tests_v19').glob('*.py')))
