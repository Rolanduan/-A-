"""All test data generated below are synthetic, short-lived TEST FIXTURES; never city evidence."""
from pathlib import Path
import sys,zipfile,json,csv,hashlib,pytest,os
P=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(P/'code_v19'),str(P/'code_v19')]
from fetch_verified import sha256_file,validate_bytes,verify_receipt
from acquire_census import CITIES,STATES,TABLES,specs,scan_acs,export_city_subset
from uncertainty_envelopes import ratio_envelope,acs_utility_bounds
import importlib.util
_spec=importlib.util.spec_from_file_location('v19_score_isolated',P/'code_v19/score_official_gis.py')
_v19_score=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_v19_score)
u_acscity=_v19_score.u_acscity

def test_exact_number_of_original_inputs():
    assert len(STATES)==12 and len(CITIES)==12 and len(TABLES)==4
    assert len(specs())==28

def test_all_census_hosts_and_formats_are_real_schema():
    for s in specs():
        assert s['url'].startswith('https://www2.census.gov/')
        assert s['filename'].endswith(('.dat','.zip'))

def test_sha256_reality(tmp_path):
    p=tmp_path/'file.bin';p.write_bytes(b'known original bytes')
    assert sha256_file(p)==hashlib.sha256(b'known original bytes').hexdigest()

def test_truncated_zip_rejected(tmp_path):
    p=tmp_path/'broken.zip';p.write_bytes(b'abc'*300)
    with pytest.raises(ValueError):validate_bytes(p,'zip')

def test_tiger_zip_with_real_shapefile_name(tmp_path):
    p=tmp_path/'tiger.zip'
    with zipfile.ZipFile(p,'w') as f:
        f.writestr('sample.shp',b'shapefilebytes'*30)
    assert validate_bytes(p,'zip')['sha256']==sha256_file(p)

def test_html_rejected_even_large(tmp_path):
    p=tmp_path/'html.dat';p.write_bytes(b'<html>not a census table</html>'*30)
    with pytest.raises(ValueError):validate_bytes(p,'dat')

def test_real_acs_header_valid_in_temp_fixture(tmp_path):
    p=tmp_path/'local.dat';p.write_bytes(b'GEO_ID|B01001_E006|B01001_E030\n'+b'1400000US12345678901|5|4\n'*20)
    assert validate_bytes(p,'dat')['bytes']>200

def test_receipt_hash_protection(tmp_path):
    p=tmp_path/'x';p.write_bytes(b'one')
    r={'status':'DOWNLOADED_ORIGINAL_WITH_SHA','sha256':sha256_file(p),'origin_verification':'DIRECT_TLS_SOURCE'}
    assert verify_receipt(p,r)
    p.write_bytes(b'two')
    with pytest.raises(ValueError,match='SHA256_MISMATCH'):verify_receipt(p,r)

def test_manual_import_not_official_proof(tmp_path):
    p=tmp_path/'x';p.write_bytes(b'abc')
    r={'status':'DOWNLOADED_ORIGINAL_WITH_SHA','sha256':sha256_file(p),'origin_verification':'UNVERIFIED_MANUAL_OR_PREEXISTING_FILE'}
    with pytest.raises(ValueError,match='ORIGIN_NOT_VERIFIED'):verify_receipt(p,r)

def test_b28002_004_broadband_not_002_in_v19_score():
    r={'B25070':{'B25070_E001':100,'B25070_E007':10,'B25070_E008':15,'B25070_E009':12,'B25070_E010':8,'B25070_E011':10},
       'B17001':{'B17001_E001':1000,'B17001_E002':100},
       'B28002':{'B28002_E001':200,'B28002_E002':190,'B28002_E004':160}}
    score1,_=u_acscity(r)
    r['B28002']['B28002_E002']=197
    score2,_=u_acscity(r)
    assert score1==score2
    r['B28002']['B28002_E004']=180
    score3,_=u_acscity(r)
    assert score3>score2

def test_conservative_ratio_envelope():
    low,high=ratio_envelope(30,3,100,4)
    assert 0<=low<.3<high<=1

def test_bad_moe_denominator_refused():
    with pytest.raises(ValueError):ratio_envelope(5,2,10,12)

def test_acs_moe_propagation_conservative():
    def row(table,vals):
        r={}
        for i,val in vals.items():r[f'{table}_E{i:03d}']=val;r[f'{table}_M{i:03d}']=min(val/15,2)
        return r
    r={'B25070':row('B25070',{1:100,7:10,8:10,9:10,10:10,11:5}),
       'B17001':row('B17001',{1:500,2:50}),
       'B28002':row('B28002',{1:200,4:180})}
    l,h,_=acs_utility_bounds(r)
    assert 0<=l<h<=100

def test_official_source_files_are_never_embedded_in_test_fixtures():
    # Do not assert data is absent: rerunning V19 after a successful download is required.
    assert not any(p.suffix in ('.dat','.pbf') for p in (P/'tests_v19').rglob('*') if p.is_file())

def test_final_ranking_requires_verifiable_inputs():
    # The existence or absence of output during a later real run is not itself a bug.
    from score_official_gis import TABLES
    assert len(TABLES)==4
