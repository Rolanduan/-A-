"""V19 tests use entirely synthetic fixtures for algorithm verification ONLY.
They are not empirical 2026 HiMCM A evidence, not released rankings.
"""
import json,sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code_v19'))
from evidence_frontier import build_evidence_horizon,verification_queue
from preference_paths import (frozen_reference_weights,policy_archetypes,rank_scores,
                              exact_leader_segments,calculate_preference_paths,MULTIPLIERS)


def synthetic_horizon_input():
    city=['Austin','Boston','Chicago'];geoid=['4805000','2507000','1714000']
    b=pd.DataFrame(dict(city=city,city_geoid=geoid,M0_acs_citywide=[70.,60.,50.],M1_real_walk_20m=[75.,65.,55.]))
    m=pd.DataFrame(dict(city_geoid=geoid,acs_m0_low_moe_stress=[68.,59.,48.],acs_m0_high_moe_stress=[72.,61.,52.]))
    a=pd.DataFrame(dict(city_geoid=geoid,M_network_Q10_reference=[75.,65.,55.],M_network_unknown_upper=[76.,69.,58.]))
    return b,m,a


def test_horizon_preserves_reference():
    d=build_evidence_horizon(*synthetic_horizon_input())
    assert len(d)==3
    np.testing.assert_allclose(d.score_outer_lower,[73.8,64.4,53.8])
    np.testing.assert_allclose(d.score_outer_upper,[77.2,69.6,59.2])
    assert (d.score_outer_lower<=d.M1_real_walk_20m).all()
    assert (d.score_outer_upper>=d.M1_real_walk_20m).all()


def test_horizon_necessary_exclusions():
    d=build_evidence_horizon(*synthetic_horizon_input())
    assert d.loc[d.city=='Austin','certified_best_if_outer_bounds_valid'].iloc[0]
    assert d.loc[d.city=='Boston','eliminated_by_verified_outer_bound'].iloc[0]
    assert d.loc[d.city=='Chicago','eliminated_by_verified_outer_bound'].iloc[0]


def test_horizon_tolerates_join_order():
    b,m,a=synthetic_horizon_input()
    d=build_evidence_horizon(b,m.sample(frac=1,random_state=3),a.iloc[::-1])
    assert list(d.city)==list(b.city)


def test_horizon_rejects_missing_data():
    b,m,a=synthetic_horizon_input()
    with pytest.raises(ValueError,match='HETEROGENEOUS'):build_evidence_horizon(b,m.iloc[:2],a)


def test_horizon_rejects_fake_reference_ablation():
    b,m,a=synthetic_horizon_input();a.loc[0,'M_network_Q10_reference']=82
    with pytest.raises(ValueError,match='ABLATION'):build_evidence_horizon(b,m,a)


def test_horizon_rejects_upside_below_reference():
    b,m,a=synthetic_horizon_input();a.loc[0,'M_network_unknown_upper']=74
    with pytest.raises(ValueError,match='UNKNOWN_ACCESS_UPPER'):build_evidence_horizon(b,m,a)


def test_horizon_rejects_acs_outside_moe():
    b,m,a=synthetic_horizon_input();m.loc[0,'acs_m0_high_moe_stress']=65
    with pytest.raises(ValueError,match='ACS_MOE'):build_evidence_horizon(b,m,a)


def test_queue_does_not_impute_missing_probability():
    d=build_evidence_horizon(*synthetic_horizon_input());q=verification_queue(d)
    assert len(q)==6
    assert all('success probability' in x for x in q.interpretation)
    assert not q.isna().any().any()


def test_queue_conditional_exclusion_is_not_claim_of_observation():
    q=verification_queue(build_evidence_horizon(*synthetic_horizon_input()))
    assert q.human_validation_action.str.contains('Audit|Confirm').all()
    assert q.potential_upper_bound_reduction.min()>=0


def test_weight_reference_from_existing_score_contract():
    sc=json.loads((ROOT/'config_v19/reference_model_v19.json').read_text())['scoring']
    w=frozen_reference_weights(sc)
    np.testing.assert_allclose(w,[.21,.21,.18,.165,.135,.10],rtol=0,atol=1e-10)


def test_weights_leave_reference_unchanged():
    b=np.array([.21,.21,.18,.165,.135,.1]);p=policy_archetypes(b)
    assert set(p)==set(MULTIPLIERS)
    np.testing.assert_allclose(p['reference'],b)
    for key,w in p.items():
        assert abs(w.sum()-1)<1e-10
        assert min(w)>0


def test_weights_reject_unusable_base():
    with pytest.raises(ValueError):policy_archetypes(np.array([.5,.5,0,0,0,0]))


def test_exact_preference_crossing_is_not_grid_estimate():
    # utility A=(1,0), B=(0,1); baseline favors A, terminal favors B.
    data=np.array([[1.,0.],[0.,1.]])
    s=exact_leader_segments(['A','B'],data,np.array([.9,.1]),np.array([.1,.9]))
    assert len(s)==2 and s[0]['winner']=='A' and s[1]['winner']=='B'
    assert s[0]['t_to']==pytest.approx(.5,abs=1e-12)
    assert s[1]['t_from']==pytest.approx(.5,abs=1e-12)


def test_non_crossing_preference_path():
    u=np.array([[.8,.8],[.3,.3]])
    s=exact_leader_segments(['A','B'],u,np.array([.9,.1]),np.array([.1,.9]))
    assert len(s)==1 and s[0]['winner']=='A'


def test_path_requires_distinct_names():
    u=np.array([[.2,.2],[.3,.3]])
    with pytest.raises(ValueError,match='BAD_SCORING'):rank_scores(['A','A'],u,np.array([.5,.5]))


def test_ref_rank_is_stable_with_city_name_tie_breaker():
    u=np.array([[.5,.5],[.5,.5]])
    r=rank_scores(['Z','A'],u,np.array([.5,.5]))
    assert {x[0]:x[2] for x in r}=={'Z':2,'A':1}


def test_six_component_observed_reference_must_match_original():
    sc=json.loads((ROOT/'config_v19/reference_model_v19.json').read_text())['scoring']
    w=frozen_reference_weights(sc)
    vals=np.tile(np.array([.4,.5,.6,.7,.8,.9]),(12,1)).astype(float)
    df=pd.DataFrame(vals,columns=['rent_burden','poverty','broadband','library_mean_normalized','park_mean_normalized','opportunity_weighted_Q10'])
    df['city']=[f'C{i}' for i in range(12)]
    df['M1_real_walk_20m']=100*(vals@w)
    a,t,r,_=calculate_preference_paths(df,sc)
    assert len(a)==48 and len(r)==12 and len(t)>=3
    df.loc[0,'M1_real_walk_20m']+=10
    with pytest.raises(ValueError,match='UTILITY_DECOMPOSITION'):calculate_preference_paths(df,sc)


def test_v19_integrations_have_immutable_main_model():
    text=(ROOT/'code_v19/run_v19.py').read_text()
    assert text.index("'uncertainty','evidence_frontier'")<text.index("'preference_paths'")
    assert text.index("'decision_gate'")<text.index("'paper'")
    manuscript=(ROOT/'code_v19/build_empirical_gis_paper.py').read_text()
    assert r'\input{V19_DECISION_EVIDENCE_ADDITIONS.tex}' in manuscript
    assert 'validate_v19_decision' in manuscript
    assert 'scoring' in (ROOT/'config_v19/reference_model_v19.json').read_text()


def test_no_competing_team_code_import_or_remote_dependency():
    source='\n'.join(p.read_text(encoding='utf-8') for p in (ROOT/'code_v19').glob('*.py'))
    assert 'TypeThe0ry' not in source
    assert 'task4_v121' not in source
    assert 'task4_v122' not in source
    assert 'TOPSIS' in (ROOT/'code_v19/preference_paths.py').read_text() # explicitly says no TOPSIS


def test_no_release_without_actual_data():
    from decision_release import validate
    d=validate()
    assert d['status']=='BLOCKED_FOR_V19_GIS_PAPER'
    assert len(d['issues'])>=1
