# V19 — SINGLE AUTHORITY MASTER / 唯一主控

**Integration status:** the Algorithm I adaptive directional solver is a source-backed verification and pilot computation after the unchanged frozen M1 score engine; it does **not** replace the original baseline's Dijkstra routing in `acquire_osm_walk.py`. Algorithm II and III are sampled auxiliary analyses. Twenty-four GIS thematic IDs are implemented as a data-gated separate atlas with 12-city panels; thematic point maps derived from sampled pilots must remain labelled as sampled.


All source code is under `code_v19/` and the **only** command is `python code_v19/run_v19.py --stage all --network auto`. The 12-city study and frozen M0/M1 reference remain unchanged. Algorithm II/III outputs are supplementary sampled pilots until full datasets and source evidence permit stronger conclusions. All original GIS drawing functions remain. Full city thematic maps are gated by real data.


## V19 Algorithm and publication upgrades (governing addenda)


**Mathematical correction:** the M1 graph kernel is aggregated by facility category and transformed **within each category** using `1-exp(-A/2)` before `.55/.45` combination. A naive `K @ eligibility @ categories @ weights` replaces the model with a different linear score and is forbidden. Incidence Laplacians do not compute directed shortest paths by matrix inversion. The directed shortest path operator uses min-plus algebra conceptually and truncated Dijkstra computationally.



---

## INTEGRATED SOURCE: V19_DECISION_LOCK.md

# V19 决策锁定记录｜算法主线与设计边界

状态：**DESIGN DECISIONS FROZEN / 实证和正式 V19 代码尚未执行**。记录来源：用户在本次会话明确同意上轮三层算法建议。

## 固定且不允许视觉改版偷换的主干

- 对象：预设美国12城；2024 ACS 五年期真实原始 DAT、TIGER 2024、真实 OSM 步行网络原始响应或 Geofabrik PBF；保留来源 SHA256 与同版本审计。
- 研究逻辑：系统边界 → 真实观测 → M0 家庭条件基线 → 同设施集库存/直线/路网/资格/公平控制消融 → M1 冻结参考榜单 → M2 稳健性与决策边界 → 论文。
- **Algorithm I:** Adaptive Directed Truncated Dijkstra（根据居住起点/设施数量选择正向与逆向截断精确最短路；必须验证有向性、同一OD结果与性能提升，不是伪称新算法）。
- **Algorithm II:** GIS-grounded Monotone Submodular Facility Opportunity Optimization + Lazy Greedy/CELF（固定非负人口权重与饱和机会效用时验证次模性，等成本 cardinality 约束下才使用 1-1/e 经典近似界；候选增设点是反事实方案，绝不覆盖 M1 现状榜单）。
- **Algorithm III:** Population-weighted Lower-Tail CVaR + Edge-Removal Network Resilience（尾部人口加权均值是 Q10 的补充；关闭边后重算真实最短路，不能假称城市真实动态反馈）。
- 原 V18 Pareto/LP、证据外包络、定向核验与偏好路径保留作支持性决策分析，不改变参考模型权重、得分和城市样本。
- 图谱坚持 GIS真实坐标、算法真实中间量、数学对象一致和论文一源多输出，禁止假数据、手工编辑图上结果、用装饰性3D冒充实测地形。

## V19 视觉锁定决策

1. 正式解答：**英文、一份PDF、Summary第1页、正文+目录+新闻稿+参考文献不超过25页、12pt或更大可读文字**；AI使用报告按COMAP规则附在25页解答之后。此为“COMAP样式约束”，项目当前是独立研究，不得生成假 Team Control Number。
2. 设计语言：理性、克制、高清晰度；论文采用浅底色、科学图像采用矢量 PDF/SVG，必要栅格地图分辨率300–600dpi，黑白打印可辨识。
3. 唯一重要视觉主线：系统边界与证据链 → Algorithm I 测量 → M0/M1 控制实验 → 十二城现状结论 → Algorithm II 改善 → Algorithm III 公平/脆弱性 → 稳健决策。
4. 主文选择约7幅“必须解释”的图、3个关键表、3份算法/证明块；其余置于独立研究图谱，不以巨幅不可读多联图硬塞25页。
5. 论文与图均从同一个冻结 release_id / rank CSV / source hash manifest / run config 渲染，并对 PDF 每页渲染做可读性与重叠审计。
6. 本指令是**设计决议**，不声明真正的HiMCM评委参与，不替代真实科学同行评审与实际数据计算。

## 来源
- COMAP 2026: https://contest.comap.org/highschool/contests/himcm/instructions.html
- COMAP 2026 A题: https://contest.comap.org/highschool/contests/himcm/2026_Problems/2026_HiMCMProblem_A.pdf
- COMAP 官方 Summary TeX: https://www.contest.comap.com/highschool/contests/himcm/flyers/HiMCM-MidMCM_Summary.tex
- Consortium Judges Commentary: https://www.contest.comap.com/highschool/contests/himcm/flyers/Cons_HiMCM.pdf
- Nature Figure Guide: https://research-figure-guide.nature.com/figures/preparing-figures-our-specifications/
- PLOS Figure Requirements: https://journals.plos.org/plosbiology/s/figures


---

## INTEGRATED SOURCE: V19_EXPERT_COUNCIL_VISUAL_DIRECTIVE.md

# V19 学术视觉与排版专家模拟廷议 — 正式决议（设计版）

> **事实边界**：本文件是基于 HiMCM 2026 官方网页、官方题目、公开评审评论摘要、Nature/PLOS 图形规范与 V18 实际源码的多学科**模拟评审**，没有真实 HiMCM 评委受邀或发表意见。V19 的论文与图谱仍须真实数据运行；本文件只制定实施合同和验收标准。

## 0. 已记录的用户决定／不改主线

算法主线：I 自适应有向截断 Dijkstra；II 基于真实 OD 的固定权重次模设施机会优化（Greedy/CELF）；III 人口加权尾部 CVaR 与关键边扰动。保持十二城 Census/TIGER/OSM 数据源、系统论框架、参考 M0/M1 排名以及原有结果的严谨门禁。具体数学假设、近似界的适用条件见 `V19_DECISION_LOCK.md`。

## 1. 资料级别与直接发现

**官方硬约束（不是编辑建议）：** 单份英文 PDF；第1页 Summary；解答、目录、参考文献、新闻稿等合计不超过25页；正文可读字至少12 pt；每页顶部 Team Control Number + 页码且不得出现个人、学校身份；AI使用报告附在25页后不计入25页。A题要求至少十城、显著模型修订、1–2页非技术新闻稿。对于本未报名独立项目，绝不能填造 Team Control Number 或声称可以官方提交。官方建议的正文分节是 Optional Layout，不可混同于硬格式。

**官方评审关注点：** 建模过程、分析、数学方法、清楚且有证据的结论；公开的 Consortium HiMCM Judges’ Commentary 强调图、表与文本平衡，并把说明放在相关图表附近。

**V18 实际源码发现（审计而非猜测）：** `render_atlas.py` 设置默认字号10 pt，局部包含6–8 pt 标签及250dpi栅格导出；`decision_atlas.py`和地图函数也有9–11 pt；`build_empirical_gis_paper.py` 的 `\documentclass[12pt,letterpaper]{article}` 与 `.78in` 边距基本合理，旧版曾依赖 `F17_GIS_*` 图名，现在统一源代码与论文均迁移到 F19； 原有15×7双图若直接嵌进Letter纸将严重缩小注释。因此 V19 要解决的是最终打印尺寸的可读性，不是单纯把 PNG 改成 PDF。

## 2. 十席模拟审稿与综合裁决

| 专业角色（模拟） | 关键质询 | V19 采用的决议 |
|---|---|---|
| HiMCM 主审 | 读完Summary能否立即知道前提、模型修订、12城结论、未验证之处？ | Summary一页，最后生成；最多1个主结果视觉；来源与条件必须在页内。 |
| HiMCM 数学审 | 三个算法各自解决什么，在哪些假设下成立？ | 每个算法必须有现实问题、变量/单位、伪代码、关键定理/性质与同数据benchmark。 |
| 运筹专家 | 设施选择是不是偷偷替代了12城排名？ | 优化是干预反事实子研究；仅比较固定预算/候选集，禁止重置M1。 |
| GIS专家 | 几何地图能否反映合法步行路线与入口不确定？ | 导出实际图边/设施/tract；GIS地图必须图例、CRS、比例、时间和准入注释。 |
| 统计专家 | MOE外包络是否被错误写成联合95%置信区间？ | 统计抽样/设施资格/偏好情景分层绘制，禁止混并概率术语。 |
| 科学图形设计师 | 图是否存在字小、图例重复、无实义多面板？ | 每图单一主张；常规主文仅约7张高价值图，其余输出atlas。 |
| 学术排版专家 | A4/Letter转码、字体、公式、参考文献会不会违例？ | 12pt实际PDF跨度审查、25页实际分页审查、页眉/摘要模板审查。 |
| 无障碍评审 | 黑白或色盲是否仍可区分？ | 同时使用线型、标记、图例与直接标签；不得仅靠红绿对比。 |
| 复现专家 | 图和文字是否确实来自同一批源文件？ | figure ID ↔ claim ID ↔ equation ID ↔ result CSV ↔ raw SHA ↔ run ID，全部自动关联。 |
| 非技术编辑 | 非技术新闻稿会不会成为换词版Summary？ | 独立写作2页以内，面向家长/城市公共议题，同一数据事实但另一种叙事。 |

## 3. 学术视觉系统（Design Tokens）

| 元素 | 推荐规范 | 原因 |
|---|---|---|
| 论文纸张 | US Letter 8.5×11英寸；边距0.78–0.85英寸，全文统一 | 与V18已有LaTeX兼容；保证图幅预测可靠 |
| 主文本 | 12pt，合理行距1.15–1.22倍；数学字体与正文配套 | 遵守COMAP可读性要求；无需故意填满25页 |
| 一级标题 | 15–16pt、醒目但不夸张；二级13–14pt | 建立层级而非海报化 |
| 图轴/标注/图例 | 优选最终PDF打印尺寸下12pt；确实困难时拆分图，而非缩至6pt | 保守满足主办方至少12pt约束 |
| 图注 | 12pt正文宽度；顺序：结论型标题—数据/单位—不确定性—来源 | 图应与正文独立可解释 |
| 表格 | booktabs；数值按小数点或单位对齐；不用竖线与浓色背景 | 减少视觉噪声与误读 |
| 数学 | amsmath＋cleveref；每个核心公式附变量与单位；只编号被引用的式子 | 数学不是装饰 |
| 主色 | 深海军蓝 `#183B56` | 主参考模型／可信证据 |
| 机会色 | 冷青 `#087E8B` | 真实可达机会 |
| 干预色 | 沙金 `#C18C39` | Algorithm II反事实资源配置 |
| 负效应色 | 暖赭 `#AD5D58` | 风险、限制、未知资格（须配线型） |
| 中性色 | `#5D6B75` / `#E9EEF0` / 白 | 文字、网格、浅底；不使用大片彩底 |
| 数据源编码 | 实心=观测；空心=代理；虚线=情景；斜线/问号=未知 | 灰度或色盲场景也能识别 |

**对Nature/PLOS规范的正确借鉴：** 学它们的视觉精确、有限色彩、清楚轴单位、矢量源文件和来源说明，而不复制期刊常见的5–7pt缩印字号到COMAP报告。Nature指出应避免多余彩色与装饰，PLOS建议在栅格交付时使用300–600dpi；但具体图中文字字号需服从本报告更严格的竞赛约束。

## 4. 统一视觉语法（不是三篇独立论文）

**层级逻辑图：**

`Urban boundary [TIGER PLACE] → Tract youth proxy [ACS B01001] → Facility eligibility [OSM/IMLS] → Road access [Algorithm I] → Current M0/M1 city score → Intervention [Algorithm II] → Tail/edge robustness [Algorithm III] → Verified decision + uncertainty [LP/Evidence]`。

凡箭头都标变量或文件名，如`n_g`, `OD_{gj}`, `A_{gk}`, `a_g`, `M1(c)`, `∆F(K)`, `L_0.1`, `R_e`。用一个小角标区分：**Observed / Inferred / Normative / Counterfactual**。以虚线和旁注画研究流程中的“诊断→改模型→验算”；不得将其说成测得的真实城市社会反馈。

**Algorithm I 的视觉结构：** 先展示真实有向路网、源点与设施节点；再显示正向与反向截断Dijkstra，同一OD值一致；最后给出速度与内存基准。须标注数据规模、速度阈值和重现条件。

**Algorithm II 的视觉结构：** 图一显示候选点与受益区域；图二显示K=0...Kmax的实际边际改善和近似比较；图三显示固定候选集下 Greedy、Random、Count、Euclidean 在相同预算下的结果，不直接声称现实可建。

**Algorithm III 的视觉结构：** 人口加权机会分布分位曲线说明 Q10 与 CVaR区别；关键边扰动前后的图像要求重路由而不是扣分；同一图中不要把统计抽样误差与断边情景合并成“置信带”。

## 5. V19 图谱计划

见机器可读 `V19_FIGURE_PROGRAM.csv`，列出16张图的唯一ID、来源、所需实算、主论文/atlas去向和科学误用禁令。**主PDF仅保留约7幅：F19-01/03/04/05/06/07/08**，辅助图以证据图谱提供，非强制塞入25页。图号是规划标识；没有真实数据的数值图不能预先生成或假填。

最终的专题图谱建议四组：

- A 证据与空间数据：来源谱系、人口/城市地理、12城同尺度地图；
- B 模型与算法：Dijkstra精确解/基准、控制消融、次模收益/定理对照；
- C 决策与系统论：12城主榜、LP/Pareto、不确定性、跨界性与韧性；
- D 科研复现：模型输入—输出注册表、地图坐标元数据、图表来源 SHA256。

对“10/20/30分钟服务区”，严格用道路图可达子图与合法构造的服务区域几何表达，不允许把欧氏圆或凸包直接称为精确真实网络服务圈。绘制多个城市时颜色尺度、分位法、边界口径、图例、字体一律统一。

## 6. 图表选型细则

| 要表达的判断 | 首选可视化 | 不推荐的做法 |
|---|---|---|
| 城市第一与完整排序 | 12城水平点/条图，标数值和单位 | 饼图、雷达图当主结果、只有热图没榜单 |
| 重大修订引起的名次变化 | M0→同设施库存→直线→路网→公平 slopegraph，另分维解释 | 只有M0 vs M1却归因于道路 |
| 地理机会和服务覆盖 | 正确 CRS 的路网、tract、设施与真实OD路径 | 装饰性城市地图、未经验证入口、虚假等时圈 |
| 贪心设施优化 | K-收益曲线、与确切小实例对照、同预算基线 | 只给出看似理想的选址点、没有真实收益 |
| 最差群体机会 | 人口加权尾部曲线、Q10/CVaR比较 | 把Q10画成统计置信下界 |
| 不确定性 | ACS MOE与资格上界分开；端点类型文字清晰 | 一个大误差棒同时当“95%置信” |
| 系统稳定与脆弱 | 删边后的机会损失/路由变化分布 | 用一张动态箭头图谎称长期稳定性 |
| 数据论据可追溯 | 有输入文件/字段/公式/运行ID的因果审查图 | 仅有箭头方框、无变量单位和事实接口 |

## 7. 25页内容预算——“纸张先行，图像后做”

详见 `V19_25PAGE_EDITORIAL_PLAN.csv`，提供每一物理页的工作预算：P1摘要、P2目录、P3–21正文、P22–23新闻稿、P24–25参考文献（最后一页为伸缩预留）。如新闻稿实际仅1页或参考文献一页，空余页可转给关键推导，但不能超25页。目录和参考文献都计入25页，AI报告附后不计。不要在第25页突然附大量不可读伪代码/链接；完整代码和数据保存在独立可复现包中，不作为正式提交附录。

## 8. 实施工具栈与已有源码修复

- 数据和线路：Census/TIGER、GeoPandas、OSMnx/NetworkX、SciPy；原始源与缓存都存 SHA。
- 静态科研图：Matplotlib 输出 `PDF + SVG + PNG`；避免透明叠图过多、PDF裁剪框过紧和对文档整体缩放。
- 概念系统图：Graphviz `dot` 生成初稿后矢量精修；只允许用于无地理尺度的流程图；节点展示变量/单位。
- 数学和排版：`article[12pt,letterpaper]` + `amsmath`, `mathtools`, `booktabs`, `tabularx`, `siunitx`, `cleveref`, `microtype`, `hyperref`, `fancyhdr`, `graphicx`；使用原版 COMAP Summary TeX 的真实下载副本，修改团队字段时若未注册用独立研究标识且显式标记不合官方提交要求。
- 自动排版：`latexmk` 编译；`pymupdf`/`pypdf` 检查页码与文字，200dpi逐页渲染；逐页检查文字尺寸、图表溢出、公式截断、超页、孤行和英文字符问题。
- 发现的具体遗留应修复：`render_atlas.py` 中6–8pt文字，250dpi；`render_city_atlas_v18.py` 15×7图在 Letter 上缩印；`build_empirical_gis_paper.py` 中仍引用旧版 F17 图名；图表与正文使用不同字体与图注习惯。V19规范要求统一命名 `F19-*`、统一图表尺寸并在最终嵌入尺寸下重新绘图，而非简单放大旧位图。

## 9. 论文硬门禁和人工评审

参见 `V19_VISUAL_QUALITY_GATES.csv`。最低要求：

1. **源**：每张图的原始输入链接、文件SHA256、软件版本、准确单位和算法条件可追溯。
2. **格式**：一份英文PDF，Summary第一物理页，页码，控制号规则（正式参赛才填写真正控制号），正文/TOC/新闻稿/参考文献在25页内；AI报告在后。
3. **可读性**：PDF最终打印尺寸≥12pt文本；独立渲染所有页；若嵌入图导致小字先拆图，不能以“期刊允许小字”为由绕过比赛规则。
4. **数学**：Algorithm I/II/III 均要有原数据验证、公式单位、条件证明、失败例和对应图；CELF 近似界只在满足约束条件时成立。
5. **审稿**：检查每个结果段落是否出现 `Claim → Evidence → Computation → Possible counterexample → Scope` 五要素；新闻稿的数字与 Summary/正文完全一致。
6. **负结果**：若没有原始官方数据与12城路网，所有真实排名图、GPS地图、性能提升和正式PDF均保持 BLOCKED，不准用假结果实现视觉预览。

## 10. 高优先级建议及反对意见决议

| 争议 | 反对意见 | 最终建议 |
|---|---|---|
| 是否做Nature式图形 | 期刊小字号/精细多面板易违反HiMCM12pt与25页 | **保留学术美学，拒绝期刊的小字密图** |
| 是否把12城全部地图放主文 | 空间比较全面但大概率缩小到不可读 | **主文一城机制地图＋多城对照小表，完整地图独立atlas** |
| 是否做3D城市效果图 | 视觉抓人但可能无法证实高程/步行阻抗 | **仅在真实DEM与坡度算法存在时做可证据化3D，绝不占核心主文版面** |
| 是否展示三算法全部伪代码 | 有助数学辨识但版面有限 | **I、II主文短伪码，III主文公式＋验证，完整流程在独立复现包** |
| 是否用复杂桑基图表示所有数据源 | 适合汇报但遮挡具体字段 | **用带变量/单位的分层DAG，原始字段表辅助** |
| 是否追求全25页满页 | 内容拥挤并降低可信度 | **不必填满25页；只保留支持结论的证据与论证** |

## 11. 建议交付结构

```text
Y_CITY_SYORA_V19/
  V19_MASTER.md                     # 将本决议并入唯一主控，不丢V18模型合同
  V19_DECISION_LOCK.md             # 用户锁定的三算法与主模型边界
  design_v19/
    editorial_design_tokens.json
    figure_program.csv
    page_budget.csv
    visual_quality_gates.csv
    algorithm_figure_contracts.csv
  code_v19/
    render_scientific_atlas.py
    render_algorithm_figures.py
    render_city_maps.py
    paper_layout_and_font_audit.py
    build_empirical_paper.py
  figures_v19/                     # 真实运行后产生，不预填数值图
  paper_v19/                       # 真实运行后产出TeX/PDF与附录
  qa_v19/                          # 字体/页数/图源/单位/截图/发布证明
```

该结构是下一轮可执行升级的目标目录，并不表示这些源代码在本“廷议”交付中已经全部实现。

## 12. 可靠参考来源（链接已核对）

- COMAP 2026 Instructions: https://contest.comap.org/highschool/contests/himcm/instructions.html
- 2026 HiMCM A original PDF: https://contest.comap.org/highschool/contests/himcm/2026_Problems/2026_HiMCMProblem_A.pdf
- COMAP generic Summary LaTeX: https://www.contest.comap.com/highschool/contests/himcm/flyers/HiMCM-MidMCM_Summary.tex
- COMAP Consortium HiMCM Judges Commentary: https://www.contest.comap.com/highschool/contests/himcm/flyers/Cons_HiMCM.pdf
- Nature scientific graphics: https://www.nature.com/nature/for-authors/formatting-guide
- Nature research figure guide: https://research-figure-guide.nature.com/figures/preparing-figures-our-specifications/
- PLOS figure requirements: https://journals.plos.org/plosbiology/s/figures
- NetworkX+OSMnx geospatial example: https://networkx.org/documentation/latest/auto_examples/geospatial/plot_osmnx.html

**最终审查状态：** `V19_VISUAL_CONSENSUS_DOCUMENTED / ALGORITHM_DESIGN_LOCKED / CODE_MIGRATION_PENDING / EMPIRICAL_DATA_PENDING`。未声称实际评委出席、真实数据实算、正式论文编译或获得评审认可。


---

## INTEGRATED SOURCE: V19_GIS_ALL_MAPS_PRESERVATION_LOCK.md

# V19 — GIS ALL MAPS PRESERVATION LOCK

Status: design/implementation requirement, NOT evidence of actual full-city GIS outputs.

## Non-negotiable decision

The paper's ~7 selected primary figures are a **subset** for editorial clarity only. This limitation shall never delete, skip, overwrite, or drop any GIS figure, map producer, city, layer, route-corridor threshold, or full-resolution source output from the separate research atlas. The V18 source ZIP remains immutable. Migrate code under a new V19 namespace by copying and regression testing, not editing original V18 assets in place.

## Existing V18 GIS source code verified in the archived ZIP

- `code_v19/render_city_atlas_v19.py`: `run()` iterates through all 12 frozen city GEOIDs; each city's combined figure includes (A) 20-minute tract opportunity choropleth, and (B) directed walking-network 10/20/30-minute **corridors** and mapped library/park candidates. Each is saved as an individual PDF and SVG, and all twelve entries go into the evidence manifest. These are network-edge buffered display corridors; they are NOT proven full-space isochrone polygons or verified facility gates.
- `code_v19/render_atlas.py`: retains all 10 source-backed V18 analytic figure generators, including Austin network case, cross-boundary exposure, 12-city ranking, equity comparison, and systems provenance.
- `code_v19/render_real_gis_figures.py`: retains ranking, rank bump and Austin walking-network output code; historical F17 figure filenames were migrated to F19 source and manuscript references.
- `code_v19/decision_atlas.py`: retains the separate evidence and preference plots.

## Full V19 GIS catalog (regardless of paper page budget)

1. Twelve individual city-level tract opportunity choropleths on actual Census TIGER geographies, consistent scales and legends.
2. Twelve individual city pedestrian-network maps with actual OSM topology, public/unknown/restricted POIs clearly distinguished and authentic OD anchors.
3. 10/20/30-minute actual-network **reachable edge corridor** maps, with separate native cutoff semantics; never mislabel as a verified pedestrian isochrone polygon.
4. Cross-municipal-boundary service access and city-edge flow maps using actual routed pairs.
5. Twelve-city comparative small multiples with frozen colormap scales and common units.
6. Map of 15–17 ACS tract youth-proxy allocations and city/tract overlay, identifying area interpolation.
7. Street-network algorithm I: selected real directed path and accessibility computation diagnostics.
8. Facility-placement algorithm II: observed candidate location layer and clearly labeled hypothetical, optimizer-selected locations (not approved real construction sites).
9. Tail-fairness and road-break algorithm III: low-opportunity tracts and hypothetical closure-risk maps; not observed closures.
10. City-scale evidence/provenance maps and source-to-claim figure records.
11. Existing 10-frame V18 scientific atlas graphics and 2 decision-evidence figures stay available; title renaming cannot drop an output.
12. Original real data maps must be editable where feasible as PDF/SVG, with noneditable source or any additional cartographic GeoPackage / GeoJSON published as reproducibility source when allowed.

## Preservation and acceptance gates

- The V19 figure registry shall distinguish MAIN_PAPER, COMPLETE_ATLAS, ALGORITHM_ATLAS, and GIS_DATA_LAYER, with no figure omitted solely due to main-paper length.
- All 12 frozen GEOIDs must appear in the final map manifest. Save per-city PDF + SVG with city GEOID and run_id. Include input graph and Census geometry SHA256.
- Exports must pass legibility at the actual target page size, no clipped labels, matched legend and scale, readable source timestamp and network speed.
- GIS graphics require 28 original Census files, real OSM source bytes, 12 valid pedestrian graphs and actual derived tract/route metrics. If missing, the manifest status is `BLOCKED_FOR_REAL_CITY_GIS_ATLAS`, not success.
- The complete atlas is a separate deliverable from the 25-page paper, not squeezed into the main PDF. All legacy V18 drawing functions remain accessible or demonstrably replaced with equivalent-or-better tested implementations.
- Regression check: enumerate V18 existing figure-generation functions/files before migration, compare with V19 registry, fail if a GIS category or one of the 12 cities disappears.

## Frozen city set

Austin (4805000), Boston (2507000), Chicago (1714000), Denver (0820000), Madison (5548000), Minneapolis (2743000), Pittsburgh (4261000), Portland (4159000), Raleigh (3755000), San Diego (0666000), Seattle (5363000), Atlanta (1304000).

This is an additional V19 GIS design contract. It does not claim that GIS outputs have already been rendered or independently validated.


---

## INTEGRATED SOURCE: V19.1_GIS_ATLAS_AND_DISCUSSION_CONTRACT.md

# V19.1 — GIS Atlas and Figure Discussion Contract

Status: **UPGRADE PATCH / additive only**. This file upgrades V19. It does not delete, replace, or invalidate any existing V19 GIS design files.

## 1. Non-negotiable preservation rule

All GIS maps planned in V19 shall be preserved in one of three layers:

1. **Main-paper GIS figures**: a small editorial subset used inside the 25-page paper.
2. **Complete GIS atlas**: the full set of city-level and algorithm-level GIS maps.
3. **GIS data-layer outputs**: per-city, per-threshold, and per-algorithm exports used for audit and reproducibility.

No GIS class may be dropped merely because the main paper has page pressure.

## 2. Required GIS figure families

The final V19 implementation shall preserve or generate the following GIS figure families:

### Family A — spatial frame and population basis
- **GIS-A1**: US locator map of the 12 frozen cities.
- **GIS-A2**: city PLACE boundary + TRACT overlay map.
- **GIS-A3**: youth-proxy (ACS 15–17) tract choropleth.
- **GIS-A4**: spatial interpolation / geographic matching diagnostic map.

### Family B — current opportunity geography
- **GIS-B1**: real OSM pedestrian graph over audited city.
- **GIS-B2**: eligible / restricted / unknown facilities map.
- **GIS-B3**: routed access map (selected OD paths).
- **GIS-B4**: tract opportunity choropleth under the frozen M1 access kernel.
- **GIS-B5**: 10/20/30-minute real-network reach corridor maps.
- **GIS-B6**: cross-boundary access and city-edge permeability map.

### Family C — algorithm I / graph-routing GIS outputs
- **GIS-C1**: directed graph with source/target node snapping diagnostics.
- **GIS-C2**: route mismatch / directionality diagnostic map.
- **GIS-C3**: truncated-search coverage subnetwork map.

### Family D — algorithm II / facility optimization GIS outputs
- **GIS-D1**: candidate facility layer.
- **GIS-D2**: selected hypothetical facility placements for a fixed K.
- **GIS-D3**: before/after tract opportunity improvement map.
- **GIS-D4**: underserved-tract improvement emphasis map.

### Family E — algorithm III / fairness and resilience GIS outputs
- **GIS-E1**: lowest-opportunity tracts highlight map.
- **GIS-E2**: tail-fairness geographic concentration map.
- **GIS-E3**: edge-removal impact / vulnerable corridor map.
- **GIS-E4**: opportunity loss after hypothetical closure map.

### Family F — comparative multi-city atlas
- **GIS-F1**: 12-city small multiples of tract opportunity.
- **GIS-F2**: 12-city small multiples of pedestrian network density / routing frame.
- **GIS-F3**: 12-city small multiples for one fixed threshold (e.g., 20-minute reach corridor or normalized opportunity layer).

## 3. Detailed discussion requirement

Every GIS figure must have a matching discussion block. Each block shall include:

1. **What the map shows** — exact geometry layers and variables.
2. **Why it matters** — the scientific claim supported.
3. **How it is computed** — source files, CRS, snapping logic, thresholds, aggregation.
4. **What must not be over-interpreted** — unknown facility eligibility, age proxy, entry-point uncertainty, hypothetical interventions, etc.
5. **Link to results** — which equation / CSV / manuscript paragraph uses it.

## 4. Required discussion template (for each GIS figure)

Use the following structure in the atlas and in the manuscript discussion notes:

### [Figure ID] Title
- **Purpose:**
- **Primary data layers:**
- **Derived variables and units:**
- **Computation chain:**
- **Interpretive claim:**
- **Limitations / scientific caution:**
- **Referenced equations:**
- **Linked result files:**
- **Linked manuscript section:**

## 5. Main-paper GIS selection rule

The paper may select only a compact subset, but it must still preserve atlas completeness.

Recommended main-paper GIS subset:
- GIS-A2/A3 combined compactly
- GIS-B4 (one audited city opportunity map)
- GIS-B5 or GIS-B6 (true network access / permeability)
- GIS-D3 or GIS-D4 (optimization effect)
- GIS-E3 or GIS-E4 (resilience / vulnerability)

The rest go to the complete atlas.

## 6. Technical quality rules

Every GIS map must satisfy:
- real CRS recorded;
- north arrow and scale bar where meaningful;
- legend with units;
- frozen city GEOID in caption or filename;
- actual network source timestamp;
- no Euclidean circle mislabeled as a network isochrone;
- no unknown-access facility silently merged with public-access facility;
- no unexplained normalization.

## 7. Acceptance gate

If V19 later executes with real data, the GIS atlas is considered complete only if:
- all 12 frozen cities appear in the atlas manifest;
- each city has at least one Family A and one Family B map;
- at least one audited city has Families C, D, and E rendered;
- figure discussion records exist for every GIS figure;
- source hashes and run_id are linked.

This file is a preservation-and-discussion upgrade only. It does not claim that the real GIS maps have already been generated.


---

## INTEGRATED SOURCE: V19.1_GRAPH_THEORY_MATRIX_DERIVATIONS.md

# V19.1 — Graph-Theory Matrix Derivations for the HiMCM A Research System

Status: **additive mathematical appendix** for V19. This file upgrades V19 and does not replace the existing scalar/network formulations.

## 1. Goal

All graph-theoretic sections in V19 shall be expressible not only in path-language but also in matrix language. This appendix defines the required matrix derivations for:

1. pedestrian-network representation;
2. shortest-path and accessibility operators;
3. facility-opportunity aggregation;
4. Algorithm II optimization kernel;
5. Algorithm III vulnerability / edge-removal analysis.

## 2. Base graph representation

Let the walkable urban network be a directed weighted graph
\[
G=(V,E,w), \qquad |V|=n,\ |E|=m,
\]
where each edge \(e=(u,v)\in E\) has nonnegative impedance \(w_e\) (distance or time).

### 2.1 Adjacency matrix
Define the weighted adjacency matrix
\[
A\in \mathbb{R}_{\ge 0}^{n\times n},
\qquad
A_{uv}=
\begin{cases}
\exp(-w_{uv}/\tau), & (u,v)\in E,\\
0, & \text{otherwise.}
\end{cases}
\]
For pure graph structure discussions, an unweighted binary adjacency matrix may also be used:
\[
B_{uv}=\mathbf 1((u,v)\in E).
\]
The weighted form above is useful because it already resembles accessibility decay.

### 2.2 Incidence matrix
Let \(M\in \{-1,0,1\}^{n\times m}\) be the directed incidence matrix:
\[
M_{ve}=
\begin{cases}
-1,& \text{if edge } e \text{ leaves } v,\\
+1,& \text{if edge } e \text{ enters } v,\\
0,& \text{otherwise.}
\end{cases}
\]
If \(W_e=\operatorname{diag}(w_1,\dots,w_m)\), then the combinatorial Laplacian is
\[
L = M M^\top,
\]
and a weighted variant is
\[
L_w = M W_e^{-1} M^\top
\]
(or an alternative positive diagonal scaling depending on convention).

### 2.3 Node classes and selection matrices
Let:
- \(R\subseteq V\) be residential / tract-anchor nodes,
- \(F\subseteq V\) be facility nodes,
- \(C\subseteq V\) be candidate intervention nodes.

Define selection matrices:
\[
S_R\in\{0,1\}^{|R|\times n},\qquad S_F\in\{0,1\}^{|F|\times n},\qquad S_C\in\{0,1\}^{|C|\times n},
\]
so that, for example, \(S_R x\) extracts the components of \(x\) indexed by residential nodes.

## 3. Shortest-path matrices

### 3.1 Pairwise shortest-path matrix
Define the all-pairs shortest-path matrix
\[
D\in (\mathbb{R}_{\ge0}\cup\{\infty\})^{n\times n},
\qquad
D_{uv}=\text{length of a shortest directed walk from }u\text{ to }v.
\]
At the research-engineering level, \(D\) is not formed densely for all \(u,v\); instead, it is computed implicitly by repeated truncated Dijkstra searches. But for derivations, it is the cleanest object.

Then the residential-to-facility distance matrix is
\[
D_{RF}=S_R D S_F^\top.
\]
Likewise, residential-to-candidate and residential-to-edge-endpoint relations can be written using analogous selection matrices.

### 3.2 Thresholded reachability kernel
For time threshold \(T\) and decay scale \(\tau\), define the accessibility kernel
\[
K(T,\tau)_{ij}=\mathbf 1\bigl(D_{RF,ij}\le T\bigr)\exp\left(-\frac{D_{RF,ij}}{\tau}\right).
\]
Thus
\[
K(T,\tau)\in\mathbb{R}_{\ge0}^{|R|\times |F|}.
\]
This is the matrix form of the tract-to-facility contribution rule.

## 4. Facility eligibility matrices

Suppose facilities are partitioned into categories \(k\in\{1,\dots,K\}\) (e.g., libraries and parks).
Let \(y\in\{0,1\}^{|F|}\) indicate confirmed public eligibility; let \(u\in\{0,1\}^{|F|}\) indicate unknown eligibility.
Then the **strict-access** facility mask is
\[
Y_{\text{strict}}=\operatorname{diag}(y),
\]
whereas the **upper-envelope** mask is
\[
Y_{\text{upper}}=\operatorname{diag}(y+u).
\]
This expresses the lower and upper access envelopes without treating unknown as confirmed public access.

If category membership is encoded by a matrix
\[
C\in\{0,1\}^{|F|\times K},
\]
then category-specific accessible opportunity from residential nodes is
\[
A^{(\ell)} = K(T,\tau)Y_{\ell}C,
\qquad \ell\in\{\text{strict},\text{upper}\}.
\]
Hence \(A^{(\ell)}\in\mathbb{R}_{\ge0}^{|R|\times K}\), and each row corresponds to one residence/tract anchor.

## 5. Tract-level opportunity and population aggregation

Let \(p\in\mathbb{R}_{\ge0}^{|R|}\) be the youth-proxy population vector (e.g., 15–17 ACS-derived tract population), and let \(\Omega=\operatorname{diag}(p/\sum p)\) be the normalized population-weight matrix.

If category weights are \(\lambda\in\mathbb{R}_{\ge0}^K\), then tract-level opportunity is
\[
a^{(\ell)} = A^{(\ell)}\lambda,
\qquad a^{(\ell)}\in\mathbb{R}_{\ge0}^{|R|}.
\]
The population-weighted mean opportunity is
\[
\bar a^{(\ell)} = \mathbf 1^\top \Omega a^{(\ell)}.
\]
This is the matrix version of the average access score.

For a lower-tail fairness statistic, let \(q_{0.1}(a,p)\) be the population-weighted 10th percentile and let \(\operatorname{CVaR}_{0.1}(a,p)\) be the population-weighted average over the lowest 10% by cumulative population. These are not simple matrix multiplications, but they are well-defined functionals on \((a,p)\).

## 6. Matrix interpretation of M1 access module

The access component of the reference model may be written abstractly as
\[
\Phi^{(\ell)} = 0.75\,\bar a^{(\ell)} + 0.25\,Q_{0.1}^{(\ell)},
\]
where \(Q_{0.1}^{(\ell)}\) is the weighted lower-decile summary. If the V19 upgrade adds CVaR as an auxiliary fairness diagnostic,
\[
\Psi^{(\ell)} = \operatorname{CVaR}_{0.1}(a^{(\ell)},p)
\]
becomes a companion statistic rather than a silent replacement.

## 7. Algorithm I in matrix language

Although the exact solver is Dijkstra-based, its target object is the sparse thresholded kernel \(K(T,\tau)\). V19 should present the algorithm as computing selected rows or columns of \(D\), then applying the nonlinear map
\[
D_{RF}\mapsto K(T,\tau).
\]
The forward-truncated formulation computes rows of \(D_{RF}\) from residential origins. The reverse-truncated formulation computes columns by running truncated Dijkstra on the reverse graph. The two strategies are algebraically equivalent in the sense that they seek the same entries of \(D_{RF}\); they differ only in computational route.

## 8. Algorithm II — facility placement as a set function with matrix kernel

Let candidate facilities be indexed by \(C\). For each candidate \(c\in C\), define its contribution vector at residential nodes as
\[
k_c\in\mathbb{R}_{\ge0}^{|R|},
\qquad
(k_c)_i = \mathbf 1(D_{RC,ic}\le T)\exp(-D_{RC,ic}/\tau),
\]
possibly category-specific.

Let the baseline opportunity be \(a^0\). For a chosen set \(S\subseteq C\), define added opportunity
\[
a(S)=a^0 + \sum_{c\in S} k_c.
\]
Using a concave, increasing saturation map \(\phi\), define the total objective
\[
F(S)=\sum_{i=1}^{|R|} \omega_i\bigl[\phi(a_i(S)) - \phi(a_i^0)\bigr],
\]
where \(\omega_i\ge0\) are frozen tract weights.

### Proposition (monotone submodularity)
If:
1. \(k_c\ge0\) componentwise for every candidate \(c\),
2. \(\omega_i\ge0\), and
3. \(\phi\) is increasing and concave,
then \(F(S)\) is monotone and submodular.

### Proof sketch
For any tract \(i\), the marginal gain of adding \(c\) to set \(S\) is
\[
\Delta_c^i(S)=\omega_i\left[\phi\left(a_i^0+\sum_{s\in S}k_{s,i}+k_{c,i}\right)-\phi\left(a_i^0+\sum_{s\in S}k_{s,i}\right)\right].
\]
Because \(\phi\) is concave and \(k_{c,i}\ge0\), \(\Delta_c^i(S)\) decreases as \(S\) grows. Summing over \(i\) preserves diminishing returns, so \(F\) is submodular. Monotonicity follows from nonnegative gains.

Thus, under a cardinality constraint \(|S|\le K\), classical greedy enjoys the \((1-1/e)\) guarantee.

This is the principal matrix-compatible optimization derivation that should appear in V19.

## 9. Algorithm III — edge-removal vulnerability in matrix language

Let edge \(e\) be removed, inducing graph \(G\setminus e\) and shortest-path matrix \(D^{(-e)}\). Then the new kernel is
\[
K^{(-e)}(T,\tau).
\]
Let resulting tract opportunities be \(a^{(-e)}\). Then the weighted opportunity loss due to edge \(e\) is
\[
R_e = \sum_i \omega_i\bigl(a_i-a_i^{(-e)}\bigr).
\]
If the focus is the lower-tail loss, define
\[
R_e^{\text{tail}} = \operatorname{CVaR}_{0.1}(a,p)-\operatorname{CVaR}_{0.1}(a^{(-e)},p).
\]
This creates a matrix-linked vulnerability measure grounded in actual recomputed path structure.

## 10. Systems architecture links

The matrix objects above should map directly onto systems diagrams:
- raw Census/TIGER/OSM layers -> selection matrices, population vector, graph matrices;
- routing engine -> shortest-path matrix operator;
- access engine -> thresholded kernel \(K\);
- scoring engine -> tract opportunity vector \(a\);
- optimization engine -> set function \(F(S)\);
- resilience engine -> perturbed kernel \(K^{(-e)}\).

## 11. What V19 should present in the manuscript

At minimum, V19 should present:
1. the adjacency / incidence / shortest-path notation;
2. the kernel matrix \(K(T,\tau)\);
3. the category-access aggregation formula;
4. the submodularity proof sketch for Algorithm II;
5. the edge-removal loss formulation for Algorithm III;
6. a note that exact computations are implemented by truncated Dijkstra rather than dense matrix multiplication.

This appendix upgrades V19 mathematically. It does not claim that the real data execution has already been completed.


---

## INTEGRATED SOURCE: V19.1_DRAWIO_STANDARD_AND_DIAGRAM_CONTRACT.md

# V19.1 — Draw.io Standard and Diagram Contract

Status: **additive upgrade**. All conceptual / architecture / technical-route / evidence-chain diagrams in V19 shall follow this Draw.io standard. This does not invalidate existing textual design decisions; it standardizes their visual execution.

## 1. Scope

The following diagram classes must be created in Draw.io (diagrams.net) style, not as ad hoc PowerPoint-like illustrations:

1. **Systems Architecture**
2. **Technical Route**
3. **Evidence-to-Decision Architecture**
4. **Algorithm I workflow**
5. **Algorithm II workflow**
6. **Algorithm III workflow**
7. **Claim–Equation–Data–Figure–Manuscript chain**
8. **Release / reproducibility / quality-gate flow**

## 2. Draw.io style rules

### 2.1 Canvas and export
- Use white background.
- Native editable source: `.drawio`.
- Export: `SVG` and `PDF`.
- Primary page size: US Letter landscape for wide architecture diagrams; portrait for workflow diagrams if more readable.
- Minimum final readable font in export target: 12 pt equivalent.

### 2.2 Shape grammar
- **Rounded rectangle**: process / computational module.
- **Document shape**: input or output file.
- **Cylinder**: data store / dataset repository.
- **Hexagon**: decision or audit gate.
- **Parallelogram**: external source or imported official raw data.
- **Swimlane / grouped lane**: system layer (data, model, decision, paper, audit).

### 2.3 Connector grammar
- Solid arrow: actual computed data flow.
- Dashed arrow: audit / validation / review flow.
- Dotted arrow: conceptual influence or interpretation, not direct computation.
- Red or warning-styled connector: blocking gate / failure branch.

### 2.4 Color semantics
- Data source / provenance: muted blue-gray.
- Graph/routing modules: teal.
- Optimization modules: sand/gold.
- Risk/fairness modules: muted terracotta.
- Manuscript / communication modules: navy.
- Audit / gate / warning: gray plus red accent.

## 3. Diagram-specific requirements

### 3.1 Systems Architecture
Purpose: show the full research stack from raw sources to paper outputs.
Required lanes:
- Official data inputs
- Spatial preprocessing
- Graph computation
- Scoring and ranking
- Optimization / fairness / robustness
- Manuscript / atlas / release outputs
- Quality gates

Each connector must be labeled with at least one variable, matrix, or file object (e.g., `D_RF`, `K(T,τ)`, `a`, `rank.csv`, `figure_registry.csv`).

### 3.2 Technical Route
Purpose: show the research pipeline in chronological execution order.
Required numbered modules:
1. acquire official raw files
2. verify SHA256
3. build city geometry and youth proxy
4. build pedestrian graph
5. compute Algorithm I access kernel
6. compute M0 / controlled ablations / M1
7. compute Algorithm II optimization
8. compute Algorithm III fairness and resilience
9. compute LP/Pareto/evidence horizon
10. render GIS / charts / atlas
11. render paper and perform release audit

### 3.3 Evidence-to-Decision Architecture
Purpose: show how observed data, normative weights, counterfactual modules, and final recommendations are separated.
Required separation:
- Observed quantities
- Derived but observational metrics
- Counterfactual outputs
- Normative decision layer
- Communication outputs

### 3.4 Algorithm diagrams
Each algorithm diagram must contain:
- input set
- data structures
- key loop or computation
- output object
- exact audit outputs
- failure / blocking conditions

### 3.5 Claim-chain diagram
This must explicitly show:
`source manifest -> equation contract -> result CSV -> figure ID -> manuscript section -> release audit`.

## 4. Prohibitions
- No decorative icons unrelated to the science.
- No 3D blocks.
- No unlabeled arrows.
- No arrows that pretend a normative preference is an observed data flow.
- No generic “AI analysis” box without explicit role.

## 5. File naming
- `D19-01_systems_architecture.drawio`
- `D19-02_technical_route.drawio`
- `D19-03_evidence_to_decision.drawio`
- `D19-04_algorithm1_routing.drawio`
- `D19-05_algorithm2_optimization.drawio`
- `D19-06_algorithm3_fairness_resilience.drawio`
- `D19-07_claim_chain.drawio`
- `D19-08_release_quality_gates.drawio`

## 6. Manuscript use
The paper should include at most 2–3 compact Draw.io diagrams in the main body, with the rest placed in the technical atlas or reproducibility appendix. The main candidates are:
- D19-01 Systems Architecture
- D19-02 Technical Route
- D19-03 Evidence-to-Decision Architecture

## 7. Acceptance gate
A diagram is accepted only if:
- the editable `.drawio` exists,
- the exported `SVG/PDF` exists,
- all arrows are labeled,
- all major variables and file objects are named,
- it matches the actual V19 computational modules,
- it uses the prescribed style grammar.

This file adds execution standards. It does not assert that the Draw.io diagrams have already been drawn.


---

## PRESERVED V18 SCIENTIFIC ENGINE — migrated to V19 paths without changing frozen M0/M1

# Y-CITY × SYORA | V19 — COMPLETE STANDALONE EMPIRICAL RESEARCH ENGINE

**Identity:** V19-only executable research directive; no earlier-version archives, master documents, datasets, reports or source code are bundled. Any indispensable earlier algorithms have been integrated under `code_v19/` and migrated to V19 storage paths.

**Research target:** Download and verify 28 original 2024 U.S. Census ACS/TIGER files, acquire 12 authentic OSM pedestrian street networks from OSMnx/Overpass or Geofabrik/PBF, calculate route-based opportunity with tract-scale youth proxies, rank all 12 cities, independently recompute results, run systems-science and uncertainty tests, render real scientific charts and GIS maps, then compile an English scientific PDF to the official optional layout. Data acquisition and final empirical paper have NOT been executed in this packaged edition. A ZIP containing scripts is not a proof of downloads.

**Binding rules:**
1. The only valid code namespace is `code_v19/`, only runnable tests are under `tests_v19/`, and the only frozen reference weights are `config_v19/reference_model_v19.json`. No external version folder is a runtime dependency.
2. A ranking or compiled empirical manuscript may be released only after 28 original Census bytes with SHA256 and actual source provenance, 12 OSM graphs and their raw OSM sources, real route/POI inputs, complete scores, independent replay, sensitivity, system hypotheses, source-grounded figures, PDF preflight and human scientific review.
3. Census is the government publisher of ACS and TIGER; OSM street observations are from OpenStreetMap contributors (and may be obtained through Geofabrik or Overpass), not a government-certified walking network.
4. The official paper layout supplied by the user is explicitly optional, but the project chooses to follow it and audit that choice. Scientific validity and model uncertainty cannot be established by chapter labels alone.
5. Hard failure or unavailable data produces `BLOCKED_FOR_FINAL_GIS_PAPER` and a precise evidence ledger, never invented Census, maps, ranking or results.

**Canonical entrypoint:** `python code_v19/run_v19.py --stage all --network auto`. Use `--dry-run` only to inspect phases; never describe a dry run as completed empirical execution. Windows users may run `code_v19/run_v19_windows.ps1`; Linux/macOS users may run `code_v19/run_v19_linux_macos.sh`.

---

## 1. V19 original research purpose and the single model spine

The question remains **Which city among twelve fixed U.S. candidates is most favorable for a high-school-aged resident under explicitly defended, measurable and potentially reachable opportunities?** Preserve the 12-city study set as frozen before seeing results: Austin TX (`4805000`), Boston MA (`2507000`), Chicago IL (`1714000`), Denver CO (`0820000`), Madison WI (`5548000`), Minneapolis MN (`2743000`), Pittsburgh PA (`4261000`), Portland OR (`4159000`), Raleigh NC (`3755000`), San Diego CA (`0666000`), Seattle WA (`5363000`), Atlanta GA (`1304000`). Each seven-digit place GEOID is a **string** and must retain leading zeros. No city is dropped for scoring convenience, and there is no peeking at the champion to re-select indicators.

The unified mathematical narrative is **systems boundary → observations → M0 simple baseline → explicit model diagnosis → M1 network-constrained opportunity revision → M2 fairness, trade-offs and robustness → qualitative meaning → separate limitations/conditional interpretations.** Never present M0/M1/M2 as three unrelated city indices. A historical city-level proxy ranking must not be imported as the network-GIS champion or used to tune the model.

V19 explicitly combines two non-interchangeable original source families:

- **Official federal originals:** 2024 ACS five-year Table-Based Summary File at the full `.dat`-file byte level and 2024 Census TIGER/Line place/tract shapefile ZIPs. These support statistical, population and municipal boundary assertions. The Census all-roads county shapefiles are additional independent road geometry, not a legal pedestrian-access routing network.
- **Actual OSM network originals:** Overpass's actual HTTP response bytes cached by OSMnx **or** Geofabrik's actual downloaded `.osm.pbf` bytes. OpenStreetMap contributors provide OSM observations under ODbL; these are not official U.S. Census walking network records. The saved `GraphML` is derived by actual parsing of original OSM bytes, not raw OSM source.

**Evidence hierarchy:** `SOURCE_URL_DISCOVERED` ≠ `ORIGINAL_BYTE_DOWNLOADED` ≠ `HASH_RECORDED` ≠ `SCHEMA_PASSED` ≠ `GEO_TIME_ALIGNED` ≠ `GRAPH_ROUTES_CALCULATED` ≠ `INDEPENDENTLY_RECOMPUTED` ≠ `COMPLETE_PAPER_COMPILED` ≠ `HUMAN_SCIENTIFIC_REVIEW_PASSED`. Do not publish a winning city until the final conditions are met.

## 2. Mandatory 28 Census originals: complete, executable download contract

**Data version decision (freeze):** 2024 five-year ACS means observations from 2020–2024; geographic boundaries from TIGER 2024. They do not constitute a 2026 survey or exact 2024 individual housing observation. Record the 2026 retrieval date separately. The official dataset and file grammar are documented at:

- `https://www.census.gov/programs-surveys/acs/data/summary-file.2024.html`
- `https://www.census.gov/programs-surveys/acs/data/summary-file/getting-started.html`
- `https://www2.census.gov/programs-surveys/acs/summary_file/2024/table-based-SF/data/5YRData/`
- `https://www.census.gov/geographies/mapping-files/time-series/geo/tiger-line-file.2024.html`

**All 28 original files are REQUIRED for the reference main model:**

1. `acsdt5y2024-b01001.dat` → project file `acs_2024_5y_B01001.dat`: population by sex and age, tract and city.
2. `acsdt5y2024-b25070.dat` → project file `acs_2024_5y_B25070.dat`: household rent as share of income; exclude 'not computed'.
3. `acsdt5y2024-b28002.dat` → project file `acs_2024_5y_B28002.dat`: use **`B28002_E004` broadband of any type**, NOT `B28002_E002` (any internet subscription). Verify all actual labels using official table definitions.
4. `acsdt5y2024-b17001.dat` → project file `acs_2024_5y_B17001.dat`: poverty status by sex/age universe; use correctly scoped B17001 002/001 ratio for citywide household-context proxy, not a direct child poverty probability.
5–28. For all **twelve** state FIPS prefixes `06,08,13,17,25,27,37,41,42,48,53,55` download both `https://www2.census.gov/geo/tiger/TIGER2024/PLACE/tl_2024_{STATE}_place.zip` and `https://www2.census.gov/geo/tiger/TIGER2024/TRACT/tl_2024_{STATE}_tract.zip`. The 24 state-specific ZIPs must each be a real ZIP containing shapefile geometry, not a scraped city outline or synthesized GeoJSON.

The acquisition executable is `code_v19/acquire_census.py` using a robust transfer kernel in `code_v19/fetch_verified.py`. It attempts HTTPS streaming with bounded exponential retry and true byte-offset resume. A resumed `206` must confirm `Content-Range` begins at the already received offset; a server that ignores Range and returns `200` restarts the file, never concatenates duplicate bytes. On network failures the downloader can legally attempt installed **aria2, curl and wget** with bounded retries, without evading authentication or server rate limits. Downloaded files are kept byte-for-byte, not decompressed into replacement pretend originals.

`SHA256(original_byte_stream)` is generated only after the original file exists. For each source store: `source_id,publisher,official_url,final_response_url,datetime_utc,file_path,exact_byte_count,http_status,sha256,content_type,zip_or_dat_schema_pass,origin_verification,release_eligible`. Save manifests atomically to `qa_v19/census_original_manifest.json` and optionally append sidecar `sha256sum` checks; manually typed or pre-existing hashes do not prove retrieval. **The official source does not necessarily publish a trusted reference SHA256; a locally computed SHA256 demonstrates identity and later consistency, while actual official-domain TLS/download records support provenance.** Do not claim publisher-certified checksum without an official published expected digest.

The parser must stream the real **pipe-delimited** table-based ACS original (`|`), not assume a comma-delimited CSV, and distinguish its `B01001_E006` / `B01001_M006` form from Census API's `B01001_006E` / `B01001_006M`. Match `GEO_ID` exactly: `1600000US` + seven-digit city GEOID or `1400000US` + eleven-digit tract GEOID. Reject missing/malformed estimate and MOE columns, duplicates, negative Census sentinel codes, values marked unavailable and incompatible denominator universes. Retain a 12-city derived CSV **and its hash**, linked to the hash of the actual full-table source.

A Census API response may be used **as an independently hashed cross-validation source**, but it does **not** replace a missing whole-table `.dat` when the strict V19 full-original release gate requires the latter. `data.census.gov` CSV exports and legal archives are also acceptable for independent validation and recovery, clearly tagged with their own exact data format/vintage and local SHA. They do not silently downgrade the 28-original condition.

## 3. More-than-one-way acquisition without compromising provenance

The source hierarchy is a **decision tree**, not a guarantee of HTTP availability:

- **A: Direct federal originals:** `www2.census.gov` official Table-Based `.dat`, official TIGER ZIP, exact names and vintage. Download via Python, curl, aria2 or wget. Support HTTPS system proxy settings where legally and securely configured. Do not bypass access control or falsify a user agent to defeat explicit denial.
- **B: A different legitimate client on the same official origin:** browser, approved network or remote machine; download exact official bytes to a local folder. Do not edit their raw bytes; compute SHA256 and record the real official HTTPS URL and browser/download evidence. Import through `--import-dir` and actual per-file JSON attestation; use `--allow-attested-origin` only after human verification. This is separately labeled as **human-attested**, not machine-proven direct-source transfer. Official original files may also be brought in from an institutionally obtained lawful copy with independently verifiable trusted receipt.
- **C: Geofabrik fallback for OSM:** `https://download.geofabrik.de/north-america/us/{state}-latest.osm.pbf`. Download state original PBF to a stored file; independently SHA256 it; use Pyrosm's `OSM(...,bounding_box=...)`, `get_network(network_type='walking',nodes=True)` and `to_graph(...,graph_type='networkx')` to build the actual walking network. Recover POIs from actual PBF features. This is source independent of the Overpass HTTP API.
- **D: Overpass fallback for OSM:** OSMnx `graph_from_polygon(...,network_type='walk')` + saved raw HTTP cache and `features_from_polygon()` for candidate libraries/parks. Respect Overpass rate limits and timeout. A legal second public Overpass endpoint can be configured only if its behavior/terms are reviewed. Do not assert that an untried endpoint was successfully used.
- **E: Other openly documented OSM extract indexes for further recovery:** Pyrosm's `find_extracts/get_data_by_area` discovers Geofabrik, BBBike and Movisda options. If a new source is used, preserve its actual original PBF bytes, URL, exact SHA256, license/attribution and geometry extent. Verify walk/POI coverage using the same graph tests. Record the different source ID; never silently relabel a BBBike extract as Geofabrik. Do not claim an automatically cropped derivative PBF is the unmodified upstream original file.
- **F: The Census 2024 TIGER county `ROADS` series** is available through the optional `code_v19/acquire_tiger_roads.py` stage. It provides independent original cartographic street geometry and SHA256 for city-covering counties, useful for cross-source topology checks, **but cannot silently replace a legal pedestrian walking graph**. TIGER includes vehicular/private facilities and lacks all pedestrian entitlement constraints.

The permitted sources and links are only candidate inputs until actual download logs certify bytes. Avoid treating the existence of URLs, GitHub repositories, or a ZIP folder named `raw` as evidence of acquisition. Stop after reasonable bounded retries; print exact missing records for human continuation instead of promising unlimited background downloads. The run can be resumed after the external availability or source evidence improves.

## 4. Actual OSM pedestrian network: 12-city geometry, topology, origin–destination proof

Start from actual TIGER place polygons (project with EPSG:5070 to buffer 3.5–4 km in real metres), not city names or coarse city centroid rectangles. Download/parse beyond municipal administrative borders so that service catchments can genuinely cross them. Source snapshot vintage of OSM PBF or Overpass query date is **recorded separately** from Census 2024. A `2026-latest` OSM graph cannot be called an actual 2024 historical street graph.

**Native geometry sequence:** TIGER PLACE ZIP → unique 7-digit GEOID city polygon → 2024 tract TIFF? **No:** use TIGER `TRACT` shapefile, intersect with city polygon → 2024 ACS 15–17 estimated population weighted by area fraction → one actual inside-city representative tract origin → walkable `OSM` road graph + true graph nodes/edges → snapped origin and candidate facilities → Dijkstra network distance → 10/20/30-minute opportunity values. Any claim about precise residence address, park access gateway, admission or travel reliability remains unobserved.

For every one of the 12 cities save: original raw Overpass cache `.json` responses with SHA256 **or** one referenced original state Geofabrik `.pbf` (SHA256, source URL and source timestamp), derived `.graphml` (SHA256), full graph node/edge counts, CRS, speed and cutoff settings, nearest-node snap distance distribution, actual observed POI list with OSM IDs/access tags, tract origins, gzipped OD route pairs, per-tract computed facilities, and one per-city receipt. No synthetic network, no bird-flight time formula, no fabricated bus feed.

**Walk model:** edge cost is measured network distance in metres and pedestrian time is `distance / 1.25 m/s` in the frozen reference case. Re-evaluate alternative reasonable speeds as separate scenarios. Respect graph direction and any actual legal foot access restrictions; directed disconnected reaches are `unreachable`, not zero-minute access. Project geometries before KD-tree node snapping. Fail graph QA if network tiny, implausible lengths, missing actual libraries/parks, excessive snap distances, no tract populations or missing original response/PBF. A public facility point is a *potential opportunity* until opening hours, entry constraints and gate points are verified.

**Important park entrance caveat:** an OSM park polygon's `boundary.representative_point()` is only a geometric **boundary-access proxy**, not evidence of a public entrance. Never call an OSM point a validated gate unless an observed `entrance=*` point or official local park-access record supports it. All such entries are labeled in `poi_osm_*.csv`; quantify how exclusions or assumptions could change accessibility. Document duplicate park geometries and point POIs separately; do not double-count the same mapped park and its centroid as two opportunities.

**Conditional fallback route:** first OSMnx/Overpass, next full state-level Geofabrik/PBF + Pyrosm. On one city failing, continue only in controlled recovery attempts; do not publish ten cities under an unannounced changed sample. To maintain the fixed 12-city reference main model, require **all 12 valid graphs**. Network retry does not imply scheduler or cloud task automation; human reruns commands after addressing failures.

## 5. Spatial demography, time alignment and scientific error accounting

Age 15–17 proxy: for tract $g$, $n_g=\mathrm{B01001}_{E006,g}+\mathrm{B01001}_{E030,g}$; record both marginal $M006/M030$ and whether the sum's MOE treatment conservatively bounds unknown covariance. If actual official target 14–18 values cannot be observed at comparable tract granularity, label the age-proxy limitation and test reasonable scenarios rather than inventing enrollment counts. **Never treat the 15–17 estimate as an exact 14–18 population.**

For a tract intersecting a city boundary, $n_{gc}=n_g\cdot A(g\cap c)/A(g)$ using EPSG:5070 projected area; $\sum_c n_{gc}$ need not equal actual city census counts because area interpolation assumes locally uniform density within the source tract. The difference must be assessed and reported. City inputs and raw source universes must use 2024 ACS five-year common vintage; do not merge a Census 2025 one-year estimate into the main 2024 five-year score without a separately disclosed scenario and modified uncertainty treatment.

`B25070` housing burden: $r_c=(E007+E008+E009+E010)/(E001-E011)$; numerator represents household gross-rent burden at or above 30% **among computed cases**, not the fraction of all students paying rent. `B17001`: $p_c=E002/E001$ citywide population below poverty in table universe. `B28002`: $b_c=E004/E001$ broadband-of-any-type household subscription, **not** E002 and not individual teenage broadband access. All three are environmental proxies, not actual youth welfare outcome measures.

**Uncertainty ledgers must remain separate:**

| Channel | Source of uncertainty | Auditable treatment | Prohibited inference |
|---|---|---|---|
| ACS sample | Census published marginal 90% MOE | `uncertainty_envelopes.py` propagates numerator/denominator worst-case endpoint ranges into M0 and M1 | The resulting simultaneous bounds are not a 90% joint confidence interval |
| Spatial allocation | Tract area share, representative origin, MAUP | stratified sensitivity of geographies, origins and missing tracts; compare place youth totals | Exact house-to-road travel observed |
| OSM geometry | missing roads, direction, fragmented graph, feature duplication | network coverage, snap errors, compare TIGER all-roads as a cartographic *crosscheck* | TIGER all-roads proves foot access |
| Eligibility | park gates, fees, hours, public access | evidence-based access tags and lower/upper opportunity scenarios; never silently set unknown=true | modelled proximity proves actual participation |
| Normative model | score anchors, dimension weights, fairness preference and cutoff | 27 actual recomputed scenarios plus explicit alternative bottleneck operator | rank frequencies are population preferences or frequentist confidence |
| Temporal | mixed ACS 2020–2024 and OSM acquisition snapshot | label two vintages in every figure and caveat | cross-sectional correlation proves dynamic feedback |

## 6. Mathematical spine, actual testable properties and the main model revision

**M0: household-context baseline** is a transparent fixed normative scoring rule (model definitions are decisions, not discoveries):

\[
\begin{aligned}
 u_r &= \operatorname{clip}((0.80-r_c)/0.60,0,1),\\
 u_p &= \operatorname{clip}((0.35-p_c)/0.35,0,1),\\
 u_b &= \operatorname{clip}((b_c-0.60)/0.40,0,1),\\
 M_0(c) &= 100(0.35u_r+0.35u_p+0.30u_b).
\end{aligned}
\]

For true pedestrian routes and facilities, with reference $v=1.25$ m/s, cutoff $T=20$ min, and exponential decay constant $\tau=12$ min:

\[
 t_{gj}=\ell_{gj}^{\mathrm{network}}/v,
 \quad K_{gjk}=\mathbf1\{j\in k,t_{gj}\le 60T\}\exp[-t_{gj}/(60\tau)],
 \quad A_{gk}=\sum_jK_{gjk}.
\]

An opportunity candidate is *not* a youth attendance probability. With $k=L$ (libraries) and $P$ (parks), let $U_{gk}=1-e^{-A_{gk}/2}$ and $a_g=0.55U_{gL}+0.45U_{gP}$. Let $\bar a_c=\sum_gn_ga_g/\sum_gn_g$, $Q_{0.1,c}$ the weighted lower 10% quantile of $a_g$ across tracts (not a 10% bootstrap confidence interval), and $V_c=0.75\bar a_c+0.25Q_{0.1,c}$. The final frozen reference score is

\[
 \boxed{M_1(c)=0.60M_0(c)+40V_c}
\]

Because $M_0\in[0,100]$ and $V\in[0,1]$, $M_1\in[0,100]$. The revision changes the mathematical object by introducing genuine route-limited spatial opportunity, population weighting and a lower-decile equity component; it is **not** merely retuning weights. Still, its predictive/external *merit* must be demonstrated separately; a changed winner is not evidence of increased empirical validity.

M2 is a **robustness/decision layer** over M1, not a third selectively marketed trophy ranking. For 3 cutoff values `10/20/30 min` × 3 ACS share weights `0.50/0.60/0.70` × 3 fairness weights `0/0.25/0.50`, actually recompute all 12 cities = **324 score rows** and exactly 27 full rank permutations. Scenario champion frequency $\hat p_c=(1/27)\sum_{s=1}^{27}\mathbf1\{c\mbox{ ranks first in }s\}$ has the interpretation **share of specified finite preference scenarios**, not a posterior probability or a human preference sample. Use stable tie-breaking. Compare rank confidence only when a valid sampling/measurement design warrants it.

Proof obligations for validation: (i) M0 bound and monotonicity; (ii) increasing travel distance cannot increase feasible $K$, conditional on fixed eligibility; (iii) adding a verified reachable facility cannot reduce raw $A$; (iv) adding an unreachable facility leaves $A$ unchanged; (v) weighted accessibility remains in domain; (vi) no prohibited division-by-zero; (vii) rank permutation exactly 1…12 for each of 27 scenarios; (viii) both marginal ACS MOE and missing network snap perturbations recorded; (ix) source version changes cause re-computation; (x) final English Summary, table, figures and news article all use the same released score CSV.

## 7. The eight systems principles become falsifiable empirical science

Use the `8-4-2` conception as a **study-specific organizing heuristic**, not a claim that an uncontested set of eight universal laws exists. Key implementation is in `code_v19/systems_hypothesis_tests.py`, generating `results_v19/SYSTEMS_THEORY_EMPIRICAL_TESTS.csv`, `H3_CROSS_BOUNDARY_SERVICE_FLOW.csv`, `H4_COMPLEMENTARITY_BOTTLENECK.csv` and independent receipts. Use only observed inputs; for unidentifiable principles report `NOT_IDENTIFIABLE` instead of decorating the paper with unsupported jargon.

| Systems principle | Observable / falsifiable operating hypothesis | Actual source-linked computation | Interpretation boundary |
|---|---|---|---|
| **目的性 Purpose** | a youth-relevant metric set differs from adult commuting/diploma prestige | age 15–17 proxy; remove adult-only indicators; compare M0 and feature choice | normative age fit ≠ observed teen preference |
| **整体性 Holism** | resource access can be bottlenecked when only one channel is available | additive $0.55U_L+0.45U_P$ versus $\sqrt{U_LU_P}$ with same measured inputs | geometric mean is a policy operator, not empirical proof of synergy |
| **层次性 Hierarchy** | city mean conceals tract disparity | population-weighted $\bar a$, weighted $Q10$, gap and choropleth | tract representative points are proxies for residents |
| **开放性 Openness** | reachable opportunities and services cross city borders | GIS classify OSM facilities vs TIGER city polygon; report share of actual decay-weighted route-pair contributions outside city | this particular share is route-pair weighted, **not** population-weighted |
| **突变性 Threshold behavior** | 10/20/30 min constraints can sharply remove opportunities | 27 real parameter scenarios and cutoff rank changes | change at a policy threshold is not a physical phase transition |
| **稳定性 Stability** | cities' access structure persists under time-varying shocks | cross-year panel only if multiple actual historical graphs and comparable data are supplied | one mixed-vintage cross-section: **NOT IDENTIFIABLE** |
| **自组织性 Self-organization** | local youth groups create endogenous opportunities | only testable with repeated observed real social/club network data | currently **NOT IDENTIFIABLE**; do not fabricate mechanism |
| **相似性 Similarity/transfer** | score structure applies to comparable held-out cities | optional independent cities with frozen definitions and new original data | current selected 12 do not prove general national representativeness |

The systems loop represented in the Introduction graphic is a **research feedback cycle** (diagnose empirical error, revise model, re-run, test counterexamples), not a measured causal feedback mechanism in students or cities. To claim self-regulation/dynamic stability, specify a temporally indexed state transition model and obtain repeated measurements first.

## 8. High-level rigorous empirical tests beyond a pretty leaderboard

All tests must be computed from frozen, genuinely obtained inputs. At a minimum run:

1. **Base quality:** source byte lengths/SHA, ACS variable and GEOID integrity, polygon validity, CRS, duplicate POIs, graph edge costs, snap-error extremes, dataset timestamp and source citation.
2. **All-city complete M0/M1 rerun:** same 12 population/period/geometry, frozen anchors, clear champion and 12-row rank output; no selective replacement city.
3. **Model revision audit:** M0→M1 all-city delta ranks, Kendall τ and Spearman ρ, a citypair explanatory case and ablation of network access and fairness. A change in ordering is necessary to understand the revision, not proof of objective correctness.
4. **GIS external audit:** source-snapshot crosschecks, optionally Census county all-roads and official IMLS FY2024 library outlets / NCES 2024–25 school directory as independent facility-coverage comparators. These sources require real downloaded bytes and version/coverage checks; they are not silently added to the main score without common nationwide data and eligibility evidence.
5. **Target-population error:** tract area interpolation and school-age proxy denominators compared to ACS municipal controls. Document observations that cannot be mapped (including OSM disconnected segments) and the consequences for cities at risk of score reversal.
6. **Spatial fairness:** tract Q10, population-weighted city mean, mean-minus-Q10 and within-city geographic dot/choropleth showing real tract boundaries and graph access scores; labels distinguish tracts from individuals.
7. **Cross-border openness:** share of real 20-minute route-pair facility contributions lying outside city polygon; boundary spillovers demonstrate system permeability and make them nontrivial to count.
8. **Conservative ACS sampling stress:** use each needed 2024 ACS `E` and matching `M` fields to generate numerator/denominator ratio bounds; propagate to M0/M1; label endpoint ranges as **stress envelopes, not a simultaneous confidence interval**.
9. **27 actual preference and structural scenarios:** 324 row matrix, champion changes, spatial non-compensatory alternatives, no invented posterior probabilities.
10. **Counterfactual limits:** no real teen happiness/educational-attainment outcome data implies no causal effect and no objectively universally best city. Document failed hypotheses and weak external validity.

The source-backed city ranking is only the **reference** under frozen preferences. A family whose priority is disability access, school-district eligibility, rental availability, safety, special needs or mass transit must not be told that the top city in this limited model is universally best for them.

## 9. Production scientific visualization: 10+ figure evidence atlas

`code_v19/render_atlas.py` is an **evidence-gated** graphics producer. The figure outputs are not generated or fabricated before the requisite actual data exist. On full successful execution it generates vector PDF and SVG plus high-resolution PNG as appropriate, with a `figure_manifest.json` linking every published figure to the SHA256 of the final ranking file and its own exported PDF hash. A graph of concepts may be drafted before the run, but numerical and map figures cannot be presented as completed until their evidence is available.

| Figure | Research question | Form and exact source |
|---|---|---|
| F18-01 | Who leads the frozen reference? | ordered horizontal bar, exact 12-city M1 values from audited CSV |
| F18-02 | Was model revision substantive? | 12-city M0→M1 slopegraph showing every actual change |
| F18-03 | Do Census sampling errors challenge the conclusion? | bound whiskers using genuine official ACS `M` field calculations; **not confidence intervals** |
| F18-04 | When does each city lead under different preferences? | complete 12×27 rank-acceptability heatmap, exact scenario labels |
| F18-05 | Which type of public opportunity drives observed differences? | library vs park population-weighted score comparison |
| F18-06 | Where do the worse-served tracts hide behind averages? | city mean vs weighted tenth-percentile dumbbell chart |
| F18-07 | Is GIS based on actual streets, or hand-drawn proximity? | Austin real Census boundaries, actual OSM street graph, real POIs and tract origins, actual scoring; projected geometry |
| F18-08 | Can every claimed result be traced backwards? | source→spatial transforms→M0/M1→QA/uncertainty→paper architecture, deterministic Graphviz DOT+SVG+PDF |
| F18-09 | How open are municipal service areas? | ranked cross-city-boundary decay-weighted route-pair contributions |
| F18-10 | Is a single excellent opportunity type masking weakness elsewhere? | additive vs geometric-complementarity small scatter using real city components |

**Scientific graphic house rules:** PLOS/Nature-style restrained visual language rather than decorative infographics; each figure has a clear analytical question, readable direct labels, meaningful baseline/units, uncertainty definition, consistent city order/colour, colorblind-safe and grayscale-distinguishable visual channels, true coordinate reference, credible geographic scale and source vintage. Render all streets from actual GraphML. The only valid map coordinate values are from traceable TIGER/OSM data; a schematic flowchart is not a geospatial map. Never use unlicensed satellite tiles, fictional gates, decorative heat maps or fabricated contours. Graphviz/TikZ is for conceptual system diagrams, not street geometry. Labels need legibility at printed page size and no obstruction or clipping.

For the final 25-page manuscript include the **highest-impact 3–5 figures** selected for argumentative economy; retain the rest as reproducibility/technical appendix and high-quality standalone research atlas, rather than clogging the main paper with 10 decorative figures. Page count and format must be verified on the actually compiled PDF.

## 10. Submission-grade English scientific paper: write from results, not from wishes

The generated target is a **publication-grade independent research paper**, written after real ranks and graphs are available. It is not official COMAP submission without valid team registration and independent competition compliance; none is claimed. Use `code_v19/build_empirical_gis_paper.py` and `code_v19/release_audit.py` after all upstream audits; no synthetic data or manually composed champion is permitted. Sources and corresponding code/receipt IDs must be cited for every quantitative result. Ensure the scholarly narrative does not overstate the link between potential facility access and actual teen welfare.

**Suggested reading order (≤25-page solution where practical, not forced padding):**

1. **One-page research Summary** with actual champion/score, 12 cities, time/vintage, measurable definition, explicit revision, most important robust conclusion and one failure/conditionality statement.
2. **Contents and Introduction** with one professional systems-and-evidence architecture, no hollow history of systems-theory authors and no fake feedback loop measurement.
3. **Problem analysis and indicator choices**, 14–18 target vs ACS 15–17 proxy, facility eligibility, exclusions, prior city sample, known alternative plausible values.
4. **Data & GIS methods**, exact source provenance, 4 ACS DAT + 24 TIGER ZIP + 12 OSM originals, MOEs, geographies, buffer, network, snap error, city/tract geometry.
5. **M0 analytical definition and diagnosis**, all physical units and frozen normative score anchors.
6. **M1 mathematical derivation and substantive revision**, true route length, exponential kernel, bounded facility type utility, population weighting, lower decile, proof of key monotonic properties and empirical mechanism.
7. **Actual 12-city results** and full comparison table with exact references, real Austin map and spatial equity case, unambiguous conditional reference winner.
8. **Independent verification, model comparison and falsification**, source-asset hashes, Kendall τ and rank changes, precision limitations, 27 scenarios, ACS sampling stress, systems principles tested/not identifiable.
9. **Limitations and defensible improvements**, historical vintage mismatch, OSM data completeness, park gates/eligibility, schools, socioeconomic construct, spatial resolution and noncausal interpretation.
10. **Conclusion and 1–2 page nontechnical news article**, exact same champion, score, assumptions, major revision effect and weak points as Summary.
11. **Full references and honest AI-use statement** describing actual model/code/figure/drafting assistance, not a generic fictitious disclosure.

All tables and captions should be produced by programs from the same frozen result object. The summary is written last. A valid TeX bundle is not sufficient: actually compile the PDF, audit page count, readable font size, source/caption consistency, render quality, no unintentional clipping, abstract/table/news cross-consistency, and source DOI/URL validity. V19's automated PDF gate returns `TECHNICAL_PRECHECK_PASS_HUMAN_SCIENCE_REVIEW_PENDING` at most, never claims a human or official reviewer accepted the paper. If an unexpected class/package or LaTeX template issue occurs, repair and recompile; do not delete substantive sections to hide the issue.

## 11. Single-command deterministic workflow and exact release files

Human operator opens `README_START_V19.md` and runs one of these commands after installing Python 3.11/compatible native GIS wheels, Graphviz and LaTeX. Use appropriate bandwidth and disk budget. OSM data may require gigabytes, especially on Geofabrik fallback for California and Texas; do not try to fetch all USA if only 12 cities are needed.

```bash
# Linux or macOS
bash code_v19/run_v19_linux_macos.sh

# All operating systems, after dependencies installed
python code_v19/run_v19.py --stage all --network auto

# Lightweight no-network command inspection
python code_v19/run_v19.py --dry-run

# Full offline unit tests before data acquisition
PYTHONPATH=code_v19 python -m pytest -q tests_v19

# Optional independent official Census county-roads acquisition (not pedestrian routing)
python code_v19/run_v19.py --stage census_streets
```

In Windows PowerShell, use:

```powershell
powershell -ExecutionPolicy Bypass -File .\code_v19\run_v19_windows.ps1
```

When direct TLS download fails but human has downloaded the exact official originals:

```bash
python code_v19/run_v19.py --stage all --import-dir /path/to/original_files --attestation-dir /path/to/reviewed_source_receipts --allow-attested-origin
```

This human-attested branch explicitly needs actual source records and actual reviewer signoff. It cannot be triggered by putting a ZIP in a folder or inventing checksums. Standalone code cannot prove the authenticity of an externally supplied file unless a trusted publisher hash or trustworthy provenance chain is provided. In the official acquisition run, the direct TLS source + generated SHA256 is its evidence mechanism.

**Phase states in `qa_v19/v19_execution_state.json`:** `tests` → `census` → `geography` → `networks` → `score` → `audit` → `sensitivity` → `uncertainty` → `systems` → `figures` → `atlas` → `paper` → `release`. Every phase must actually exit zero. Any phase failure sets `BLOCKED_FOR_FINAL_GIS_PAPER` with logs; no text instruction may overwrite this state.

**Mandatory post-run file proofs (not pre-created empty placeholders):**

```text
qa_v19/census_original_manifest.json            # 28 actual Census source records, true SHA256 and verified schema
qa_v19/full_gis_qa.json                       # independent 12-city graph/CSV/source-hash audit
qa_v19/v19_execution_state.json               # actual run gates, not planning checklist
data/raw_official/v19/acs_2024_5y_*.dat        # actual full Census original table bytes
data/raw_official/v19/tl_2024_*.zip            # actual 24 place and tract TIGER originals
data/raw_osm/v19/cache/...                     # actual Overpass JSON response originals OR
data/raw_osm/v19_geofabrik/*.osm.pbf           # actual Geofabrik originals
data/raw_osm/v19/graphml/*.graphml             # 12 actual derived walking graphs, plus hashes
data/processed/v19_network/walk_pairs_*.csv.gz # actual directed network OD route lengths
results_v19_gis/FINAL_12_CITY_REAL_GIS_RANKING.csv
results_v19_gis/REAL_GIS_27_SCENARIOS.csv       # exactly 324 actual score rows
results_v19_gis/V19_ACS_MOE_STRESS_ENVELOPES.csv
results_v19/SYSTEMS_THEORY_EMPIRICAL_TESTS.csv
figures/v19_real_gis_atlas/figure_manifest.json  # ≥10 rendered empirical figures and hashes
paper_v19_official_gis/V19_EMPIRICAL_YOUTH_CITY_NETWORK_RESEARCH.tex
paper_v19_official_gis/V19_EMPIRICAL_YOUTH_CITY_NETWORK_RESEARCH.pdf
qa_v19/final_release_audit.json
```

The final response of a subsequently executing AI must report **not only downloadable filenames but actually observed n=12, exact champion and score, most influential revision, robustness conditions, published MOE stress envelopes, systems tests and actual SHA256 evidence**. If official originals or OSM graph evidence are absent, output the exact acquisition/coverage blockers and all legitimate existing research outputs. Never change the fixed scoring definitions or sample secretly to force a desired champion.

## 12. Professional engineering: frozen environment, defensive execution, and reproducibility

The delivered code includes `requirements_v19.txt`, conda-forge `environment.yml`, cross-platform launchers, `Dockerfile`, unit tests, a source attestation template and a separate release auditor. Record the actual execution environment with `python -V`, installed package versions, Pyrosm/OSMnx version, GDAL/PROJ version, `dot -V`, `latexmk -v`, operating system, and actual source URLs and retrieval times; for reproducibility freeze dependency versions and model config at run time. Never silently change an old source hash: any new download or corrected code requires a fresh run ID and score refresh.

The official acquisition module requires the `all_pass` gate for *all 28 official originals* including source origin and real schema. The B28002 variable is corrected from any-internet `E002` to broadband `E004`. V19 score and PDF must be computed from actual 2024 raw bytes; no earlier rankings may be carried forward by renaming CSVs.

No external credentials, Census API keys, private institutional assets or copyrighted images are bundled. Optional public-data endpoints are not proof of retrieval. Protect large-file downloads with bounded retries and disk checks, respect human/supplier usage terms and preserve original source notice and OSM ODbL attribution. If a legally obtained proprietary access dataset cannot be redistributed, archive its metadata, original SHA and a permitted recreation route rather than unlawfully redistributing the byte stream.

## 13. Independent release gates, manual peer critique and explicit no-success shortcuts

- **RG-01 Originality**: precisely 28 actual 2024 official Census original files or explicit human-attested copies, all byte SHA256 + schema and 12-city GEOID checks passed. A 12-row scraped CSV is insufficient.
- **RG-02 Geometry**: official 2024 city/tract shapefiles intersect with expected GEOIDs; age 15–17 tract proxy coverage and area interpolation included, not hidden.
- **RG-03 Walking route**: all 12 actual graph files and raw source caches/PBF with SHA; roads are connected enough to reach sampled facilities and graph monotonicity/snap validated. Straight line is never titled a travel-time isochrone.
- **RG-04 Score**: actual `FINAL_12_CITY_REAL_GIS_RANKING.csv` has 12 unique geoid rows, no invalid scores, one stable complete M1 rank permutation and explicit conditional reference champion.
- **RG-05 Systems evidence**: actual 8-principle hypothesis registry, including honestly unidentifiable dynamics/self-organization, measured cross-border spillovers and tract equity.
- **RG-06 Statistical evidence**: actual 27 scenarios, 324 rows, marginal ACS MOE stress endpoints, direction and denominator consistency, independent negative results when applicable.
- **RG-07 Visual evidence**: ten source-backed atlas figures and hash manifest, with accurate geographic CRS and legend; paper uses authentic maps, not aesthetics in lieu of data.
- **RG-08 English argument**: numbered formulas in narrative, justified data choices, M0→M1 revision, complete 12-city conclusions, model sensitivity, genuine limitations, citations, one-page summary, 1–2 page lay article, compiled final PDF.
- **RG-09 Independent code replay**: at least two computational paths or clean-environment rerun of scores, plus file checksum comparison. Unit tests cannot substitute actual source audit.
- **RG-10 Human review**: source provenance and scientific construct validity, licensing, map accuracy, potential eligibility issues and writing claims checked by a real reviewer; no “simulated peer review” signed as an actual outside expert.

Only RG-01–RG-09 machine verifiability plus final human review can justify calling the completed PDF a release-quality **independent paper**. `qa_v19/final_release_audit.json` may say `TECHNICAL_PRECHECK_PASS_HUMAN_SCIENCE_REVIEW_PENDING` after actual machine checks. It may not say peer-reviewed, official COMAP-approved, uploaded or accepted when those things did not happen.

### Verified scholarly/technical entrypoints (consult actual version and license before executing)

- Census 2024 ACS Table-Based Summary File and user guide: https://www.census.gov/programs-surveys/acs/data/summary-file.2024.html ; https://www.census.gov/programs-surveys/acs/data/summary-file/getting-started.html
- Census 2024 original table directory: https://www2.census.gov/programs-surveys/acs/summary_file/2024/table-based-SF/data/5YRData/
- Census 2024 TIGER/Line place, tract and county-road file interface: https://www.census.gov/geographies/mapping-files/time-series/geo/tiger-line-file.2024.html
- ACS B28002 variable and annotation definition: https://api.census.gov/data/2024/acs/acs5/groups/B28002.html
- OpenStreetMap contributor license and attribution: https://www.openstreetmap.org/copyright
- Geofabrik United States source directory and state extracts: https://download.geofabrik.de/north-america/us.html
- OSMnx 2 API: https://osmnx.readthedocs.io/
- Pyrosm PBF network parser and download methods: https://pyrosm.readthedocs.io/en/latest/reference.html ; https://pyrosm.readthedocs.io/en/latest/downloading_data.html
- Optional independent site validation: IMLS PLS https://www.imls.gov/research-evaluation/surveys/public-libraries-survey-pls ; NCES CCD https://nces.ed.gov/ccd/files.asp ; ParkServe https://www.tpl.org/park-data-downloads

**Final document metadata:** `V19_OPERATIONAL_DIRECTIVE_PREPARED` — independent 12-city research, official-byte/GIS mandatory data gates, cross-platform reproducible source. Requires future real execution to become `V19_EMPIRICAL_GIS_RESEARCH_COMPLETE`.

---

# 15 — V19.2 OFFICIAL OPTIONAL PAPER LAYOUT INTEGRATION / 论文结构、短文件与参考文献终版门禁

> **增量版本：V19.2（2026-11-07）。** 本章专门落实用户提供的官方 `Optional Paper Layout` 原文。它不改变 V19 的真实数据、数学、GIS、系统论、科研绘图和发布硬闸；它只把正式论文的组织顺序、短文件归档、参考文献和PDF版式变成可执行合同。
>
> **官方原文的关键限定词是 Optional。** 官方说明完整解答“may be organized as follows”，并明确允许团队根据解法和表达方式调整。因此本项目选择严格采用推荐顺序作为默认排版，不把“Optional Paper Layout”错误升级为另一条不可调整的独立竞赛规则。若题目本身或当届规则要求不同，先服从题目/当届规则并记录理由。

## 15.0 官方原文（用户提供，按原文保留）

> Optional Paper Layout. In general, a complete solution submission may be organized as follows. Teams are welcome to adjust their submission format to meet the needs of their solution method and communication style.
>
> - Summary Sheet – Write this summary after you have done all your work. This one-page summary is Page #1 of your solution document. It provides an overview of your work, including the problem, your approach, and actual results.
> - Table of Contents – List the major items in your solution document to show the organization of your paper.
> - Introduction and Restatement of the Problem – Introduce the problem. Restate the problem and requirements in your own words.
> - Assumptions with Justifications – State any assumptions you made to simplify and solve the problem and state why you made those assumptions.
> - Presentation of Model and Solution – Ensure you address all requirements and describe what you are doing in solving the problem. Show and explain all your work, especially the model you created or selected and why. How it was applied. Use representations that help you tell the reader how you solved the problem (for example: equations, tables, graphs, pictures, etc.).
> - Analysis of Your Work – Describe the implication of your work. Perform a sensitivity, which means to adjust or remove an assumption to see its impact on the result. Address any strengths (good points) and limitations (weaknesses) of your model and solution.
> - Concluding Paragraph – End your solution paper with a final concluding paragraph that summarizes your results and/or makes recommendations for future work.
> - Include all 1-2 page documents and memos, if not already included earlier.
> - Reference List – List any sources that you used to solve the problem (for example: websites, AI tools, scientific, newspaper or magazine articles, etc.).

## 15.1 唯一默认论文顺序

V19.2 生成的英文论文必须按以下顺序组织：

1. **Summary Sheet** — 一页，PDF第1页。必须在全部工作完成后最后撰写，内容概括问题、方法和真实结果。
2. **Table of Contents** — 紧接Summary Sheet，PDF第2页开始；目录可占一页以上，页码必须来自最终编译结果。
3. **Introduction and Restatement of the Problem** — 介绍问题，并用作者自己的语言重述题目及要求。
4. **Assumptions with Justifications** — 逐项列出假设及采用理由；每项假设还须说明其影响、边界和对应敏感性/反证测试。
5. **Presentation of Model and Solution** — 完整呈现数据、模型、数学公式、求解步骤、应用过程、实际结果、表格、地图和图形；不得只介绍工具而不回答题目。
6. **Analysis of Your Work** — 解释结果含义，开展敏感性分析，说明调整或移除假设后的影响，并讨论模型优势与局限。
7. **Concluding Paragraph** — 以一个清晰的最终结论段落收束主解答，概括结果并提出有证据边界的未来工作建议。
8. **Supplementary 1–2 Page Documents and Memos** — 所有未在前文纳入的1–2页文件/备忘录集中放置。A题要求的非技术新闻稿作为第一份补充文件；其他必要短文件不得遗漏。
9. **Reference List** — 参考文献是主论文的最后一个主要章节，列出实际使用过的全部来源。

不得增加独立封面页而把Summary Sheet推到第2页；Summary Sheet必须是整份解答PDF的第一页。若Summary Sheet内容溢出，必须压缩或重写摘要，而不能把溢出部分当作正文继续占页。

## 15.2 Summary Sheet事实合同

Summary Sheet必须在所有模型、排名、稳健性和限制分析完成之后生成。它必须从冻结的最终结果对象读取事实，至少包括：

- **Problem**：研究的问题、年龄范围及城市比较对象；
- **Approach**：真实数据来源、M0→M1实质性修订及核心计算机制；
- **Actual results**：实际城市数量、真实冠军、得分、关键名次变化和实际敏感性结果；
- **Conclusion and limits**：冠军适用的条件、重要限制及不可声称的因果结论。

所有数值必须由同一个冻结的`FINAL_12_CITY_REAL_GIS_RANKING.csv`、场景结果和证据清单生成；Summary、正文、新闻稿不得人工重抄并各自维护不同数字。没有真实最终排名时，不生成含虚构冠军的Summary；论文生成器应继续保持`BLOCKED_FOR_FINAL_GIS_PAPER`。

## 15.3 Assumptions with Justifications 必须独立成章

V19.2 将假设从零散的模型说明中抽出，独立形成A1–A10表。每行至少包含：`Assumption ID / Assumption / Why it is reasonable / Consequence and test`。默认覆盖：

- 预先冻结的12城目的性样本及其外推限制；
- ACS 15–17岁作为14–18岁目标的代理；
- tract与市界相交时的人口面积加权近似；
- 步行速度和10/20/30分钟时间阈值；
- 路网快照时间与ACS年份不一致；
- 图书馆、公园点位仅是候选机会，不等于准入/开放/安全；
- M0固定归一化锚点及维度权重；
- M1城市条件、机会、图书馆/公园、均值/低分位的偏好权重；
- 不虚构学校录取资格、设施容量或实际参与概率；
- 横截面数据不能识别长期稳定性、内生自组织或因果福利。

假设值应从`config_v19/reference_model_v19.json`读取，而不是在论文生成器中另写一套数值。对可扰动假设，必须链接到实际执行的敏感性结果；不能扰动的假设应解释为什么当前数据不能检验。

## 15.4 Presentation of Model and Solution 的内容边界

该章将数据与模型组织成一条连续的解题论证：

1. 原始数据、版本、时间、空间口径、SHA256及质量筛查；
2. Census/TIGER与OSM真实空间对象的连接方式；
3. M0基线定义、归一化、权重和单位；
4. M1网络可达性、人口加权、设施类型和公平项的数学定义与推导；
5. Austin真实GIS案例和必要的其他实证案例；
6. 12城完整实际排名、分数和M0/M1对照；
7. 关键公式的适用条件、计算步骤、性质测试和结果解释。

不能将研究工程说明、依赖安装清单、GitHub仓库列表或概念系统图替代实际求解。每个定量主张仍必须回溯到原始文件、计算run、代码版本、表格和图形。

## 15.5 Analysis of Your Work 必须同时报告正反证据

本章至少包括：

- 为什么M0不足、M1究竟改变了什么，以及是否有实证证据支持此次修订；
- 算法验证、独立数值复算、空间与数据质量验证之间的区别；
- 真实运行的27组情景、ACS MOE压力区间及模型结构/路网误差；
- 系统论原则中哪些被实际计算检验，哪些因缺少纵向或个体数据而不可识别；
- 模型优势、数据优势、适用边界和主要弱点；
- 负结果、冠军翻转条件和不能从横截面排名推断的事项；
- 实际使用的AI工具和软件的透明披露。

不得把情景频率写成置信概率或公众偏好；不得把“可达机会”写成实际参加、学校录取或因果改善。

## 15.6 Concluding Paragraph 必须是主解答的最后一个结论段

主解答以一个结论段落结束。它应当：

- 明确指出在冻结条件下的实际排名结论；
- 解释这个结论适用于哪些样本、指标、年份和偏好；
- 指出最重要的限制；
- 提出下一步最有价值的实证工作。

不要在结论之后继续添加新的主模型、主要结果或一串没有层级的未来工作清单。补充新闻稿/备忘录属于官方布局中的独立短文件，放在结论之后、参考文献之前。

## 15.7 所有1–2页文件和备忘录的注册机制

新增目录：`paper_supplemental/`，主清单：`paper_supplemental/manifest.json`。

- 自动生成的`Nontechnical News Article`是第一份补充文件；
- 任何其他尚未在主文中纳入的1–2页文件或memo，必须保存为`.tex`并在manifest中登记`id,title,path,pages_min=1,pages_max=2`；
- 未登记的`.tex`文件会阻止论文编译，避免遗漏；
- 生成PDF后，逐份核验其实际页数必须为1或2页；
- 所有补充文件都必须位于最终Reference List之前。

如果某份memo已经在正文完整纳入，则不得再重复插入；清单需说明其已在正文中，不重复计页。当前默认manifest为空，因为除自动新闻稿外尚无其他已确认必须插入的独立memo；后续执行时如产生，必须登记。

## 15.8 Reference List 必须是最后一个主要章节

Reference List列出实际使用的来源，不按类别机械凑数。根据实际使用情况包括：

- 官方数据集和政府网站（Census ACS、TIGER等）；
- OSM/Geofabrik等实际使用的地图与数据服务；
- 学术论文、理论著作、方法手册；
- 实际运行的软件/程序文档；
- 实际使用的AI工具及其模型/版本、访问日期和用途；
- 若真正引用过新闻或杂志文章，则列入；未使用则不虚构。

新增`sources/ai_tool_use_ledger.csv`记录本项目已发生的AI工具使用；新增`sources/additional_references.csv`记录实际使用的其他网站、数据集、学术论文、新闻或杂志来源。未来执行者必须将新增AI工具、模型、版本、用途、日期及其他实际来源继续登记；未实际使用的候选来源不得进入Reference List。AI工具在Reference List中的引用不取代单独的AI使用披露；若适用的当届竞赛政策要求单独AI报告，应作为独立合规附件处理，不得把它伪装成主论文的References章节。

Reference List之后不得再出现新的主论文章节。若赛事另要求AI合规报告，该报告属于独立合规材料，不改变主论文以Reference List结束的结构。

## 15.9 V19.2代码与自动版式验收

新增/修改以下文件：

- `code_v19/paper_layout_contract.py`：同时检查TeX源结构与编译PDF；
- `code_v19/build_empirical_gis_paper.py`：按官方可选布局重新组织论文，生成Summary Sheet、TOC、Assumptions表、模型与结果、Analysis、单段Conclusion、新闻稿/补充文件和最终Reference List；
- `code_v19/release_audit.py`：将版式验收加入正式发布门禁，且检查审计收据与PDF SHA256一致；
- `code_v19/package_evidence.py`：把补充文件清单、AI工具账本和版式审计收据纳入复现包；
- `tests_v19/test_official_paper_layout.py`：对第一页、目录起始页、章节顺序、补充文件页数、参考文献位置进行合成PDF测试。

PDF自动门禁至少要求：

1. PDF第1页是唯一一页Summary Sheet，包含Problem/Approach/Actual results；
2. Table of Contents从PDF第2页开始；
3. 主要章节按上述顺序出现，允许两个章节标题在同一物理页，但不允许逻辑顺序颠倒；
4. 主结论是一个最终段落，之后才进入补充文件；
5. 每份补充文件实际占1–2页；
6. Reference List为TeX源中的最后一个主要章节；
7. PDF页数满足本项目另行核验的页数门禁；
8. TeX结构审计与PDF审计均通过，且收据SHA256绑定最终PDF。

**当前V19.2实际验证边界：** 使用合成PDF fixture完成了版式审计器测试，并对论文生成器进行了隔离的合成数据TeX smoke build；该临时目录已删除，绝不作为城市研究结果或正式论文交付。V19专属离线测试通过，说明相关代码与门禁通过合成测试；不表示Census原始数据、OSM路网或12城实证已经完成。

## 15.10 V19.2执行命令与发布状态

离线测试命令：

```bash
PYTHONPATH=code_v19 python -m pytest -q tests_v19
```

实际论文仍只能通过原V19完整流水线生成。任何Census、TIGER、OSM、GIS、独立复算或敏感性阶段失败，论文仍为`BLOCKED_FOR_FINAL_GIS_PAPER`；版式门禁不得绕过上游实证门禁。

V19.2状态：`OFFICIAL_OPTIONAL_LAYOUT_IMPLEMENTED_AND_SYNTHETICALLY_TESTED / EMPIRICAL_PAPER_NOT_EXECUTED`。

## 16 — V19 P0/P1 EVIDENCE-AND-VALIDITY REPAIR (AUTHORITATIVE ADDENDUM)

## 16 — V19 P0/P1 EVIDENCE-AND-VALIDITY REPAIR (AUTHORITATIVE ADDENDUM)

> **Authoritative correction to inherited directives (2026-11-09).** This V19-only source tree is the entire current research engine. Every existing rule above remains useful unless contradicted by the stricter empirical science and file contracts in this section. Version labels in the inherited narrative are historical context only; at runtime only `code_v19`, `tests_v19`, `config_v19`, `qa_v19` and `V19_*` output names are authoritative. No V11–V16 source folders or archives are required or included. This is a complete *runnable engineering source package*, not a claim that twelve-city public downloads or final GIS scores have already occurred.

### 16.1 Non-negotiable research identities and scientific truth

- Study: 2026 HiMCM Problem A; twelve fixed US incorporated places: Austin, Boston, Chicago, Denver, Madison, Minneapolis, Pittsburgh, Portland OR, Raleigh, San Diego, Seattle, Atlanta. Every place GEOID is a seven-character STRING, not an integer.
- Evidence: Four official 2024 ACS 5y table-based SF `.dat` originals (`B01001`, `B25070`, `B28002`, `B17001`), twelve 2024 TIGER PLACE ZIPs and twelve 2024 TIGER TRACT ZIPs (total **28 actual originals**), and twelve REAL OSM walkable graph assets each traceable to hashed original Overpass JSON or state-level Geofabrik OSM PBF. Add IMLS FY2024 official outlet ZIP as independent verification and original COMAP summary template `.tex`.
- Census original SHA256 computed from actual bytes is a *local integrity and reproducibility fingerprint*, not publisher certification unless a published Census digest independently matches. Preserve official URL and TLS evidence; manually imported copies need separate human source attestation and should never be relabeled as direct publisher transfer.
- Geographic analysis is network-derived and sourced; TIGER ROADS is a secondary roads geometry crosscheck only, not validated pedestrian legality. Do not call park polygon representative points actual gates or inferred opportunities actual participation.
- `code_v19/run_v19.py --stage all --network auto` is the only all-stage orchestrator. It fails closed. Dry Run is not a successful research execution. Human can re-run after failed downloads and source validation.

### 16.2 P0-01/02: Mandatory dataset and full research-output gates

The rank gate MUST find 28 verified federal originals + appropriate age & geometry rows in the source files, plus 12 verified walked network graphs, verified raw OSM source bytes, and all source-recorded city/geography/POI/OD files. Disallow missing, zero-filled, copied historic final rankings, synthetic roads or maps. A source success requires file existence, valid structure, exact local SHA256, provenance, vintage, all 12 expected FIPS/GEOIDs, and quality checks.

The published machine result is `results_v19_gis/FINAL_12_CITY_REAL_GIS_RANKING.csv`, with exactly twelve distinct place GEOIDs and proper rank permutation. Other outputs (scenarios, figures, paper) MUST derive from the same frozen run. If any real original, route, downstream test or human-required attestation fails: `BLOCKED_FOR_FINAL_GIS_PAPER`. Do not export a fake champion. All 30 stages must exit zero and final release audit must explicitly authorize machine precheck before a PDF can be described as technically checked. Human peer review and COMAP registration are distinct.

### 16.3 P0-03: Controlled model revision that isolates *mechanisms*

The inherited household-context M0 does **not** include a facility inventory; its addition to M1 is both new data and a new spatial mechanism. Never call `M0 → M1` itself a causal proof that pedestrian routes outperform inventory. V19 introduces an explicit **same-facility-set counterfactual ladder** with source-aligned OSM entities and fixed denominators:

1. `M0_household` — Census rent-burden, poverty, broadband, no facilities (diagnostic only).
2. `P0_facility_inventory` — actual candidate counts for library/park facilities over the fixed study geography and administrative buffer; does not imply eligibility.
3. `P1_geodesic_proxy` — **the same eligible/candidate facility set** using geometric straight-line proxy; NOT a walking-route estimate.
4. `P2_directed_network` — same facilities, actual directed OSM network paths and travel kernel, same city/tract and population weights.
5. `P3_network_spatial_equity` — adds frozen population-weighted lower-decile fairness to the same network access.
6. `P4_unknown_access_upper` — explicit counterfactual *unknown facilities may be usable* upper bound, not the reference and not a verified observed improvement.

The controlling file is `code_v19/model_ablation.py`, output `V19_CONTROLLED_ABLATION.csv`. The paper must state *what changed at each step* and show real differences; do not falsely infer better predictive validity from a ranking change. Population/eligibility/network/fairness are compared only where original observations support the comparison. Methodology improvement needs an independent comparator; otherwise report `MECHANISM_ISOLATED / EXTERNAL_MERIT_NOT_ESTABLISHED`.

### 16.4 P0-04: Unknown facility access is a two-sided, NOT one-sided measurement

`code_v19/access_policy.py` is a shared policy for Overpass and PBF routes. `access=private/no/...` is `RESTRICTED`, `access=yes/public/permissive` or comparable explicitly tagged facility is `OSM_TAGGED_PUBLIC`, and everything with no trustworthy access tag or ambiguous tags is `UNKNOWN`. Reference opportunity **never silently accepts UNKNOWN**. Present lower (= observed OSM public-tagged candidates) and optimistic upper (= lower + unknown) as a reproducible **assumption interval**; `OSM_TAGGED_PUBLIC` itself is not legally authoritative admission, school eligibility or opening hours. If intervals are large enough to change policy ranking, describe the conditionality. Original POI tags, OSM IDs, coordinate provenance, duplicate checks and candidate admission classification go into traceable per-city files.

### 16.5 P0-05 / P1-10: Independent GIS reconstruction, not rerunning a derived score CSV

`code_v19/replay_raw_network.py` re-parses original Overpass ways/nodes or the original Geofabrik PBF into a separate actual directed graph, then independently recomputes source-based shortest paths for geographically stratified origin–destination pairs and compares against production OD records. Record number checked, discrepancy thresholds, disconnected paths, node IDs, graph version, and result hash. If parser differences or distances are scientifically irreconcilable, FAIL. The runtime gate also requires IMLS FY2024 outlet-to-OSM one-to-one spatial matching (`external_imls_validation.py`) as an **independent facility-coverage diagnostic**. Match rate does not demonstrate legal access or actual youth outcomes. `edge_failure_stress.py` checks an explicit sampled network link-removal scenario; it is **not** a complete twelve-city rank recalculation.

### 16.6 P0-06: Official summary, paper-length limits and separate AI use disclosure

A valid paper run must download the **original** `HiMCM-MidMCM_Summary.tex` from COMAP's own host (or receive a separately human-attested publisher original), save its exact byte SHA256, compile a derived one-page Summary using that source's preamble and the **actual scored claims**, and splice it as solution PDF page 1. Without original official TeX do not claim template compliance. Real team number only when provided; for the independent research, label **Not Registered** rather than inventing a number.

The remaining solution follows the user's official *Optional Paper Layout*: Table of Contents, Introduction and Restatement, Assumptions and Justifications, Presentation of Model and Solution, Analysis of Your Work (sensitivity and strengths/limits), final Concluding Paragraph, 1–2-page news article and any registered memos, Reference List. Preserve one-page Summary and ≤25 pages for the solution in the competition-shaped technical preflight. Typesetting at 12pt class is not enough: verify real output page spans and figure/text legibility, rejecting microscopic table/axis text. Use the *actual* AI tool and prompt log in `sources/`, human-confirmed prompt provenance including genuinely lost prompts marked as such; compile a separate **Report on Use of AI Tools** after the ≤25-page solution and record different solution vs combined hashes. Never invent previous prompts, external reviewers or contest approval.

### 16.7 P0-07: Evidence-generated prose, independent research gate

`code_v19/paper_claims.py` is executed only after the final real ranking, ablation table, original-OSM independent replay receipt, IMLS comparison, and constrained-weight robust preferences exist. It writes `research/v19_claim_evidence_registry.csv`, `research/v19_equation_contracts.csv`, an evidence-linked narrative LaTeX section and its SHA256 receipt. Each claimed result must take the form **Claim → observed source and units → exact computation → actual result → counterexample/negative evidence → inference boundary**, explicitly cite its model version and original source SHA. Human scholarly editing is still required; source-generated sentences are not a guarantee of O-Award quality. Never let a paper template with blanks substitute for actual result evidence.

### 16.8 P1-01/02/03/04/05: Public service evidence and honest target-age GIS

- IMLS FY2024 original library outlet ZIP is mandatory as an external audit, including ZIP SHA, file member and true outlet coordinates; its system records must not be counted as independent libraries. The `IMLS` comparator operates at outlet and OSM candidate entity grain, not individual verified admission.
- NCES/EDGE schools, ParkServe and official city park directories remain **discovery/conditional validation inputs**. Do not silently score school presence as a guaranteed school seat, or a school district as admission. If stable, comparable original data/eligibility are available, extend frozen experimental branches with a new run ID; otherwise preserve `NOT_MODELED_DUE_TO_ELIGIBILITY_OR_COVERAGE` and describe the consequence. Do NOT claim these optional full modules are already installed.
- Census age 15–17 estimate remains a proxy for the 14–18 question. Without comparable single-age location observations, no algorithm may claim exact 14–18 residents; record age proxy uncertainty separately.
- TIGER tract partial-overlap weights and one representative origin per tract are *spatial approximations*, not real home addresses; evaluate consistency vs city-level population controls, MAUP and residential-weight spatial alternatives only when legitimate underlying data exist.
- Candidate POI snaps to walked graph node, 1.25 m/s frozen base and varied speeds/edge removal; pedestrian bridge, access law and park entrance are not fully observed. Show 10/20/30-minute reached **network corridors** rather than claiming validated walkable isochrone polygons unless actual reachable polygon algorithm and entrance validation exists.

### 16.9 P1-07/08/09: Five sensitivity axes + exact preference theory

1. **Normative preferences**: official 27 scenario matrix = 3 travel-time cutoffs × 3 ACS share weights × 3 equity weights, 324 actual city-score records. It is a finite declared grid, not a preference distribution.
2. **Sampling and measurement**: real 2024 ACS E/M published MOE endpoint stress; distinguish marginal MOEs, unknown covariance and conservative envelopes from true joint 90% confidence intervals.
3. **GIS and access stress**: 18 actual OD-based city rerankings (3 walk speeds × 3 *hypothetical* feature missing rates × 2 eligibility assumptions). Include scored cases of OSM unknown lower/upper and actual edge dropout on stratified OD sample; none of these hypothetical missing percentages may be represented as independently observed error rates.
4. **Structural and model revision**: same facility inventory vs geodesic proxy vs directed network vs equity, non-compensatory holism comparison, with outputs from the exact same frozen source corpus.
5. **Temporal and geographic**: check 12 cities' OSM acquisition times and mixed-vintage ACS, compare years/city or spatial origin only if verified compatible observations are acquired; if not, explicitly mark cross-year stability and national representativeness **NOT_IDENTIFIABLE**, not PASS.

`robustness_lp.py` computes Pareto non-dominated city set, worst-case preference region via constrained LP over weights, and maximum regret. Its pre-specified 6-dimensional utility vector and admissible polytope must be documented; robust-first is only within that mathematical set. Simple stochastic rank frequencies are not frequentist probabilities of the true preferred city. Dynamic feedback, youth-club self-organization, or welfare causation are **not identifiable** without genuinely observed panel/participation evidence.

### 16.10 P1-11/12/13/14/15/16: Scientific figures, formula contracts and reproducibility

The figure system creates twelve actual city-level network/tract panels (`render_city_atlas_v19.py`), a research atlas with ≥10 evidence-backed maps/plots, and source-bonded SHA256 figure manifest. Only authentic TIGER polygons and OSM nodes/ways/POIs may be used in geo maps. Publicity-grade but unverifiable renderings are prohibited. Add original sources and graphics in reference/bibliography and use the *smallest* set of informative figures in the ≤25-page main text.

Maintain traceable `V19` claim–source–calculation–figure–paper and equation–proof–test–actual-result registries. Every displayed rank and number must be traceable to machine result files. Dependent software must log actual environment: Python, GIS packages, PROJ/GDAL, Graphviz and LaTeX, and packages at the moment of actual execution. Dependencies in requirements are **ranged but not locked** in this package; a real execution environment must generate a pinned per-run lock/provenance receipt and compare on an independent machine, if claiming clean reproducibility. Do not claim cross-platform live GIS tested merely because pure Python pytest passes. Clean V19 maintains no V11–V16 code/runtime dependency, no inherited old rankings or old maps.

### 16.11 Full phase order, machine release and human review

The 30-stage single-command orchestrator's stages are:
`tests → environment → official_summary → census → geography → networks → osm_temporal → score → audit → independent_replay → raw_network_replay → controlled_ablation → sensitivity → uncertainty → evidence_frontier → systems → external_imls → robustness_lp → preference_paths → route_stress → edge_failure → figures → atlas → multicity_maps → decision_figures → evidence_review → decision_gate → paper → release → package`.

If original real data are missing, output a real failure receipt and exact missing files. A failed stage must NOT create a fake success CSV or PDF. Runtime receipt `qa_v19/v19_execution_state.json` records the truth. Any future technical release means only **machine tests/real data check passed; human scientific review pending** unless an actual human reviewer certifies its full scientific adequacy. Authoring/reading the MD does not execute its stages.

**Exactly four independently assessable releases:** (A) this source-only V19 reproducible engine, (B) future frozen Census/OSM original source-and-hash manifest, (C) future true network/12-city numerical results atlas, (D) future real study PDF and TeX plus AI appendix. The current delivery has only (A). B–D may be generated only when all their actual prerequisites exist.

### 16.12 Acceptance crosswalk

The tracked obligation register is `V19_QUALITY_GATES.csv` and the full original source/provenance evidence contracts in this master. All P0/P1 defects are coded as `CODE_IMPLEMENTED_OFFLINE_TESTED`, `IMPLEMENTED_CONDITIONAL_REQUIRES_REAL_SOURCE`, `NOT_IMPLEMENTED_OPTIONAL_OR_NOT_IDENTIFIABLE`, or `BLOCKED_NO_REAL_INPUT`, *never* a blanket `DONE`. Source-independent mathematical test status does not certify any city result. After live human execution, rerun acceptance matrix based on actual machine receipts and real science review.

**Scientific quality criterion:** every mathematical result must have grounded data; every graphical result must be regenerable from original bytes; every section must answer the problem; every unavailable observation must be stated as such. Formal submission is a future outcome, not a label assigned by this source-only package.

---

# V19 PRIORITY OVERRIDE — EVIDENCE HORIZON AND DECISION-BOUNDARY UPGRADE

> **Binding release:** This section supersedes prior details in this file only where it adds a stricter V19 evidence gate. The core twelve-city sample, original Census/OSM acquisition, fixed M0/M1 score, same-facility ablation, systems-theory structure, official paper layout and release conditions remain unchanged. This section never imports another team's data, code or contest answer. Source-only state: **V19_CODE_PREPARED_EMPIRICAL_NOT_RUN**.

## V19.1 Research originality and protected model core

We are studying original municipal measurements and the geographic transformation of amenities into potentially accessible opportunities. V19 is an independent empirical GIS inquiry, not an adaptation of a competitor's globally mixed city-ranking paper. Its only valid research core remains:

`28 authenticated official Census originals → 12 real OSM walk networks → 12-city fixed-score real-GIS comparison → independent routing and uncertainty QA → systems-science falsification → full English research manuscript`.

The comparative provenance and our independent transformation are documented in `research/V19_TRANSFER_AND_DIFFERENTIATION.md`. We reviewed general methodological ideas about evidence uncertainty, prioritizing verification, preference dependence, and claim-specific writing; we did **not** copy any external paper's prose, code, values, figures, global city sample, weight matrix, TOPSIS/VIKOR scoring architecture or incomplete-data results. Mathematical concepts that are established in the literature should be cited as established rather than misrepresented as new inventions.

## V19.2 Two-layer scientific interpretation

The first layer is the **unchanged observed-data reference** $M_1(c)$ and the actual same-facility mechanism decomposition. The second layer is a *decision evidence audit*, not a competing final scoring model. It must never overwrite `FINAL_12_CITY_REAL_GIS_RANKING.csv`, reselect the twelve cities by their performance or invent missing values.

### V19.2.1 Evidence outer horizon, not joint probability

For city $c$, let $H_c$ be the household-context score in $[0,100]$, $L^H_c,U^H_c$ the source-grounded 2024 ACS marginal-MOE endpoint **stress** values, $Y_c$ the network opportunity component under OSM-tagged-public reference, and $Y_c^+$ the additional upper-bound result when unverified access is hypothetically granted. The frozen normative weights still satisfy $0.60+0.40=1$:

\[
S^{\rm ref}_c = 0.60 H_c + Y_c,
\quad\underline S_c=0.60 L^H_c+Y_c,
\quad\overline S_c=0.60 U^H_c+Y_c^+.
\]

Here $Y_c\in[0,40]$ already contains the $40\times$ share of weighted access; its upper extension is **not** an additional bonus. The permitted outer envelope is $[\underline S_c,\overline S_c]$. It intentionally lets ACS and unknown-access components vary independently, and may be wider than any realizable simultaneous observation. **It is neither a joint 90% confidence region nor an empirical posterior.**

Define only logically supportable labels:

- Sufficient elimination: $\overline S_c < \max_{j\ne c}\underline S_j$ (under declared outer bounds).
- Sufficient single-winner certification: $\underline S_c > \max_{j\ne c}\overline S_j$ (under declared outer bounds).
- Otherwise, `NOT_EXCLUDED_BY_OUTER_BOUND`, which is **not** a proof of realistic simultaneous feasibility or of being objectively best.

The actual executable is `code_v19/evidence_frontier.py`. It reads *actual* `FINAL_12_CITY_REAL_GIS_RANKING.csv`, `V19_ACS_MOE_STRESS_ENVELOPES.csv`, and `V19_CONTROLLED_ABLATION.csv`. It validates the same GEOID set, exact reference identity, bounds, 0–100 domains, and scores; it refuses to produce any result before the original Census/GIS audit.

### V19.2.2 Verification priority as conditional decision influence

`V19_TARGETED_EVIDENCE_QUEUE.csv` is a ranked set of 24 city-by-evidence-family suggestions (12 cities × 2 concrete families: ACS denominator/MOE and official access/entrance verification). It calculates the **maximum upper-score reduction conditional on returning a resolution equal to the reference**; it does not assume the result of a field visit, provide a survey sampling probability or claim a monetary expected return. Priority must not be used to skip the mandatory official 28 source files or 12 networks.

This is evidence-gathering triage. The absence of an affordable/available way to verify one site must be recorded as an unresolved constraint, never changed to a numerical zero or a fabricated positive answer.

## V19.3 Declarative household archetypes without surveys or change to M1

Write each reference city score as a six-component additive utility vector:

\[
 u_c=(u_{\text{rent}},u_{\text{poverty}},u_{\text{broadband}},
 u_{\text{library}},u_{\text{park}},u_{\text{lower decile}})_c.
\]

Our *actual frozen reference* $S_c^{\rm ref}=100\,w^{\!0}\cdot u_c$ has

\[
 w^{\!0}=(0.210,0.210,0.180,0.165,0.135,0.100),
\]

**derived programmatically** from `config_v19/reference_model_v19.json` and verified against the authoritative M1 column to numerical tolerance. We declare only three alternative **analyst-proposed hypothetical** household priorities (household continuity, nearby free public opportunity, safeguard of poorly served tracts). Each is a positive multiplier of $w^0$ followed by normalization. No teen survey or AHP elicitation is claimed. The original M1 rank remains the final reference; policy family winners are a separate sensitivity surface.

For each family weight vector $w^a$, analyze the entire affine preference path

\[
 w(t)=(1-t)w^0+t w^a,\qquad t\in[0,1].
\]

For each city-pair $i,j$, their score difference is an affine function of $t$. Solve all distinct pairwise line intersections analytically, partition $[0,1]$, and determine the first-place city on each open segment. Only genuine first-place transitions are reported; this avoids arbitrary grid discretization and does **not** convert a constructed preference domain to a population probability.

Executable: `code_v19/preference_paths.py`; outputs: `V19_DECLARED_PREFERENCE_FAMILIES.csv` (4×12), `V19_EXACT_LEADER_TRANSITIONS.csv` (dynamic number of leader segments), `V19_CROSS_FAMILY_MINIMAX_REGRET.csv` (12 rows). The family-level regret is a decision stress number over **four declared cases**, not a theorem over all possible preferences; the existing `robustness_lp.py` retains the exact six-dimensional polytope certificate.

## V19.4 Systems theory and evidence semantics

These additional decision tools make the existing systems-science interpretation more *falsifiable*: 

- **Openness/Hierarchy:** Cross-municipal service catchments and tract-level bottom-decile exposure stay tied to genuinely routed OSM streets and ACS tract proxies, not a country-level average.
- **Purpose:** Which families' priorities alter the city choice is a normative counterfactual; real adolescents' preferences remain unmeasured.
- **Holism/Constraints:** Unknown facility entry cannot be assumed open. The score upper bound shows how missing access evidence can alter the interpretation.
- **Stability versus robust choices:** Weight-space robustness, city sample robustness, parameter stability and longitudinal actual system stability are *different objects*. Only the first three can be evaluated by the current static data. Multi-year endogenous urban adjustment is **NOT IDENTIFIABLE** without real repeated states.
- **Feedback:** The research loop `measure → diagnose → identify decision-critical uncertainty → verify with new independent data → re-run` is real in the methodology; a causal feedback loop among cities/students is not established by a static map.

Explicitly distinguish sampling/measurement, normativity, city context, qualification and structural model uncertainty in all paper figure captions. A small rank-change number is not evidence of causal welfare validity.

## V19.5 New paper and figures are real-results gated

`code_v19/decision_atlas.py` generates two complete three-format source-bound scientific figures only after real data: 

- F18 Decision 01: twelve-city **outer evidence envelope** with the frozen reference marker and logical elimination labels. No 90% probability language.
- F18 Decision 02: four declared hypothetical household priority ranking columns. No implied student poll.

`code_v19/decision_evidence_review.py` generates the **V19 epistemic claim registry** and `V19_DECISION_EVIDENCE_ADDITIONS.tex` as a supplementary evidentiary subsection of the official `Analysis of Your Work`, not as a new main paper or appended independent ranking. It connects observed city results to source-hash references and reports one counterexample plus the failure boundary of each quantitative claim. `research/V19_EPISTEMIC_REVIEW_CONTRACT.csv` documents what evidence each argument needs and what it must not claim.

`code_v19/decision_release.py` is a **new mandatory release gate**. It checks the 12-row horizon, 24-row verification queue, 48 preference-family rows, genuine transition segments, 12-row family regret, exact hashes of source ranking/MOE/ablation/config, both figures in PDF/SVG/PNG with manifests, and the text/source evidence registry. Paper building and final release call this validator again. A fake or stale file name cannot replace actual original-source evidence.

**Official optional paper sequence remains:** one-page Summary Sheet (page 1), Table of Contents, Introduction/Restatement, justified assumptions, Presentation of Model/Solution, Analysis of Your Work (including V19 evidence uncertainty), concluding paragraph, actual 1–2-page requested news article/memos, and References; separate AI-use disclosure as genuinely applicable. We obey the official recommended structure by choice, not by misdescribing `Optional` as mandatory.

## V19.6 Expanded authoritative end-to-end pipeline

The **30 actual code stages** are:

`tests → environment → official_summary → census → geography → networks → osm_temporal → score → audit → independent_replay → raw_network_replay → controlled_ablation → sensitivity → uncertainty → evidence_frontier → systems → external_imls → robustness_lp → preference_paths → route_stress → edge_failure → figures → atlas → multicity_maps → decision_figures → evidence_review → decision_gate → paper → release → package`.

Start in the unzipped root with `python code_v19/run_v19.py --stage all --network auto`. The V19 extras **cannot** run before official raw-data and GIS passes; they therefore do not add fake analysis when the original data are unavailable.

**Success requires every original-source, model, reference/ablation, path, rank, Figure, manuscript, supplementary, AI-disclosure and human scholarship condition previously declared, plus all V19 addendum outputs.** There is no claim that this source-only package has downloaded the 28 original Census files, computed 12 real graphs or produced a real winner yet. Failure must provide the real exception and state `BLOCKED_FOR_FINAL_GIS_PAPER`, not a synthetic number or a promised future automatic result.

## V19.7 Finite handoff rather than uncontrolled feature growth

Do not expand the primary score beyond its two facility categories purely because another project uses ten indicators. Education/safety/environment may be developed as **independent, comparably acquired scope/construct-validity checks**, but their inclusion in the reference metric requires pre-registered scientific justification, synchronized twelve-city sources, entire pipeline rerun, and a new recorded model policy. Do not use V19 to change the winner after seeing it.

**The new standards are implemented as executable input-output contracts, not paper-writing slogans.** Future running agents must report observed data status, exact source hashes, 12-city frozen reference, exclusion/non-exclusion sets, verification priorities, leader-switch intervals, counterevidence and final paper audit separately. Without actual source data, the proper result remains `CODE_AUTHORED / REAL_EMPIRICAL_RUN_PENDING`.


## V19 Unified executable additions and full GIS atlas acceptance

The *sole* entrypoint is `python code_v19/run_v19.py --stage all --network auto`. The main runner owns 34 stages, including `algorithm_pilots`, `full_gis_atlas`, `gis_discussions`, and `drawio_gate`. There is no V18 runtime directory dependency. The complete science figure suite has three separate outputs: preserved 10+ analytic atlas figures, twelve original city-map PDFs/SVGs, and 24 distinct GIS thematic IDs with 12-city outputs for 21 city-level IDs and three cross-city comparative panels. City-level counterfactual plots are diagnostic pilot **sample points**; no sample map can be described as full-city policy optimization. The full GIS atlas registry only passes after every PDF exists and its SHA256 matches. Each of 24 GIS IDs has an independently enumerated source-bound explanatory chapter, with a human-science-interpretation checkpoint.

Draw.io architectural figures are actual editable `drawio/*.drawio` diagrams with typed labeled arrows; companion `drawio/exports/*.svg` and `*.pdf` were generated from identical DAG node/edge semantics. Eight diagrams are required by `v19_drawio_gate.py`. The existing reference M1 is never overwritten by algorithm pilots, and all original V18 GIS producer functionalities remain migrated under `code_v19/`.

**Verification boundary:** source-only unit tests and Draw.io parsing are performed in this delivery; twelve-city official-data acquisition, geospatial rendering, production LaTeX compilation, full release and human peer review are not exercised without real source bytes. `release_audit.py` must reject source-only archives.
