# Graph matrix consistency notice — frozen reference M1

For a directed graph G with n vertices and m edges, its directed incidence matrix B (n × m) has -1 at each tail and +1 at each head. A combinatorial B B^T is an undirected connectivity representation, **not** a directed shortest-path solver. Weighted Laplacians similarly do not capture shortest-path directionality or access permission.

Let D be the directed shortest-path distance operator in the min-plus semiring; D_RF=S_R D S_F^T is a conceptual OD submatrix. In execution, only the needed OD distances are materialized with exact truncated Dijkstra (forward origins / reverse facilities on reversed directed graph). Define K_gj=1{d_gj≤vT} exp[-d_gj/(vτ)] with consistent distance/time units. For category membership C_jk and public-access diagonal Y, let A=KYC. The **original M1 opportunity** is

\[ a_g=0.55\bigl(1-e^{-A_{g,L}/2}\bigr)+0.45\bigl(1-e^{-A_{g,P}/2}\bigr). \]

This is not a linear combination KYCλ. With youth population p_g, μ=∑_g p_g a_g/∑p_g and weighted lower 10th-percentile Q10, the frozen M1 score remains M1=0.6M0+40(0.75μ+0.25Q10).

For hypothetical fixed-capacity candidate sites c, let a^0_{gk} be frozen raw category opportunity and k_gc≥0 be routed contributions. For fixed w_g≥0 and increasing concave saturation φ(x)=1-exp(-x/2), F(S)=∑_g w_g[φ(a^0_g+∑_{c∈S}k_gc)-φ(a^0_g)] is monotone submodular. A cardinality-only budget allows classical 1−1/e greedy approximation; this guarantee does not extend automatically to nonmonotone objectives, dynamic CVaR weights, or arbitrary deployment constraints.

For a hypothetical removed directed edge e, recompute D^{(-e)} and K^{(-e)} rather than subtracting static path counts. Define mean opportunity loss and population-weighted bottom-tail mean difference separately. This is static topological disruption, not observed urban dynamic stability.

**Implementation note:** the V19 pilot intervention treats proposed candidate points as hypothetical extra library nodes. CELF maximizes the `.55`-weighted library-category saturated opportunity gain on its deterministic sampled tract anchors. It does not optimize park placement, real building costs, or the frozen M1 rank; the counterfactual map uses the same category-specific equation. The edge-removal pilot records both raw-kernel and saturated-opportunity static losses explicitly.
